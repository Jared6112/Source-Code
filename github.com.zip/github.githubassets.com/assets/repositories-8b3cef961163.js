"use strict";
(() => {
    var xt = Object.defineProperty;
    var i = (L, C) => xt(L, "name", {
        value: C,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [2113], {
            1314: (L, C, u) => {
                u.d(C, {
                    N: () => _,
                    x: () => v
                });
                var m = u(34782);
                let q = null;
                (async function() {
                    await m.x, c()
                })();

                function _(S) {
                    v(y(S))
                }
                i(_, "announceFromElement");

                function v(S) {
                    !q || (q.textContent = "", q.textContent = S)
                }
                i(v, "announce");

                function c() {
                    q = document.createElement("div"), q.setAttribute("aria-live", "polite"), q.classList.add("sr-only"), document.body.append(q)
                }
                i(c, "createNoticeContainer");

                function y(S) {
                    return (S.getAttribute("aria-label") || S.innerText || "").trim()
                }
                i(y, "getTextContent")
            },
            20963: (L, C, u) => {
                u.d(C, {
                    X: () => q
                });
                var m = u(64463);

                function q() {
                    return /Windows/.test(navigator.userAgent) ? "windows" : /Macintosh/.test(navigator.userAgent) ? "mac" : null
                }
                i(q, "getPlatform");

                function _(v) {
                    const c = (v.getAttribute("data-platforms") || "").split(","),
                        y = q();
                    return Boolean(y && c.includes(y))
                }
                i(_, "runningOnPlatform"), (0, m.N7)(".js-remove-unless-platform", function(v) {
                    _(v) || v.remove()
                })
            },
            27925: (L, C, u) => {
                u.d(C, {
                    b: () => h
                });
                var m = u(90420),
                    q = u(20963),
                    _ = u(60785),
                    v = Object.defineProperty,
                    c = Object.getOwnPropertyDescriptor,
                    y = i((g, p, M, N) => {
                        for (var I = N > 1 ? void 0 : N ? c(p, M) : p, x = g.length - 1, j; x >= 0; x--)(j = g[x]) && (I = (N ? j(p, M, I) : j(I)) || I);
                        return N && I && v(p, M, I), I
                    }, "__decorateClass");
                const {
                    getItem: S,
                    setItem: E
                } = (0, _.Z)("localStorage"), A = "code-button-default-tab";
                let h = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.shouldRefreshList = !1
                    }
                    showDownloadMessage(g) {
                        const p = this.findPlatform(g);
                        !p || this.showPlatform(p)
                    }
                    showCodespaces(g) {
                        const p = this.findPlatform(g);
                        !p || (this.showPlatform(p), this.loadAndUpdateContent())
                    }
                    showCodespaceSelector(g) {
                        const p = this.findPlatform(g);
                        !p || (this.showPlatform(p), this.codespaceSelector && (this.codespaceSelector.hidden = !1))
                    }
                    showOpenOrCreateInCodespace() {
                        this.openOrCreateInCodespace && (this.openOrCreateInCodespace.hidden = !1)
                    }
                    removeOpenOrCreateInCodespace() {
                        this.openOrCreateInCodespace && this.openOrCreateInCodespace.remove()
                    }
                    refreshList() {
                        this.shouldRefreshList && (this.shouldRefreshList = !1, this.loadAndUpdateContent())
                    }
                    trackDelete() {
                        this.shouldRefreshList = !0
                    }
                    hideSpinner() {
                        this.codespaceLoadingMenu && (this.codespaceLoadingMenu.hidden = !0), this.codespaceList && (this.codespaceList.hidden = !1)
                    }
                    showSpinner() {
                        this.codespaceLoadingMenu && (this.codespaceLoadingMenu.hidden = !1), this.codespaceList && (this.codespaceList.hidden = !0)
                    }
                    onDetailsToggle(g) {
                        this.modal.hidden = !1;
                        for (const M of this.platforms) M.hidden = !0;
                        const p = g.target;
                        p && p.open && this.selectDefaultTab()
                    }
                    showPlatform(g) {
                        this.modal.hidden = !0;
                        for (const p of this.platforms) p.hidden = p.getAttribute("data-platform") !== g
                    }
                    findPlatform(g) {
                        return g.currentTarget.getAttribute("data-open-app") || (0, q.X)()
                    }
                    refreshOnError() {
                        window.location.reload()
                    }
                    pollForVscode(g) {
                        this.showPlatform("vscode");
                        const p = g.currentTarget.getAttribute("data-src");
                        p && this.vscodePoller.setAttribute("src", p)
                    }
                    backToCodespacesFromVscodePolling() {
                        this.loadAndUpdateContent(), this.showPlatform("codespaces")
                    }
                    localTabSelected() {
                        E(A, "local")
                    }
                    cloudTabSelected() {
                        E(A, "cloud")
                    }
                    selectDefaultTab() {
                        const g = S(A);
                        if (!g) return;
                        const p = this.querySelector(`button[data-tab="${g}"`);
                        p && p.click()
                    }
                    loadAndUpdateContent() {
                        this.codespaceList.setAttribute("src", this.codespaceList.getAttribute("data-src"))
                    }
                }, "GetRepoElement");
                y([m.fA], h.prototype, "modal", 2), y([m.fA], h.prototype, "codespaceForm", 2), y([m.fA], h.prototype, "codespaceLoadingMenu", 2), y([m.fA], h.prototype, "codespaceList", 2), y([m.fA], h.prototype, "codespaceSelector", 2), y([m.fA], h.prototype, "openOrCreateInCodespace", 2), y([m.fA], h.prototype, "vscodePoller", 2), y([m.GO], h.prototype, "platforms", 2), h = y([m.Ih], h)
            },
            5909: (L, C, u) => {
                var m = u(13002),
                    q = u(88309),
                    _ = u(59753);
                (0, _.on)("tab-container-changed", ".js-branches-tags-tabs", async function(v) {
                    const c = v.detail.relatedTarget,
                        y = v.currentTarget;
                    if (!y) return;
                    let S, E;
                    for (const h of y.querySelectorAll("[data-controls-ref-menu-id]")) {
                        if (!(h instanceof m.Z || h instanceof q.Z)) return;
                        const g = h.getAttribute("data-controls-ref-menu-id"),
                            p = c.id === g;
                        h.hidden = !p, p ? E = h : S || (S = h.input ? h.input.value : "")
                    }
                    const A = E && E.input;
                    A && (E && S !== void 0 && (A.value = S), A.focus())
                }), (0, _.on)("click", ".js-onboarding-list-all", function(v) {
                    v.preventDefault();
                    const c = document.querySelectorAll(".js-task-list-hide-on-breadcrumb"),
                        y = document.querySelectorAll(".js-task-list-show-on-breadcrumb");
                    for (const S of c) S.hidden = !0;
                    for (const S of y) S.hidden = !1
                })
            },
            15820: (L, C, u) => {
                var m = u(90420),
                    q = u(3447),
                    _ = u(11793),
                    v = u(52660),
                    c = u(59753),
                    y = u(40728),
                    S = Object.defineProperty,
                    E = Object.getOwnPropertyDescriptor,
                    A = i((e, t, n, r) => {
                        for (var o = r > 1 ? void 0 : r ? E(t, n) : t, s = e.length - 1, a; s >= 0; s--)(a = e[s]) && (o = (r ? a(t, n, o) : a(o)) || o);
                        return r && o && S(t, n, o), o
                    }, "__decorateClass");
                let h = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.abortSearch = null, this.originalSelectedItem = null
                    }
                    submit(e) {
                        e.preventDefault()
                    }
                    resetField(e) {
                        if ((0, _.EL)(e) !== "Escape") return;
                        const t = this.field.value.trim();
                        this.field.value = "", t && this.search()
                    }
                    reset() {
                        this.field.focus(), this.field.value = "", (0, c.f)(this.field, "input")
                    }
                    get activeFilter() {
                        var e;
                        return (e = this.filters.find(t => t.classList.contains("selected"))) != null ? e : null
                    }
                    async search() {
                        var e;
                        this.originalSelectedItem || (this.originalSelectedItem = this.activeFilter);
                        const t = this.field.value.trim().length > 0,
                            n = g(this.field);
                        this.classList.toggle("is-search-mode", t), this.classList.add("is-loading");
                        for (const o of this.filters) o.classList.remove("selected");
                        t ? this.allFilter.classList.add("selected") : this.originalSelectedItem && (this.originalSelectedItem.classList.add("selected"), this.originalSelectedItem = null), (e = this.abortSearch) == null || e.abort();
                        const {
                            signal: r
                        } = this.abortSearch = new AbortController;
                        try {
                            const o = await (0, v.a)(document, n, {
                                signal: r
                            });
                            (0, y.lO)(null, "", n), this.result.innerHTML = "", this.result.appendChild(o)
                        } catch {}
                        r.aborted || this.classList.remove("is-loading")
                    }
                }, "BranchFilterElement");
                A([m.fA], h.prototype, "field", 2), A([m.fA], h.prototype, "result", 2), A([m.fA], h.prototype, "allFilter", 2), A([m.GO], h.prototype, "filters", 2), A([(0, q.D)(100)], h.prototype, "search", 1), h = A([m.Ih], h);

                function g(e) {
                    const t = e.form;
                    if (e.value.trim()) {
                        const n = new URL(t.action, window.location.origin),
                            r = new URLSearchParams(n.search.slice(1)),
                            o = t.elements.namedItem("utf8");
                        return o instanceof HTMLInputElement && r.append("utf8", o.value), r.append("query", e.value), n.search = r.toString(), n.toString()
                    }
                    return t.getAttribute("data-reset-url")
                }
                i(g, "queryUrl");
                var p = u(1314),
                    M = Object.defineProperty,
                    N = Object.getOwnPropertyDescriptor,
                    I = i((e, t, n, r) => {
                        for (var o = r > 1 ? void 0 : r ? N(t, n) : t, s = e.length - 1, a; s >= 0; s--)(a = e[s]) && (o = (r ? a(t, n, o) : a(o)) || o);
                        return r && o && M(t, n, o), o
                    }, "branch_filter_item_element_decorateClass");
                let x = i(class extends HTMLElement {
                    get branch() {
                        return this.getAttribute("branch")
                    }
                    get branches() {
                        const t = this.closest("branch-filter").querySelectorAll("branch-filter-item");
                        return Array.from(t).filter(n => n.branch === this.branch)
                    }
                    get dialogBodyPath() {
                        return this.getAttribute("dialog-body-path")
                    }
                    get destroyDialog() {
                        return this.closest("branch-filter").querySelector("modal-dialog")
                    }
                    loading(e) {
                        for (const t of this.branches) e ? t.spinner.removeAttribute("hidden") : t.spinner.setAttribute("hidden", "true"), t.destroyButton && (t.destroyButton.hidden = e)
                    }
                    set mode(e) {
                        for (const t of this.branches) t.classList.toggle("Details--on", e === "restore")
                    }
                    async restore(e) {
                        e.preventDefault(), this.loading(!0);
                        const t = e.target;
                        let n;
                        try {
                            n = await fetch(t.action, {
                                method: t.method,
                                body: new FormData(t),
                                headers: {
                                    "X-Requested-With": "XMLHttpRequest"
                                }
                            })
                        } catch {} finally {
                            (!n || !n.ok) && location.reload(), this.loading(!1)
                        }
                        this.mode = "destroy"
                    }
                    async destroy(e) {
                        e.preventDefault(), this.loading(!0), this.disableAllDeleteButtons(!0);
                        let t;
                        try {
                            t = await fetch(this.dialogBodyPath)
                        } catch {}
                        if (!t || !t.ok) {
                            this.displayServerError(!0, (t == null ? void 0 : t.status) === 404), this.disableAllDeleteButtons(!1), this.loading(!1);
                            return
                        }
                        this.displayServerError(!1);
                        const n = await t.text();
                        n ? (this.setUpDialog(n), this.loading(!1), this.destroyDialog.show(), this.disableAllDeleteButtons(!1)) : (this.disableAllDeleteButtons(!1), await this.confirmDeletion())
                    }
                    async confirmDeletion() {
                        this.loading(!0), this.destroyDialog.close();
                        const e = this.destroyButton.closest("form");
                        let t;
                        try {
                            t = await fetch(e.action, {
                                method: e.method,
                                body: new FormData(e),
                                headers: {
                                    "X-Requested-With": "XMLHttpRequest"
                                }
                            })
                        } catch {}
                        if (!t || !t.ok) {
                            this.displayServerError(!0, (t == null ? void 0 : t.status) === 404), this.loading(!1);
                            return
                        }(0, p.x)(`Branch ${this.branch} deleted`), this.loading(!1), this.mode = "restore"
                    }
                    setUpDialog(e) {
                        const t = this.destroyDialog;
                        t.querySelector(".js-delete-dialog-body").innerHTML = e;
                        const n = t.querySelector(".js-delete-branch-confirm"),
                            r = n.cloneNode(!0);
                        n.replaceWith(r), r.addEventListener("click", () => this.confirmDeletion())
                    }
                    disableAllDeleteButtons(e) {
                        for (const t of document.querySelectorAll(".js-branch-delete-button")) t.disabled = e, e ? t.classList.add("disabled") : t.classList.remove("disabled")
                    }
                    displayServerError(e, t = !1) {
                        const n = document.querySelector(".js-branch-delete-error"),
                            r = document.querySelector(".js-branch-delete-warning");
                        e ? t ? (r.querySelector(".js-branch-delete-warning-name").textContent = this.branch, r.hidden = !1) : (n.querySelector(".js-branch-delete-error-name").textContent = this.branch, n.hidden = !1) : (n.hidden = !0, r.hidden = !0)
                    }
                }, "BranchFilterItemElement");
                I([m.fA], x.prototype, "destroyButton", 2), I([m.fA], x.prototype, "spinner", 2), x = I([m.Ih], x);
                var j = u(64463);
                (0, j.N7)(".js-new-badge-autodismiss", {
                    constructor: HTMLFormElement,
                    add: e => {
                        const t = e.closest("details");
                        t.addEventListener("toggle", () => {
                            t.hasAttribute("open") && fetch(e.action, {
                                method: e.method,
                                body: new FormData(e),
                                headers: {
                                    "X-Requested-With": "XMLHttpRequest"
                                }
                            })
                        })
                    }
                }), (0, j.N7)(".js-fetch-upstream-details-content", {
                    constructor: HTMLElement,
                    initialize(e) {
                        e.hidden = !0
                    }
                }), (0, c.on)("click", ".js-fetch-upstream-summary", async function() {
                    const e = document.querySelector("details.js-fetch-upstream-details"),
                        t = e.querySelector(".js-fetch-upstream-details-spinner");
                    if (e.open) {
                        t.hidden = !1;
                        return
                    }
                    if (t.hidden) return;
                    const n = e.querySelector(".js-fetch-upstream-details-content"),
                        r = n.querySelector(".js-fetch-upstream-conflicts-ui"),
                        o = n.querySelector(".js-fetch-upstream-no-conflicts-ui"),
                        s = n.querySelector(".js-fetch-upstream-conflicts-error-message"),
                        a = n.querySelector(".js-fetch-upstream-conflicts-no-error-message");
                    if (parseInt(n.getAttribute("data-behind")) === 0) {
                        r.hidden = !0, o.hidden = !1, n.hidden = !1, t.hidden = !0;
                        return
                    }
                    const d = n.getAttribute("data-mergeability-check-url"),
                        f = await fetch(d, {
                            headers: {
                                Accept: "application/json"
                            }
                        });
                    n.hidden = !1, t.hidden = !0, f.ok ? (await f.json()).state === "clean" ? o.hidden = !1 : r.hidden = !1 : (r.hidden = !1, s.hidden = !1, a.hidden = !0)
                });
                var pe = u(86404),
                    me = u(65935),
                    Ge = u(82036);
                (0, j.N7)(".repository-import", {
                    subscribe: e => (0, pe.RB)(e, "socket:message", function(t) {
                        const n = t.detail.data;
                        n.redirect_to && (document.location.href = n.redirect_to, t.stopImmediatePropagation())
                    })
                }), (0, c.on)("change", "input.js-repository-import-lfs-opt", function({
                    currentTarget: e
                }) {
                    const t = parseInt(e.getAttribute("data-percent-used") || ""),
                        n = e.closest(".js-repository-import-lfs-container"),
                        r = e.getAttribute("data-used") || "";
                    n.querySelector(".js-repository-import-lfs-warn").classList.toggle("d-none", !(t > 100)), n.querySelector(".js-usage-bar").classList.toggle("exceeded", t >= 100), n.querySelector(".js-usage-bar").setAttribute("aria-label", `${t}%`), n.querySelector(".js-repository-import-lfs-progress").style.width = `${t}%`, n.querySelector("span.js-usage-text").textContent = r
                }), (0, me.AC)(".js-repository-import-author-form", async function(e, t) {
                    const n = await t.html();
                    e.closest(".js-repository-import-author").replaceWith(n.html)
                }), (0, c.on)("click", ".js-repository-import-projects-cancel-button", function() {
                    const e = document.querySelector(".js-repository-import-projects-cancel-form");
                    (0, Ge.Bt)(e)
                }), (0, j.N7)(".js-branch-merge-queue-link", {
                    subscribe: e => (0, pe.RB)(e, "socket:message", async function(t) {
                        const n = t.detail.data.queue_entries_count,
                            r = e.getAttribute("data-singular-message"),
                            o = e.getAttribute("data-plural-message");
                        n === "1" ? e.textContent = `${n} ${r}` : e.textContent = `${n} ${o}`
                    })
                });
                var z = u(84570);
                let he = !1;

                function Ke() {
                    const e = document.querySelector(".js-privacy-toggle:checked");
                    if (!!e) return e.value === "private"
                }
                i(Ke, "privateRepoSelected");

                function ge() {
                    const e = document.querySelector(".js-repo-name");
                    (0, c.f)(e, "input");
                    const t = document.querySelector('.js-owner-container [aria-checked="true"]'),
                        n = t.getAttribute("data-org-allow-public-repos") !== "false",
                        r = document.querySelector(".js-privacy-toggle[value=public]"),
                        o = document.querySelector(".js-privacy-toggle-label-public"),
                        s = document.querySelector(".js-public-description"),
                        a = document.querySelector(".js-public-restricted-by-policy-description");
                    be(n, r, o, s, a);
                    const l = t.getAttribute("data-business-id"),
                        d = et(l, t),
                        f = t.getAttribute("data-org-allow-private-repos") !== "false",
                        b = document.querySelector(".js-privacy-toggle[value=private]"),
                        w = document.querySelector(".js-privacy-toggle-label-private"),
                        k = document.querySelector(".js-private-description"),
                        D = document.querySelector(".js-private-restricted-by-policy-description");
                    be(f, b, w, k, D), Je();
                    const Re = t.getAttribute("data-org-private-restricted-by-plan") !== "false",
                        R = document.querySelector(".js-upgrade-private-description"),
                        Be = t.getAttribute("data-org-show-upgrade") !== "false",
                        Ue = t.getAttribute("data-org-name"),
                        B = Ue ? document.querySelector(`a[data-upgrade-link="${Ue}"]`) : null,
                        U = document.querySelector(".js-ask-owner-message");
                    f || !Re ? (R && (R.hidden = !0), B && (B.hidden = !0), U && (U.hidden = !0)) : (D && (D.hidden = Re), R && (R.hidden = !1), B && (B.hidden = !Be), U && (U.hidden = Be)), Ze(t), Ye(t);
                    const _t = t.getAttribute("data-default-new-repo-branch"),
                        Fe = document.querySelector(".js-new-repo-owner-default-branch");
                    Fe && (Fe.textContent = _t);
                    const Dt = t.getAttribute("data-owner-settings-link-prefix"),
                        He = document.querySelector(".js-new-repo-owner-settings-link-prefix");
                    He && (He.textContent = Dt);
                    const $e = t.getAttribute("data-owner-settings-url"),
                        Y = document.querySelector(".js-repo-owner-default-branch-settings-link-container"),
                        J = document.querySelector(".js-org-repo-owner-default-branch-settings-info");
                    if ($e) {
                        const P = document.querySelector(".js-new-repo-owner-settings-link");
                        P && (P.href = $e, Y && (Y.hidden = !1)), J && (J.hidden = !0)
                    } else if (Y && (Y.hidden = !0, J)) {
                        const P = t.hasAttribute("data-viewer-is-org-admin");
                        J.hidden = !P
                    }
                    const Et = t.getAttribute("data-org-show-trade-controls") === "true",
                        We = t.getAttribute("data-viewer-is-org-admin") === "true",
                        le = t.getAttribute("data-user-show-trade-controls") === "true",
                        de = Et && !f,
                        O = document.querySelector(".js-trade-controls-description"),
                        Q = document.querySelector(".js-individual-trade-controls-description");
                    le || de ? (D && (!le && !We && de ? D.hidden = !1 : D.hidden = !0), b.disabled = !0, k && (k.hidden = !0), R && (R.hidden = !0), B && (B.hidden = !0), U && (U.hidden = !0)) : (O && (O.hidden = !0), Q && (Q.hidden = !0)), le ? (O && (O.hidden = !0), Q && (Q.hidden = !1)) : de && O && (We ? O.hidden = !1 : O.hidden = !0), Qe(t, r, d, b), tt(t.getAttribute("data-permission") === "yes"), nt(), je();
                    const ue = document.querySelector(".js-quick-install-container");
                    if (ue) {
                        const P = ue.querySelector(".js-quick-install-divider");
                        P.hidden = !0;
                        const ze = document.querySelector("input[name=owner]:checked").parentElement;
                        if (ze) {
                            const fe = ze.querySelector(".js-quick-install-list-template");
                            if (fe instanceof HTMLTemplateElement) {
                                const Xe = ue.querySelector(".js-account-apps");
                                Xe.innerHTML = "", Xe.append(fe.content.cloneNode(!0)), fe.children.length > 0 && (P.hidden = !1)
                            }
                        }
                    }
                }
                i(ge, "handleOwnerChange");

                function ye(e, t) {
                    const n = t.getAttribute("data-org-name"),
                        r = t.getAttribute("data-business-name"),
                        o = t.getAttribute("data-is-user-or-org") === "true",
                        s = i(() => `You are creating a${e==="internal"?"n internal":` ${e}`} repository`, "creatingRepoMessage"),
                        a = i(() => n ? `the ${n} organization` : "your personal account", "creatingOrgMessage"),
                        l = i(() => r ? ` (${r})` : "", "creatingEnterpriseMessage"),
                        d = i(() => o ? `${s()} in ${a()}${l()}` : `${s()}`, "repoDestinationMessage"),
                        f = document.querySelector(".js-new-repo-destination-message");
                    f && (f.textContent = `${d()}.`)
                }
                i(ye, "updateRepoDestinationMessage");

                function Ve(e) {
                    const t = document.querySelector('.js-owner-container [aria-checked="true"]');
                    ye(e, t)
                }
                i(Ve, "updateRepoDestinationMessageFromVisibility");

                function Ze(e) {
                    const t = document.querySelector(".js-privacy-toggle:checked");
                    !t || ye(t.value, e)
                }
                i(Ze, "updateRepoDestinationMessageFromSelectedOwner");

                function Ye(e) {
                    const t = e.getAttribute("data-is-user-or-org") === "true",
                        n = document.querySelector(".js-repo-name");
                    t || (n.value = ""), n.disabled = !t, (0, c.f)(n, "input", !1)
                }
                i(Ye, "disableRepoNameIfRepoNotSelected");

                function be(e, t, n, r, o) {
                    e ? (t && (t.disabled = !1), n && n.classList.remove("color-fg-muted"), r && (r.hidden = !1), o && (o.hidden = !0)) : (t && (t.disabled = !0), n && n.classList.add("color-fg-muted"), r && (r.hidden = !0), o && (o.hidden = !1))
                }
                i(be, "enableDisableRepoType");

                function Je() {
                    const e = document.querySelectorAll('.js-org-upgrade-link:not([hidden=""]');
                    for (const t of e) t.hidden = !0
                }
                i(Je, "hideOrgUpgradeLinks");

                function Qe(e, t, n, r) {
                    let o = null;
                    if (e.getAttribute("data-default") === "private" && r && !r.disabled ? o = r : e.getAttribute("data-default") === "internal" && n && !n.disabled ? o = n : t && !t.disabled ? o = t : n && !n.disabled && (o = n), !o) return;
                    const s = t && t.disabled && t.checked || r.disabled && r.checked || n && n.disabled && n.checked,
                        a = (!t || !t.checked) && (!n || !n.checked) && !r.checked;
                    (he === !1 || s === !0 || a === !0) && (o.checked = !0, (0, c.f)(o, "change"))
                }
                i(Qe, "ensureOneRadioIsSelected");

                function et(e, t) {
                    let n = !1;
                    const r = document.querySelectorAll(".js-new-repo-internal-visibility");
                    for (const o of r) {
                        o.hidden = !0;
                        const s = o.querySelector(".js-privacy-toggle[value=internal]");
                        s instanceof HTMLInputElement && s.checked && (n = !0)
                    }
                    if (e) {
                        const o = document.querySelector(`#new-repo-internal-visibility-${e}`);
                        if (o) {
                            o.hidden = !1;
                            const s = o.querySelector(".js-privacy-toggle-label-internal"),
                                a = o.querySelector(".js-internal-description"),
                                l = o.querySelector(".js-internal-restricted-by-policy-description"),
                                d = o.querySelector(".js-privacy-toggle[value=internal]");
                            if (d instanceof HTMLInputElement) return t.getAttribute("data-org-allow-internal-repos") === "false" ? (d.disabled = !0, s && s.classList.add("color-fg-muted"), a && (a.hidden = !0), l && (l.hidden = !1)) : (n && (d.checked = !0, (0, c.f)(d, "change")), d.disabled = !1, s && s.classList.remove("color-fg-muted"), a && (a.hidden = !1), l && (l.hidden = !0)), d
                        }
                    }
                    return null
                }
                i(et, "updateInternalDiv");

                function tt(e) {
                    for (const r of document.querySelectorAll(".js-with-permission-fields")) r.hidden = !e;
                    for (const r of document.querySelectorAll(".js-without-permission-fields")) r.hidden = e;
                    const t = document.querySelector(".errored"),
                        n = document.querySelector("dl.warn");
                    t && (t.hidden = !e), n && (n.hidden = !e)
                }
                i(tt, "togglePermissionFields");

                function je(e) {
                    const t = document.querySelector("#js-upgrade-container");
                    if (!t) return;
                    const n = t.querySelector(".js-billing-section"),
                        r = t.querySelector(".js-confirm-upgrade-checkbox");
                    let o = e ? e.target : null;
                    o || (o = document.querySelector(".js-privacy-toggle:checked")), o.value === "false" ? (t.hidden = !1, n && n.classList.remove("has-removed-contents"), r && (r.checked = !0)) : (t.hidden = !0, n && n.classList.add("has-removed-contents"), r && (r.checked = !1)), Ve(o.value), T()
                }
                i(je, "handlePrivacyChange");

                function nt() {
                    const e = document.querySelector("#js-upgrade-container");
                    if (!e) return;
                    const t = document.querySelector("#js-payment-methods-form");
                    e.firstElementChild && t.appendChild(e.firstElementChild);
                    const n = document.querySelector("input[name=owner]:checked").value,
                        r = t.querySelector(`.js-upgrade[data-login="${n}"]`);
                    r && e.appendChild(r)
                }
                i(nt, "updateUpsell");

                function T() {
                    const e = document.querySelector(".js-repo-form"),
                        t = e.querySelector(".js-repository-owner-choice:checked"),
                        n = e.querySelector(".js-repo-name"),
                        r = e.querySelector(".js-repo-url"),
                        o = e.querySelector(".js-repo-gitignore"),
                        s = e.querySelector(".js-repo-license");
                    let a = r ? !r.classList.contains("is-autocheck-errored") : !0;
                    if (a = a && !!t, a && n && (a = n.classList.contains("is-autocheck-successful"), Ke() && (a = a && rt())), o && o.checked) {
                        const d = e.querySelector('input[name="repository[gitignore_template]"]:checked');
                        a = a && d.value !== ""
                    }
                    if (s && s.checked) {
                        const d = e.querySelector('input[name="repository[license_template]"]:checked');
                        a = a && d.value !== ""
                    }
                    const l = e.querySelector("button[type=submit]");
                    l.disabled = !a
                }
                i(T, "validate");

                function rt() {
                    const e = document.querySelector("#js-upgrade-container");
                    if (!e) return !0;
                    if (e.querySelector(".js-ofac-sanction-notice")) return !1;
                    const n = e.querySelector(".js-confirm-upgrade-checkbox");
                    if (n instanceof HTMLInputElement && !n.checked) return !1;
                    const r = e.querySelector(".js-zuora-billing-info");
                    return !(r && r.classList.contains("d-none"))
                }
                i(rt, "validBillingInfo");

                function ot(e) {
                    const t = e.closest(".js-repo-init-setting-container");
                    if (!t) return;
                    const n = t.querySelector(".js-repo-init-setting-unchecked-menu-option");
                    n && !n.checked && (n.checked = !0, (0, c.f)(n, "change"))
                }
                i(ot, "onRepoInitSettingUnchecked");

                function st(e) {
                    const t = e.closest(".js-repo-init-setting-container");
                    if (!t) return;
                    const n = t.querySelector(".js-toggle-repo-init-setting");
                    (n == null ? void 0 : n.checked) && (n.checked = !1, (0, c.f)(n, "change"))
                }
                i(st, "onRepoInitNoneMenuOptionSelected");

                function at(e) {
                    const t = e.closest("form"),
                        n = t.querySelector(".js-new-repo-default-branch-info");
                    if (!n) return;
                    const o = t.querySelectorAll(".js-toggle-new-repo-default-branch-info:checked").length > 0;
                    n.hidden = !o
                }
                i(at, "toggleDefaultBranchInfo"), (0, j.N7)("#js-upgrade-container .js-zuora-billing-info:not(.d-none)", T), (0, j.N7)(".js-page-new-repo", function() {
                    const e = document.querySelector("#js-upgrade-container");
                    e && (e.hidden = !0), ge();
                    const t = document.querySelector(".js-repo-form"),
                        n = t.querySelector(".js-repo-url");
                    if (n) {
                        n.focus();
                        return
                    }
                    const r = t.querySelector(".js-template-repository-select");
                    if (r) {
                        r.focus();
                        return
                    }
                    const o = t.querySelector(".js-owner-select");
                    o && o.focus()
                }), (0, c.on)("click", ".js-reponame-suggestion", function(e) {
                    if (document.querySelector('.js-owner-container [aria-checked="true"]').getAttribute("data-is-user-or-org") !== "true") return;
                    const n = document.querySelector(".js-repo-name");
                    n.value = e.currentTarget.textContent, (0, c.f)(n, "input", !1)
                }), (0, c.on)("click", ".js-privacy-toggle", function() {
                    he = !0
                }), (0, c.on)("change", ".js-privacy-toggle", je), (0, c.on)("details-menu-selected", ".js-owner-container", ge, {
                    capture: !0
                }), (0, c.on)("change", "#js-upgrade-container input", T), (0, z.q6)("#js-upgrade-container input", T);
                const it = i(e => {
                        const t = document.querySelector(".js-org-profile");
                        if (t) {
                            const n = document.querySelector(".js-owner-container input.js-repository-owner-is-org:checked"),
                                r = e.target,
                                o = !(n && r.value.toLowerCase() === ".github");
                            t.hidden = o;
                            const s = document.querySelector("#repo-name-suggestion");
                            s.hidden = !o
                        }
                    }, "renderOrgProfileHint"),
                    ct = i(e => {
                        const t = document.querySelector(".js-org-private-profile");
                        if (t) {
                            const n = document.querySelector(".js-owner-container input.js-repository-owner-is-org:checked"),
                                r = e.target,
                                o = !(n && r.value.toLowerCase() === ".github-private");
                            t.hidden = o;
                            const s = document.querySelector("#repo-name-suggestion");
                            s.hidden = !o
                        }
                    }, "renderOrgPrivateProfileHint"),
                    lt = i(e => {
                        const t = document.querySelector(".js-personal");
                        if (t) {
                            const n = document.querySelector(".js-owner-container input.js-repository-owner-is-viewer"),
                                r = e.target,
                                o = !(n && n.checked && n.defaultValue.toLowerCase() === r.value.toLowerCase());
                            t.hidden = o;
                            const s = document.querySelector("#repo-name-suggestion");
                            s.hidden = !o
                        }
                    }, "renderPersonalProfileHint");
                (0, z.q6)(".js-owner-reponame .js-repo-name", function(e) {
                    lt(e), it(e), ct(e), T()
                }), (0, c.on)("auto-check-send", ".js-repo-name-auto-check", function(e) {
                    const r = e.currentTarget.form.querySelector("input[name=owner]:checked").value;
                    e.detail.body.append("owner", r)
                }), (0, c.on)("auto-check-complete", ".js-repo-name-auto-check", T), (0, z.q6)(".js-repo-url", function(e) {
                    const t = e.target;
                    if (!(t instanceof HTMLInputElement)) return;
                    const n = t.closest(".form-group");
                    if (!(n instanceof HTMLDListElement)) return;
                    const r = document.querySelector(".js-insecure-url-warning"),
                        o = document.querySelector(".js-svn-url-error"),
                        s = document.querySelector(".js-git-url-error"),
                        a = t.value.toLowerCase();
                    r.hidden = !a.startsWith("http://"), o.hidden = !a.startsWith("svn://"), s.hidden = !a.startsWith("git://"), a.startsWith("svn://") || a.startsWith("git://") ? (t.classList.add("is-autocheck-errored"), n.classList.add("errored")) : (t.classList.remove("is-autocheck-errored"), n.classList.remove("errored")), T()
                }), (0, c.on)("change", ".js-toggle-repo-init-setting", e => {
                    const t = e.currentTarget;
                    t.checked || ot(t), T()
                }), (0, c.on)("change", ".js-repo-init-setting-unchecked-menu-option", e => {
                    const t = e.currentTarget;
                    t.checked && st(t), T()
                }), (0, c.on)("change", ".js-repo-init-setting-menu-option", T), (0, c.on)("change", ".js-repo-readme", T), (0, c.on)("change", ".js-toggle-new-repo-default-branch-info", e => {
                    const t = e.currentTarget;
                    at(t)
                });
                var Pt = u(5909);
                (0, j.N7)(".js-pulse-contribution-data", e => {
                    ut(e)
                });
                async function dt(e) {
                    return (0, v.a)(document, e)
                }
                i(dt, "diffstatCall");
                async function ut(e) {
                    const t = e.getAttribute("data-pulse-diffstat-summary-url");
                    let n;
                    try {
                        t && (n = await dt(t), ft(n, e))
                    } catch {
                        const o = e.querySelector(".js-blankslate-loading"),
                            s = e.querySelector(".js-blankslate-error");
                        o.classList.add("d-none"), s.classList.remove("d-none")
                    }
                }
                i(ut, "loadContributionData");

                function ft(e, t) {
                    t.innerHTML = "", t.appendChild(e)
                }
                i(ft, "showContributionData");
                var ve = u(43682);
                async function Se(e) {
                    const t = e.form,
                        n = t.querySelector("#release_draft");
                    n.value = "1", X(e, "saving");
                    const r = await fetch(t.action, {
                        method: t.method,
                        body: new FormData(t),
                        headers: {
                            Accept: "application/json",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    });
                    if (!r.ok) {
                        X(e, "failed");
                        return
                    }
                    const o = await r.json();
                    return X(e, "saved"), setTimeout(X, 5e3, e, "default"), (0, c.f)(t, "release:saved", {
                        release: o
                    }), o
                }
                i(Se, "saveDraft"), (0, c.on)("change", ".js-releases-marketplace-publish-field", function(e) {
                    we(e.currentTarget)
                }), (0, j.N7)(".js-releases-marketplace-publish-field", function(e) {
                    we(e)
                });

                function we(e) {
                    const n = e.closest(".js-releases-marketplace-publish-container").querySelector(".js-releases-marketplace-publish-preview");
                    e.checked ? n.classList.remove("d-none") : n.classList.add("d-none")
                }
                i(we, "processMarketplacePublishCheckbox"), (0, c.on)("click", ".js-save-draft", function(e) {
                    const t = e.currentTarget;
                    Se(t), e.preventDefault()
                });

                function X(e, t) {
                    for (const n of e.querySelectorAll(".js-save-draft-button-state")) n.hidden = n.getAttribute("data-state") !== t;
                    e.disabled = t === "saving"
                }
                i(X, "setState"), (0, c.on)("release:saved", ".js-release-form", function(e) {
                    const t = e.detail.release,
                        n = e.currentTarget;
                    if (n.setAttribute("action", t.update_url), t.update_authenticity_token) {
                        const o = n.querySelector("input[name=authenticity_token]");
                        o.value = t.update_authenticity_token
                    }(0, y.lO)((0, ve.y0)(), document.title, t.edit_url);
                    const r = n.querySelector("#release_id");
                    if (!r.value) {
                        r.value = t.id;
                        const o = document.createElement("input");
                        o.type = "hidden", o.name = "_method", o.value = "put", n.appendChild(o)
                    }
                }), (0, c.on)("click", ".js-publish-release", function() {
                    document.querySelector("#release_draft").value = "0"
                });

                function F(e) {
                    const t = document.querySelector(".js-release-target-wrapper");
                    if (t != null) {
                        switch (pt(e), e) {
                            case "valid":
                            case "invalid":
                            case "duplicate":
                                t.hidden = !0;
                                break;
                            case "loading":
                                break;
                            default:
                                t.hidden = !1
                        }
                        for (const n of document.querySelectorAll(".js-tag-status-message")) n.hidden = n.getAttribute("data-state") !== e;
                        ne(), H("pending")
                    }
                }
                i(F, "setTagWrapperState");

                function qe() {
                    return document.querySelector(".js-release-tag").getAttribute("data-state")
                }
                i(qe, "getTagState");

                function pt(e) {
                    document.querySelector(".js-release-tag").setAttribute("data-state", e)
                }
                i(pt, "setTagState");
                const Ae = new WeakMap;

                function ee(e) {
                    const t = e.querySelector('input[name="release[tag_name]"]:checked');
                    return t == null ? void 0 : t.value
                }
                i(ee, "getTagName");
                async function ke(e) {
                    const t = ee(e);
                    if (!t) {
                        F("empty");
                        return
                    }
                    if (t === Ae.get(e)) return;
                    F("loading"), Ae.set(e, t);
                    const n = e.getAttribute("data-url"),
                        r = new URL(n, window.location.origin),
                        o = new URLSearchParams(r.search.slice(1));
                    o.append("tag_name", t), r.search = o.toString();
                    const s = await fetch(r.toString(), {
                        headers: {
                            Accept: "application/json",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    });
                    if (!s.ok) {
                        F("invalid");
                        return
                    }
                    const a = await s.json();
                    a.status === "duplicate" && parseInt(e.getAttribute("data-existing-id")) === parseInt(a.release_id) ? F("valid") : (document.querySelector(".js-release-tag .js-edit-release-link").setAttribute("href", a.url), F(a.status)), Ie(e)
                }
                i(ke, "checkTag"), (0, c.on)("click", ".js-generate-release-notes", function(e) {
                    const t = e.currentTarget;
                    t.disabled || mt(t)
                });
                async function mt(e) {
                    H("loading"), e.disabled = !0;
                    const n = `${e.getAttribute("data-repo-url")}/releases/notes`,
                        r = new URL(n, window.location.origin),
                        o = new URLSearchParams(r.search.slice(1));
                    o.append("commitish", Ce()), o.append("tag_name", ee(document) || ""), o.append("previous_tag_name", gt()), r.search = o.toString();
                    const s = await fetch(r.toString(), {
                        headers: {
                            Accept: "application/json"
                        }
                    });
                    if (s.ok) {
                        const a = await s.json();
                        if (a.commitish === Ce()) {
                            const l = document.getElementById("release_body"),
                                d = Le() === "generated" ? "" : l.value.trim();
                            d ? l.value = d.concat(`

`, a.body) : l.value = a.body;
                            const f = document.getElementById("release_name");
                            f.value || (f.value = a.title), H("succeed"), te(d ? "generated-and-edited" : "generated");
                            const b = document.querySelector(".js-release-body-warning");
                            b.textContent = a.warning_message, b.hidden = !a.warning_message
                        }
                    } else {
                        H("failed"), e.disabled = !1;
                        const a = await s.json();
                        if (a && a.error) {
                            const l = document.querySelector(".js-comment-form-error");
                            l.textContent = a.error, l.hidden = !1
                        }
                    }
                }
                i(mt, "generateNotes");
                const ht = ["pending", "loading", "succeed", "failed"];

                function H(e) {
                    if (ht.map(t => {
                            const n = document.getElementById(`generate-icon-${t}`);
                            n && (t === e ? n.removeAttribute("hidden") : n.setAttribute("hidden", "true"))
                        }), e !== "failed") {
                        const t = document.querySelector(".js-comment-form-error");
                        t.textContent = "", t.hidden = !0
                    }
                }
                i(H, "setGeneratedNotesFetchState");

                function te(e) {
                    const t = document.getElementById("generated_notes_state");
                    t.value = e
                }
                i(te, "setNotesTrackingState");

                function Le() {
                    return document.getElementById("generated_notes_state").value
                }
                i(Le, "getNotesTrackingState");

                function Ce() {
                    var e;
                    return qe() === "valid" ? ee(document) || "" : ((e = document.querySelector('input[name="release[target_commitish]"]:checked')) == null ? void 0 : e.value) || ""
                }
                i(Ce, "getCommitish");

                function gt() {
                    var e;
                    return ((e = document.querySelector('input[name="release[previous_tag_name]"]:checked')) == null ? void 0 : e.value) || ""
                }
                i(gt, "getPreviousTagName"), (0, j.N7)(".js-release-tag", i(function(t) {
                    ke(t)
                }, "initialize"));

                function Ie(e) {
                    const n = e.closest("form").querySelector(".js-previewable-comment-form");
                    if (!n) return;
                    let r = n.getAttribute("data-base-preview-url");
                    r || (r = String(n.getAttribute("data-preview-url")), n.setAttribute("data-base-preview-url", r));
                    const o = e.querySelectorAll('input[name="release[tag_name]"], input[name="release[target_commitish]"]:checked'),
                        s = new URL(r, window.location.origin),
                        a = new URLSearchParams(s.search.slice(1));
                    for (const l of o) l.value && a.append(l.name, l.value);
                    s.search = a.toString(), n.setAttribute("data-preview-url", s.toString())
                }
                i(Ie, "processChangedTag");

                function ne(e = !1) {
                    const t = document.querySelector(".js-generate-release-notes"),
                        n = document.getElementById("prev-tag-picker");
                    if (t) {
                        const r = qe(),
                            o = r !== "valid" && r !== "pending";
                        t.disabled = e || o, t.ariaLabel = `${t.disabled?"Select a valid tag to a":"A"}utomatically add the markdown for all the merged pull requests from this diff and contributors of this release`, n && (n.hidden = e || o)
                    }
                }
                i(ne, "refreshGenerateNotesButton");

                function Te(e) {
                    if (e.value === "") ne(), H("pending"), te("initial");
                    else {
                        const t = Le();
                        ne(t !== "initial"), t === "generated" && te("generated-and-edited")
                    }
                }
                i(Te, "processChangedBody"), (0, c.on)("click", ".js-release-expand-btn", async function(e) {
                    const t = e.currentTarget.closest(".js-release-expandable"),
                        n = t.getAttribute("data-expand-url"),
                        r = await (0, v.a)(document, n);
                    t == null || t.replaceWith(r)
                }), (0, j.N7)("#release_body", function(e) {
                    const t = e;
                    t.addEventListener("input", function() {
                        Te(t)
                    }), Te(t)
                }), (0, c.on)("change", ".js-release-check-tag", function(e) {
                    const t = e.currentTarget.closest(".js-release-tag");
                    ke(t)
                }), (0, j.N7)(".js-release-form .js-previewable-comment-form", function(e) {
                    const t = e.closest("form").querySelector(".js-release-tag");
                    Ie(t)
                });
                let re, G;
                async function K(e) {
                    const t = document.querySelector(".js-release-stack").getAttribute("data-stack-url"),
                        n = new URL(t, window.location.origin);
                    let r;
                    switch ($({
                        target_found: !0,
                        template_found: !0,
                        loading: !0
                    }, "tag"), e.id) {
                        case "tag-list":
                            {
                                const o = e.querySelector('input[name="release[tag_name]"]:checked');
                                if (!o) return;r = await V(n, "ref", o),
                                r.target_found ? $(r, "tag") : (r = await V(n, G, re), $(r, G === "ref" ? "branch" : "commit"));
                                break
                            }
                        case "filter-list-branches":
                            {
                                const o = e.querySelector('input[name="release[target_commitish]"]:checked');
                                if (!o) return;re = o,
                                G = "ref",
                                r = await V(n, "ref", o),
                                $(r, "branch");
                                break
                            }
                        case "filter-list-tags":
                            {
                                const o = e.querySelector('input[name="release[target_commitish]"]:checked');
                                if (!o) return;re = o,
                                G = "oid",
                                r = await V(n, "oid", o),
                                $(r, "commit");
                                break
                            }
                    }
                }
                i(K, "validateStack");
                const oe = new WeakMap;
                async function V(e, t, n) {
                    if (oe.has(n)) return oe.get(n);
                    const r = new URLSearchParams(e.search.slice(1));
                    r.append(t, n.value), e.search = r.toString();
                    const o = await fetch(e.toString(), {
                        headers: {
                            Accept: "application/json",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    });
                    let s = {
                        target_found: !1
                    };
                    return o.ok && (s = await o.json(), s.target_found = !0), oe.set(n, s), s
                }
                i(V, "getStackStatus");
                const yt = {
                    branding: "Icon and color found in stack template.",
                    template: "Contains all the required information.",
                    readme: "File exists.",
                    init: "No issues found in init section."
                };

                function $(e, t) {
                    if (!e.target_found) return;
                    const n = document.querySelector(".js-releases-marketplace-banner-container"),
                        r = document.querySelector(".js-releases-marketplace-publish-heading"),
                        o = document.querySelector(".js-publish-release");
                    let s = !1;
                    if (o.disabled = r.hidden = n.hidden = !e.template_found, !e.template_found) return;
                    const a = ["branding", "template", "readme", "init"];
                    for (const d of a) {
                        let f;
                        e.loading ? f = "loading" : f = e[d] ? "failure" : "success", f === "failure" && (s = !0);
                        const b = n.querySelector(`#${d}-row`);
                        for (const k of b.querySelectorAll(".status-icon")) k.hidden = k.getAttribute("data-state") !== f;
                        const w = b.querySelector(".js-status-text");
                        for (const k of ["color-fg-attention", "color-fg-danger", "color-fg-muted"]) w.classList.remove(k);
                        switch (f) {
                            case "success":
                                w.textContent = yt[d], w.classList.add("color-fg-muted");
                                break;
                            case "failure":
                                w.textContent = e[d], w.classList.add("color-fg-danger");
                                break;
                            case "loading":
                                w.textContent = "Loading...", w.classList.add("color-fg-attention")
                        }
                        for (const k of b.querySelectorAll(".js-modify-button")) {
                            const D = `${d}_path`;
                            k.setAttribute("href", e[D]), t === "branch" && f !== "loading" ? k.hidden = k.getAttribute("data-state") !== f : k.hidden = !0
                        }
                    }
                    const l = n.querySelector("#init-row");
                    l.hidden = !e.init_section_exists, l.querySelector('.js-modify-button[data-state="failure"] button').textContent = l.querySelector('.js-modify-button[data-state="failure"]').getAttribute(e.init_exists ? "data-edit-text" : "data-add-text"), o.disabled = s
                }
                i($, "updateStackChecks"), (0, c.on)("change", ".js-release-stack #filter-list-branches", e => K(e.currentTarget)), (0, c.on)("change", ".js-release-stack #filter-list-tags", e => K(e.currentTarget)), (0, c.on)("change", ".js-release-stack #tag-list", e => K(e.currentTarget)), (0, j.N7)(".js-release-stack #filter-list-branches", function(e) {
                    K(e)
                });
                const _e = "<BRANCH>";

                function bt(e) {
                    const t = e.closest(".js-rename-branch-form");
                    let n = e.value;
                    const r = n !== e.defaultValue && n !== "",
                        o = t.querySelector(".js-rename-branch-autocheck-message");
                    if (o && r) {
                        let s = !1;
                        n = o.getAttribute("data-shell-safe-name") || _e, n.includes("<") && (s = !0);
                        for (const l of t.querySelectorAll(".js-rename-branch-new-name")) l.textContent = n;
                        n = o.getAttribute("data-shell-safe-name-with-remote") || `origin/${_e}`, n.includes("<") && (s = !0);
                        for (const l of t.querySelectorAll(".js-rename-branch-new-name-with-remote")) l.textContent = n;
                        const a = t.querySelector(".js-rename-branch-special-characters-documentation");
                        a && s && (a.hidden = !1, a.removeAttribute("aria-hidden"))
                    }
                }
                i(bt, "updateRenameInstructions"), (0, c.on)("auto-check-message-updated", ".js-rename-branch-input", function(e) {
                    const t = e.currentTarget;
                    bt(t)
                });
                const De = i(e => {
                        const t = document.querySelector(Ee);
                        if (t) {
                            const n = e.value.length === 0;
                            t.disabled = n
                        }
                    }, "toggleSubmit"),
                    Ee = 'form.js-protected-branch-settings button[type="submit"]';
                (0, j.N7)(Ee, {
                    add() {
                        const e = document.getElementById("rule_field");
                        e && (De(e), e.addEventListener("input", () => De(e)))
                    }
                }), (0, c.on)("change", ".js-template-repository-choice", function(e) {
                    const t = e.target,
                        n = t.checked && t.value !== "",
                        r = t.form;
                    r.querySelector(".js-repository-auto-init-options").classList.toggle("has-removed-contents", n);
                    const s = r.querySelectorAll(".js-template-repository-setting"),
                        a = r.querySelectorAll(".js-template-repository-name-display");
                    if (n) {
                        const d = t.closest(".js-template-repository-choice-container").querySelector(".js-template-repository-name"),
                            f = t.getAttribute("data-owner"),
                            b = r.querySelector(`.js-repository-owner-choice[value="${f}"]`);
                        if (b instanceof HTMLInputElement) b.checked = !0, (0, c.f)(b, "change");
                        else {
                            const w = r.querySelector(".js-repository-owner-choice.js-repository-owner-is-viewer");
                            w.checked = !0, (0, c.f)(w, "change")
                        }
                        for (const w of a) w.textContent = d.textContent
                    } else
                        for (const l of a) l.textContent = "";
                    for (const l of s) l.hidden = !n
                });
                var se = u(47142),
                    jt = u(10160),
                    vt = u(69567),
                    St = u(4687);
                const ae = (0, St.Z)(se.Gs);

                function wt(e) {
                    return encodeURIComponent(e).replaceAll("%2F", "/")
                }
                i(wt, "urlEncodeItem"), (0, z.w4)("keydown", ".js-tree-finder-field", e => {
                    e.key === "Escape" && (e.preventDefault(), history.back())
                }), (0, j.N7)(".js-tree-finder", e => {
                    const t = e.querySelector(".js-tree-finder-field"),
                        n = e.querySelector(".js-tree-finder-virtual-filter"),
                        r = e.querySelector(".js-tree-browser"),
                        o = e.querySelector(".js-tree-browser-results"),
                        s = e.querySelector(".js-tree-browser-result-template"),
                        a = new jt.Z(t, o);
                    n.filter = (l, d) => d === "" || (0, se.CD)(d, l) && ae(d, l) > 0, n.addEventListener("virtual-filter-input-filter", () => {
                        r.updating = "lazy"
                    }), n.addEventListener("virtual-filter-input-filtered", () => {
                        r.updating = "eager"
                    }), r.addEventListener("virtual-list-sort", l => {
                        l.preventDefault();
                        const d = t.value;
                        r.sort((f, b) => ae(d, b) - ae(d, f))
                    }), r.addEventListener("virtual-list-update", () => {
                        a.stop()
                    }), r.addEventListener("virtual-list-updated", () => {
                        a.start(), a.navigate()
                    }), r.addEventListener("virtual-list-render-item", l => {
                        if (!(l instanceof CustomEvent)) return;
                        const d = new vt.R(s, {
                                item: l.detail.item,
                                id: `entry-${Math.random().toString().substr(2,5)}`,
                                urlEncodedItem: wt(l.detail.item)
                            }),
                            f = d.querySelector("marked-text");
                        f && (f.positions = se.m7), l.detail.fragment.append(d)
                    }), r.querySelector("ul").hidden = !1, t.focus(), a.start()
                });
                var qt = u(57260);
                let W = null;
                const ie = new WeakMap;

                function At(e, t) {
                    const r = e.closest(".js-upload-manifest-file-container").querySelector(".js-upload-progress");
                    r.hidden = !1, e.classList.add("is-progress-bar");
                    const o = r.querySelector(".js-upload-meter-text"),
                        s = o.querySelector(".js-upload-meter-range-start");
                    s.textContent = String(t.uploaded() + 1);
                    const a = o.querySelector(".js-upload-meter-range-end");
                    a.textContent = String(t.size)
                }
                i(At, "showProgress");

                function xe(e) {
                    e.classList.remove("is-progress-bar");
                    const t = e.closest(".js-upload-manifest-file-container"),
                        n = t.querySelector(".js-upload-progress");
                    n.hidden = !0;
                    const r = t.querySelector(".js-upload-meter-text .js-upload-meter-filename");
                    r.textContent = ""
                }
                i(xe, "hideProgress"), (0, c.on)("file-attachment-accept", ".js-upload-manifest-file", function(e) {
                    const {
                        attachments: t
                    } = e.detail, n = parseInt(e.currentTarget.getAttribute("data-directory-upload-max-files") || "", 10);
                    t.length > n && (e.preventDefault(), e.currentTarget.classList.add("is-too-many"))
                }), (0, c.on)("document:drop", ".js-upload-manifest-tree-view", async function(e) {
                    const {
                        transfer: t
                    } = e.detail, n = e.currentTarget, r = await qt.P.traverse(t, !0), o = document.querySelector("#js-repo-pjax-container");
                    o.addEventListener("pjax:success", () => {
                        o.querySelector(".js-upload-manifest-file").attach(r)
                    }, {
                        once: !0
                    });
                    const s = n.getAttribute("data-drop-url");
                    (0, ve.ZP)({
                        url: s,
                        container: o
                    })
                }), (0, c.on)("upload:setup", ".js-upload-manifest-file", async function(e) {
                    const {
                        batch: t,
                        form: n,
                        preprocess: r
                    } = e.detail, o = e.currentTarget;
                    At(o, t);

                    function s() {
                        n.append("upload_manifest_id", ie.get(o))
                    }
                    if (i(s, "addInfo"), ie.get(o)) {
                        s();
                        return
                    }
                    if (W) {
                        r.push(W.then(s));
                        return
                    }
                    const l = o.closest(".js-upload-manifest-file-container").querySelector(".js-upload-manifest-form");
                    W = fetch(l.action, {
                        method: l.method,
                        body: new FormData(l),
                        headers: {
                            Accept: "application/json"
                        }
                    });
                    const [d, f] = kt();
                    r.push(d.then(s));
                    const b = await W;
                    if (!b.ok) return;
                    const w = await b.json(),
                        D = document.querySelector(".js-manifest-commit-form").elements.namedItem("manifest_id");
                    D.value = w.upload_manifest.id, ie.set(o, w.upload_manifest.id), W = null, f()
                });

                function kt() {
                    let e;
                    return [new Promise(n => {
                        e = n
                    }), e]
                }
                i(kt, "makeDeferred"), (0, c.on)("upload:start", ".js-upload-manifest-file", function(e) {
                    const {
                        attachment: t,
                        batch: n
                    } = e.detail, s = e.currentTarget.closest(".js-upload-manifest-file-container").querySelector(".js-upload-progress").querySelector(".js-upload-meter-text"), a = s.querySelector(".js-upload-meter-range-start");
                    a.textContent = n.uploaded() + 1;
                    const l = s.querySelector(".js-upload-meter-filename");
                    l.textContent = t.fullPath
                }), (0, c.on)("upload:complete", ".js-upload-manifest-file", function(e) {
                    const {
                        attachment: t,
                        batch: n
                    } = e.detail, o = document.querySelector(".js-manifest-commit-file-template").querySelector(".js-manifest-file-entry").cloneNode(!0), s = o.querySelector(".js-filename");
                    s.textContent = t.fullPath;
                    const a = t.id,
                        d = o.querySelector(".js-remove-manifest-file-form").elements.namedItem("file_id");
                    d.value = a;
                    const f = document.querySelector(".js-manifest-file-list");
                    f.hidden = !1, e.currentTarget.classList.add("is-file-list"), f.querySelector(".js-manifest-file-list-root").appendChild(o), n.isFinished() && xe(e.currentTarget)
                }), (0, c.on)("upload:progress", ".js-upload-manifest-file", function(e) {
                    const {
                        batch: t
                    } = e.detail, r = e.currentTarget.closest(".js-upload-manifest-file-container").querySelector(".js-upload-meter");
                    r.style.width = `${t.percent()}%`
                });

                function Pe(e) {
                    xe(e.currentTarget)
                }
                i(Pe, "upload_manifest_file_onerror"), (0, c.on)("upload:error", ".js-upload-manifest-file", Pe), (0, c.on)("upload:invalid", ".js-upload-manifest-file", Pe), (0, me.AC)(".js-remove-manifest-file-form", async function(e, t) {
                    await t.html();
                    const n = e.closest(".js-manifest-file-list-root");
                    if (e.closest(".js-manifest-file-entry").remove(), !n.hasChildNodes()) {
                        const o = n.closest(".js-manifest-file-list");
                        o.hidden = !0, document.querySelector(".js-upload-manifest-file").classList.remove("is-file-list")
                    }
                });
                async function Lt(e) {
                    const t = e.getAttribute("data-redirect-url");
                    try {
                        await (0, v.D)(e.getAttribute("data-poll-url")), window.location.href = t
                    } catch {
                        document.querySelector(".js-manifest-ready-check").hidden = !0, document.querySelector(".js-manifest-ready-check-failed").hidden = !1
                    }
                }
                i(Lt, "manifestReadyCheck"), (0, j.N7)(".js-manifest-ready-check", {
                    initialize(e) {
                        Lt(e)
                    }
                }), (0, c.on)("click", ".js-release-remove-file", function(e) {
                    const t = e.currentTarget.closest(".js-release-file");
                    t.classList.add("delete"), t.querySelector("input.destroy").value = "true"
                }), (0, c.on)("click", ".js-release-undo-remove-file", function(e) {
                    const t = e.currentTarget.closest(".js-release-file");
                    t.classList.remove("delete"), t.querySelector("input.destroy").value = ""
                });

                function Me(e) {
                    return e.closest("form").querySelector("#release_id").value
                }
                i(Me, "getReleaseId");
                let Z = null;
                (0, c.on)("release:saved", ".js-release-form", function(e) {
                    const t = e.currentTarget;
                    Z = null;
                    let n = !1;
                    for (const o of t.querySelectorAll(".js-releases-field .js-release-file")) o.classList.contains("delete") ? o.remove() : o.classList.contains("js-template") || (n = !0);
                    const r = t.querySelector(".js-releases-field");
                    r.classList.toggle("not-populated", !n), r.classList.toggle("is-populated", n)
                });

                function Oe(e, t) {
                    t.append("release_id", Me(e));
                    const n = Array.from(document.querySelectorAll(".js-releases-field .js-release-file.delete .id"));
                    if (n.length) {
                        const r = n.map(o => o.value);
                        t.append("deletion_candidates", r.join(","))
                    }
                }
                i(Oe, "addInfo"), (0, c.on)("upload:setup", ".js-upload-release-file", function(e) {
                    const {
                        form: t,
                        preprocess: n
                    } = e.detail, r = e.currentTarget;
                    if (Me(r)) {
                        Oe(r, t);
                        return
                    }
                    if (!Z) {
                        const s = document.querySelector(".js-save-draft");
                        Z = Se(s)
                    }
                    const o = Oe.bind(null, r, t);
                    n.push(Z.then(o))
                }), (0, c.on)("upload:start", ".js-upload-release-file", function(e) {
                    const t = e.detail.policy;
                    e.currentTarget.querySelector(".js-upload-meter").classList.remove("d-none");
                    const r = t.asset.replaced_asset;
                    if (!!r)
                        for (const o of document.querySelectorAll(".js-releases-field .js-release-file .id")) Number(o.value) === r && o.closest(".js-release-file").remove()
                }), (0, c.on)("upload:complete", ".js-upload-release-file", function(e) {
                    var t;
                    const {
                        attachment: n
                    } = e.detail, r = document.querySelector(".js-releases-field"), o = r.querySelector(".js-template").cloneNode(!0);
                    o.classList.remove("d-none", "js-template"), o.querySelector("input.id").value = n.id;
                    const s = n.name || n.href.split("/").pop();
                    for (const d of r.querySelectorAll(".js-release-file"))((t = d.querySelector(".js-release-asset-filename")) == null ? void 0 : t.value) === s && d.getAttribute("data-state") === "starter" && d.remove();
                    for (const d of o.querySelectorAll(".js-release-asset-filename")) d instanceof HTMLInputElement ? d.value = s : d.textContent = s;
                    const a = `(${(n.file.size/(1024*1024)).toFixed(2)} MB)`;
                    o.querySelector(".js-release-asset-filesize").textContent = a, o.setAttribute("data-state", "uploaded"), r.appendChild(o), r.classList.remove("not-populated"), r.classList.add("is-populated"), e.currentTarget.querySelector(".js-upload-meter").classList.add("d-none")
                }), (0, c.on)("upload:progress", ".js-upload-release-file", function(e) {
                    const {
                        attachment: t
                    } = e.detail, n = e.currentTarget.querySelector(".js-upload-meter");
                    n.style.width = `${t.percent}%`
                });
                var Ct = u(27925),
                    It = Object.defineProperty,
                    Tt = Object.getOwnPropertyDescriptor,
                    Ne = i((e, t, n, r) => {
                        for (var o = r > 1 ? void 0 : r ? Tt(t, n) : t, s = e.length - 1, a; s >= 0; s--)(a = e[s]) && (o = (r ? a(t, n, o) : a(o)) || o);
                        return r && o && It(t, n, o), o
                    }, "repo_codespaces_count_element_decorateClass");
                let ce = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.count = 0
                    }
                    connectedCallback() {
                        (0, j.N7)("get-repo", {
                            constructor: Ct.b,
                            add: e => {
                                this.handleGetRepoElement(e)
                            }
                        })
                    }
                    handleGetRepoElement(e) {
                        !e.openOrCreateInCodespace || (this.count === 0 ? e.showOpenOrCreateInCodespace() : e.removeOpenOrCreateInCodespace())
                    }
                }, "RepoCodespacesCountElement");
                Ne([m.Lj], ce.prototype, "count", 2), ce = Ne([m.Ih], ce);
                var Mt = u(9115),
                    Ot = u(68906),
                    Nt = u(63355)
            }
        },
        L => {
            var C = i(m => L(L.s = m), "__webpack_exec__");
            L.O(0, [5724, 90, 6813, 6637, 3682, 6791], () => C(15820));
            var u = L.O()
        }
    ]);
})();

//# sourceMappingURL=repositories-b6c745df7c5a.js.map