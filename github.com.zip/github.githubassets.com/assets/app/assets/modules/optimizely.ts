import {createInstance} from './github/optimizely'
import {getCookies} from './github/cookies'
import {getOrCreateClientId} from '@github/hydro-analytics-client'
// eslint-disable-next-line no-restricted-imports
import {observe} from 'selector-observer'
// eslint-disable-next-line no-restricted-imports
import {on} from 'delegated-events'

type Client = import('@optimizely/optimizely-sdk').Client
let optimizely: Client
;(async function () {
  optimizely = createInstance()
  // onReady() is needed when you use an sdk key in createInstance() to initialize, right now we only use the datafile,
  // so the returned Promise will resolve immediately.
  // Since createInstance() can by sync/async depending on how to initialize
  // we are keeping this all in an async call and onReady() so we are prepared for either case.
  await optimizely.onReady()
})()

function camelCase(input: string) {
  return input.toLowerCase().replace(/-(.)/g, function (_match, group1) {
    return group1.toUpperCase()
  })
}

// collect all data-optimizely-meta-* attributes into an object
// that can be passed along when calling optimizely.track()
export function getUserAttributes(element: HTMLElement): {[key: string]: string} {
  const userAttributes: {[key: string]: string} = {}

  for (const {name, value} of element.attributes) {
    if (name.startsWith('data-optimizely-meta-')) {
      const key = name.replace('data-optimizely-meta-', '')
      if (value && value.trim().length) {
        userAttributes[camelCase(key)] = value
      }
    }
  }

  return userAttributes
}

// Track an event with Optimizely
// Usage: add a 'data-optimizely-event' attribute to the element you want to track with the event
// key and user analytics_tracking_id.
//
// Example for a logged-in experiment:
//  <a data-optimizely-event="click.global_header.your_organizations, <%= current_user.analytics_tracking_id %>"
//     href="/settings/organizations">Your Organizations</a>
//
// Example for a logged-out experiment on a non-cached page:
//  <a data-optimizely-event="click.global_header.your_organizations, <%= current_visitor.unversioned_octolytics_id %>"
//     href="/settings/organizations">Your Organizations</a>
//
// Example for a logged-out experiment on a cached page:
//  <a data-optimizely-event="click.global_header.your_organizations"
//     href="/settings/organizations">Your Organizations</a>
//
on('click', '[data-optimizely-event]', function (event) {
  if (!optimizely) return

  const element = event.currentTarget as HTMLElement
  const optimizelyEvent = element.getAttribute('data-optimizely-event') || ''
  const [key, userId] = optimizelyEvent.trim().split(/\s*,\s*/)
  const userAttributes = getUserAttributes(element)

  if (key && userId) {
    optimizely.track(key, userId, userAttributes)
  } else if (key) {
    optimizely.track(key, getOrCreateClientId(), userAttributes)
  }
})

// Activate an optimizely experiment on page load and display the enabled variation
// Usage:
//   * Add a 'data-optimizely-experiment' attribute with the experiment key to the element that
//     contains the different experiment variations.
//   * Add a 'data-optimizely-variation' attribute with the variation key to each variation element.
//     Mark the control (e.g. the default) variation as visible, and all other variations as hidden.
//   * Add 'data-optimizely-meta-* attributes to the element so it can be sent to Optimizely when
//     the experiment is activated.
//
// Example:
//   <div data-optimizely-experiment="my_experiment" data-optimizely-meta-user-country="US">
//     <div data-optimizely-variation="control"></div>
//     <div data-optimizely-variation="variation1" hidden></div>
//     <div data-optimizely-variation="variation2" hidden></div>
//   </div>

observe('[data-optimizely-experiment]', container => {
  if (!optimizely) return

  const experimentKey = container.getAttribute('data-optimizely-experiment')
  // return if no experiment key provided or if the experiment container is not visible
  // e.g. if the experiment container is a dismissible prompt, it might be hidden if the user
  // previously dismissed it
  if (!experimentKey || (container as HTMLElement).hidden) return

  const userAttributes = getUserAttributes(container as HTMLElement)
  const enabledVariationKey = optimizely.activate(experimentKey, getOrCreateClientId(), userAttributes)
  // return if not enrolled in the experiment and leave the default variation visible
  if (!enabledVariationKey) return

  const variations = container.querySelectorAll<HTMLElement>('[data-optimizely-variation]')
  for (const variation of variations) {
    const variationKey = variation.getAttribute('data-optimizely-variation')
    variation.hidden = !(variationKey === enabledVariationKey)
  }
})

// BEGIN KOREAN HOMEPAGE TRANSLATION EXPERIMENT
// https://github.com/github/international-expansion/issues/126
// https://app.optimizely.com/v2/projects/16737760170/experiments/20121990335

// Look for a cookie set by varnish-iris-sidecar
const homepageLanguages =
  document.querySelector('meta[name="enabled-homepage-translation-languages"]')?.getAttribute('content')?.split(',') ||
  []
const enrolledInKoreanHomepageExperiment =
  getCookies('_locale_experiment').length > 0 &&
  getCookies('_locale_experiment')[0].value === 'ko' &&
  homepageLanguages.includes('ko')

if (enrolledInKoreanHomepageExperiment && window.location.pathname === '/') runKoreanHomepageExperiment()
if (enrolledInKoreanHomepageExperiment && window.location.pathname === '/join') trackSignupsFromKoreanHomepage()

async function runKoreanHomepageExperiment() {
  const experimentKey = 'ko_homepage_translation'
  const userId = getOrCreateClientId()
  const variationKey = getCookies('_locale')[0]?.value?.slice(0, 2) // en or ko

  optimizely.setForcedVariation(experimentKey, userId, variationKey)
  optimizely.activate(experimentKey, userId)

  // hide or show control and candidate elements dependending on current variation
  const variations = document.querySelectorAll<HTMLElement>('[data-optimizely-variation]')
  for (const variation of variations) {
    variation.hidden = variationKey !== variation.getAttribute('data-optimizely-variation')
  }

  for (const element of document.querySelectorAll<HTMLElement>('form[action^="/join"]')) {
    element.addEventListener('submit', () => {
      optimizely.track('submit.homepage_signup', userId)
    })
  }

  for (const element of document.querySelectorAll<HTMLElement>('a[href^="/join"]')) {
    element.addEventListener('click', () => {
      optimizely.track('click.homepage_signup', userId)
    })
  }
}

async function trackSignupsFromKoreanHomepage() {
  document.getElementById('signup-form')?.addEventListener('submit', () => {
    const experimentKey = 'ko_homepage_translation'
    const userId = getOrCreateClientId()
    optimizely.activate(experimentKey, userId)
    optimizely.track('submit.create_account', userId)
  })
}

// END KOREAN HOMEPAGE TRANSLATION EXPERIMENT

// BEGIN LOCAL CURRENCY PRICING EXPERIMENT
// https://app.optimizely.com/v2/projects/16737760170/experiments/20047736562

const currencyVariantMetaTag = document.querySelector<HTMLElement>('meta[name^="user-currency"]')
const enrolledInCurrencyExperiment = currencyVariantMetaTag && window.location.pathname === '/pricing'
if (enrolledInCurrencyExperiment) runCurrencyExperiment()

async function runCurrencyExperiment() {
  const supportedCurrencies =
    document.querySelector<HTMLElement>('meta[name^="supported-currencies"]')?.getAttribute('content')?.split(',') || []
  const experimentKey = 'local_currency_pricing'
  const viewEventKey = 'view.pricing_page'
  const controlVariationKey = 'usd'
  const candidateVariationKey = 'localized_currency'
  const userId = getOrCreateClientId()
  const requestedCurrency = currencyVariantMetaTag?.getAttribute('content')?.toUpperCase()
  const queryParams = new URLSearchParams(window.location.search)

  if (requestedCurrency === 'USD') return
  if (!requestedCurrency) return
  if (!supportedCurrencies.includes(requestedCurrency)) return

  // force user into candidate arm if `?currency=XXX` query param is set
  if (queryParams.has('currency')) {
    optimizely.setForcedVariation(experimentKey, userId, candidateVariationKey)
  }

  // activate the experiment. THIS is where bucketing happens
  // variation will either be 'localized_currency' or 'usd'
  const variation = optimizely.activate(experimentKey, userId)

  // display USD or user-requested currency, depending on experiment variation
  const displayedCurrency = variation === controlVariationKey ? 'USD' : requestedCurrency

  // track the currency code as users are enrolled in the experiment
  optimizely.track(viewEventKey, userId, {requestedCurrency})

  // if user is bucketed into the candidate arm display local currency
  // TODO: REMOVE BELOW
  // if (variation === candidateVariationKey) {
  for (const element of document.querySelectorAll<HTMLElement>('[data-currency]')) {
    element.hidden = element.getAttribute('data-currency') !== displayedCurrency
  }
  // }
}

// Track submission of the Create Account Form for users from the pricing page currency experiment
on('click', '#signup_button', function () {
  if (!optimizely) return
  if (!currencyVariantMetaTag) return

  // If user is from the pricing page and was enrolled into experiment
  const queryParams = new URLSearchParams(document.location.href)
  const isPricingExperiment = queryParams.get('pricing_exp') && queryParams.get('ref_page')?.startsWith('/pricing')
  if (!isPricingExperiment) return

  const optimizelyEvent = 'submit.create_account'
  const requestedCurrency = currencyVariantMetaTag?.getAttribute('content')?.toUpperCase()

  optimizely.track(optimizelyEvent, getOrCreateClientId(), {requestedCurrency})
})

// END LOCAL CURRENCY PRICING EXPERIMENT

// BEGIN TEST EXPERIMENT
// Test experiment used to test updates to the client-side optimizely integration
// in development, review-lab, and production
if (window.location.pathname === '/settings/profile') runTestExperiment()
async function runTestExperiment() {
  if (!optimizely) return

  const userId = getOrCreateClientId()

  optimizely.activate('test_experiment', userId)
  optimizely.track('test_event', userId)
}
// END TEST EXPERIMENT
