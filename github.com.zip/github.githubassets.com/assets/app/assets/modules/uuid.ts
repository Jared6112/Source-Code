declare global {
  interface Crypto {
    randomUUID: () => string
  }
}

export function v4() {
  return crypto.randomUUID()
}
