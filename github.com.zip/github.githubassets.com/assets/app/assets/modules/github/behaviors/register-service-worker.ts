import {ready} from '../document-ready'
;(async function () {
  if ('serviceWorker' in navigator) {
    await ready
    const serviceWorkerPath = document.querySelector<HTMLLinkElement>('link[rel="service-worker-src"]')?.href
    if (serviceWorkerPath) {
      navigator.serviceWorker.register(serviceWorkerPath, {scope: '/'})
    } else {
      await unregisterAllServiceWorkers()
    }
  }
})()

async function unregisterAllServiceWorkers() {
  let registrations: readonly ServiceWorkerRegistration[] = []
  try {
    registrations = await navigator.serviceWorker.getRegistrations()
  } catch (error) {
    if (error.name === 'SecurityError') return
  }

  for (const registration of registrations) {
    registration.unregister()
  }
}
