import {JumpToItem} from './jump-to-item'
import {serverDefinedItem} from './server-defined-item'

@serverDefinedItem
export class JumpToOrgItem extends JumpToItem {}
