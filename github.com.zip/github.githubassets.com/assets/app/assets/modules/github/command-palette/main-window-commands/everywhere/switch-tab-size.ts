import {MainWindowCommand, MainWindowGlobalCommand} from '../../main-window-command'
import CommandPalette from '../../command-palette-element'
import {MainWindowCommandItem} from '../../items/main-window-command-item'
import {StaticItemsPage} from '@github/command-palette-api'

/**
 * Allow users to configure their tab size rendering preference.
 * Valid values are 2, 3, 4, 6, 8, 10, and 12
 *
 */
class TabSizeTwo extends MainWindowCommand {
  /** overrides MainWindowCommand */
  title = '2 spaces'
  iconType = 'none'

  /** used when persisting the new setting and when updating the DOM.
   * override this for each value.*/
  tabSize = '2'

  async run(commandPalette: CommandPalette) {
    this.updateTabSize()
    this.saveSettings(commandPalette)
  }

  /**
   * Updates all the `[data-tab-size]` attributes we can find in the DOM to reflect
   * tabSize
   */
  updateTabSize() {
    const targets = document.querySelectorAll('[data-tab-size]')
    for (const target of targets) {
      target.setAttribute('data-tab-size', this.tabSize)
    }
  }

  async saveSettings(commandPalette: CommandPalette) {
    const csrfToken = document.querySelector<HTMLInputElement>('.js-tab-size-csrf')!.value
    const path = document.querySelector<HTMLInputElement>('.js-tab-size-path')!.value
    const formData = new FormData()

    formData.set('tab_size_rendering_preference', this.tabSize)

    // eslint-disable-next-line i18n-text/no-en
    const errorMessage = 'Failed to save tab size preference'

    try {
      const response = await fetch(path, {
        method: 'PUT',
        body: formData,
        mode: 'same-origin',
        headers: {
          'Scoped-CSRF-Token': csrfToken,
          'X-Requested-With': 'XMLHttpRequest'
        }
      })
      if (response.ok) {
        // eslint-disable-next-line i18n-text/no-en
        commandPalette.displayFlash('success', 'Tab size rendering updated')
      } else {
        commandPalette.displayFlash('error', errorMessage)
      }
    } catch {
      commandPalette.displayFlash('error', errorMessage)
    }
  }
}
class TabSizeThree extends TabSizeTwo {
  title = '3 spaces'
  tabSize = '3'
}
class TabSizeFour extends TabSizeTwo {
  title = '4 spaces'
  tabSize = '4'
}
class TabSizeSix extends TabSizeTwo {
  title = '6 spaces'
  tabSize = '6'
}
class TabSizeEight extends TabSizeTwo {
  title = '8 spaces'
  tabSize = '8'
}
class TabSizeTen extends TabSizeTwo {
  title = '10 spaces'
  tabSize = '10'
}
class TabSizeTwelve extends TabSizeTwo {
  title = '12 spaces'
  tabSize = '12'
}

export class SwitchTabSize extends MainWindowGlobalCommand {
  title = 'Change tab size rendering'
  icon = 'gear-color-fg-muted'
  priority = 10
  dismissAfterRun = false

  run(commandPalette: CommandPalette) {
    commandPalette.pushPage(new StaticItemsPage(this.title, 'tab-sizes', this.pageItems))
  }

  get pageItems(): MainWindowCommandItem[] {
    return [TabSizeTwo, TabSizeThree, TabSizeFour, TabSizeSix, TabSizeEight, TabSizeTen, TabSizeTwelve].map(command =>
      command.item()
    )
  }
}
