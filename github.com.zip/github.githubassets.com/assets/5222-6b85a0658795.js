"use strict";
(() => {
    var z = Object.defineProperty;
    var p = (D, L) => z(D, "name", {
        value: L,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [5222], {
            77546: (D, L, m) => {
                m.d(L, {
                    z: () => C
                });
                var h = m(59753),
                    M = m(51374),
                    T = m(52660),
                    O = m(86404),
                    A = m(78694),
                    v = m(64463),
                    u = m(65935),
                    E = m(74136);
                let r = [];
                (0, v.N7)(".js-comment-header-actions-deferred-include-fragment", {
                    subscribe: e => (0, O.RB)(e, "loadstart", () => {
                        const t = e.closest(".js-comment");
                        d(t)
                    }, {
                        capture: !1,
                        once: !0
                    })
                }), (0, v.N7)(".js-comment .contains-task-list", {
                    add: e => {
                        const t = e.closest(".js-comment");
                        d(t)
                    }
                }), (0, h.on)("click", ".js-comment-edit-button", function(e) {
                    const t = e.currentTarget.closest(".js-comment");
                    t.classList.add("is-comment-editing");
                    const o = g(t);
                    o ? o.addEventListener("include-fragment-replaced", () => s(t), {
                        once: !0
                    }) : s(t);
                    const n = e.currentTarget.closest(".js-dropdown-details");
                    n && n.removeAttribute("open")
                });

                function s(e) {
                    e.querySelector(".js-write-tab").click();
                    const t = e.querySelector(".js-comment-field");
                    t.focus(), (0, h.f)(t, "change")
                }
                p(s, "focusEditForm");

                function g(e) {
                    return e.querySelector(".js-comment-edit-form-deferred-include-fragment")
                }
                p(g, "findEditFormDeferredIncludeFragment");

                function d(e) {
                    var t;
                    (t = g(e)) == null || t.setAttribute("loading", "eager")
                }
                p(d, "loadEditFormDeferredIncludeFragment"), (0, h.on)("click", ".js-comment-hide-button", function(e) {
                    const t = e.currentTarget.closest(".js-comment");
                    f(t, !1);
                    const o = t.querySelector(".js-minimize-comment");
                    o && o.classList.remove("d-none");
                    const n = e.currentTarget.closest(".js-dropdown-details");
                    n && n.removeAttribute("open")
                }), (0, h.on)("click", ".js-comment-hide-minimize-form", function(e) {
                    e.currentTarget.closest(".js-minimize-comment").classList.add("d-none")
                });

                function C(e) {
                    const t = e.currentTarget.closest("form"),
                        o = e.currentTarget.getAttribute("data-confirm-text");
                    if ((0, A.T)(t) && !confirm(o)) return !1;
                    for (const i of t.querySelectorAll("input, textarea")) {
                        const a = i;
                        a.value = a.defaultValue, a.classList.contains("session-resumable-canceled") && (a.classList.add("js-session-resumable"), a.classList.remove("session-resumable-canceled"))
                    }
                    const n = e.currentTarget.closest(".js-comment");
                    return n && n.classList.remove("is-comment-editing"), !0
                }
                p(C, "handleCommentCancelButtonClick"), (0, h.on)("click", ".js-comment-cancel-button", C), (0, h.on)("click", ".js-cancel-issue-edit", function(e) {
                    const t = e.currentTarget.closest(".js-details-container");
                    t.querySelector(".js-comment-form-error").hidden = !0
                }), (0, u.AC)(".js-comment-delete, .js-comment .js-comment-update, .js-issue-update, .js-comment-minimize, .js-comment-unminimize", function(e, t, o) {
                    const n = e.closest(".js-comment");
                    n.classList.add("is-comment-loading");
                    const i = n.getAttribute("data-body-version");
                    i && o.headers.set("X-Body-Version", i)
                }), (0, u.AC)(".js-comment .js-comment-update", async function(e, t) {
                    let o;
                    const n = e.closest(".js-comment"),
                        i = n.querySelector(".js-comment-update-error"),
                        a = n.querySelector(".js-comment-body-error");
                    i instanceof HTMLElement && (i.hidden = !0), a instanceof HTMLElement && (a.hidden = !0), r = [];
                    try {
                        o = await t.json()
                    } catch (b) {
                        if (b.response.status === 422) {
                            const j = JSON.parse(b.response.text);
                            if (j.errors) {
                                i instanceof HTMLElement && (i.textContent = `There was an error posting your comment: ${j.errors.join(", ")}`, i.hidden = !1);
                                return
                            }
                        } else throw b
                    }
                    if (!o) return;
                    const l = o.json;
                    l.errors && l.errors.length > 0 && (r = l.errors, c(a));
                    const q = n.querySelector(".js-comment-body");
                    q && l.body && (q.innerHTML = l.body), n.setAttribute("data-body-version", l.newBodyVersion);
                    const _ = n.querySelector(".js-body-version");
                    _ instanceof HTMLInputElement && (_.value = l.newBodyVersion);
                    const y = n.querySelector(".js-discussion-poll");
                    y && l.poll && (y.innerHTML = l.poll);
                    for (const b of n.querySelectorAll("input, textarea")) {
                        const j = b;
                        j.defaultValue = j.value
                    }
                    n.classList.remove("is-comment-stale", "is-comment-editing");
                    const S = n.querySelector(".js-comment-edit-history");
                    if (S) {
                        const b = await (0, T.a)(document, l.editUrl);
                        S.innerHTML = "", S.append(b)
                    }
                }), (0, v.N7)(".js-comment-body-error", {
                    add: e => {
                        r && r.length > 0 && c(e)
                    }
                });

                function c(e) {
                    const t = e.querySelector("ol");
                    if (t) {
                        t.innerHTML = "";
                        const o = r.map(n => {
                            const i = document.createElement("li");
                            return i.textContent = n, i
                        });
                        for (const n of o) t.appendChild(n)
                    }
                    e.hidden = !1
                }
                p(c, "showBodyErrors"), (0, u.AC)(".js-comment .js-comment-delete, .js-comment .js-comment-update, .js-comment-minimize, .js-comment-unminimize", async function(e, t) {
                    const o = e.closest(".js-comment");
                    try {
                        await t.text()
                    } catch (n) {
                        if (n.response.status === 422) {
                            let i;
                            try {
                                i = JSON.parse(n.response.text)
                            } catch {}
                            i && i.stale && o.classList.add("is-comment-stale")
                        } else throw n
                    }
                    o.classList.remove("is-comment-loading")
                });

                function f(e, t) {
                    const o = e.querySelector(".js-comment-show-on-error");
                    o && (o.hidden = !t);
                    const n = e.querySelector(".js-comment-hide-on-error");
                    n && (n.hidden = t)
                }
                p(f, "toggleMinimizeError"), (0, u.AC)(".js-timeline-comment-unminimize, .js-timeline-comment-minimize", async function(e, t) {
                    const o = e.closest(".js-minimize-container");
                    try {
                        const n = await t.html();
                        o.replaceWith(n.html)
                    } catch {
                        f(o, !0)
                    }
                }), (0, u.AC)(".js-discussion-comment-unminimize, .js-discussion-comment-minimize", async function(e, t) {
                    const o = e.closest(".js-discussion-comment"),
                        n = o.querySelector(".js-discussion-comment-error");
                    n && (n.hidden = !0);
                    try {
                        const i = await t.html();
                        o.replaceWith(i.html)
                    } catch (i) {
                        if (i.response.status >= 400 && i.response.status < 500) {
                            if (i.response.html) {
                                const a = i.response.html.querySelector(".js-discussion-comment").getAttribute("data-error");
                                n instanceof HTMLElement && (n.textContent = a, n.hidden = !1)
                            }
                        } else throw i
                    }
                }), (0, u.AC)(".js-comment-delete", async function(e, t) {
                    await t.json();
                    let o = e.closest(".js-comment-delete-container");
                    o || (o = e.closest(".js-comment-container") || e.closest(".js-line-comments"), o && o.querySelectorAll(".js-comment").length !== 1 && (o = e.closest(".js-comment"))), o.remove()
                }), (0, u.AC)(".js-issue-update", async function(e, t) {
                    var o, n, i;
                    const a = e.closest(".js-details-container"),
                        l = a.querySelector(".js-comment-form-error");
                    let q;
                    try {
                        q = await t.json()
                    } catch (y) {
                        l.textContent = ((i = (n = (o = y.response) == null ? void 0 : o.json) == null ? void 0 : n.errors) == null ? void 0 : i[0]) || "Something went wrong. Please try again.", l.hidden = !1
                    }
                    if (!q) return;
                    a.classList.remove("open"), l.hidden = !0;
                    const _ = q.json;
                    if (_.issue_title != null) {
                        a.querySelector(".js-issue-title").textContent = _.issue_title;
                        const y = a.closest(".js-issues-results");
                        if (y) {
                            if (y.querySelector(".js-merge-pr.is-merging")) {
                                const j = y.querySelector(".js-merge-pull-request textarea");
                                j instanceof HTMLTextAreaElement && j.value === j.defaultValue && (j.value = j.defaultValue = _.issue_title)
                            } else if (y.querySelector(".js-merge-pr.is-squashing")) {
                                const j = y.querySelector(".js-merge-pull-request .js-merge-title");
                                j instanceof HTMLInputElement && j.value === j.defaultValue && (j.value = j.defaultValue = _.default_squash_commit_title)
                            }
                            const S = y.querySelector("button[value=merge]");
                            S && S.setAttribute("data-input-message-value", _.issue_title);
                            const b = y.querySelector("button[value=squash]");
                            b && b.setAttribute("data-input-title-value", _.default_squash_commit_title)
                        }
                    }
                    document.title = _.page_title;
                    for (const y of e.elements)(y instanceof HTMLInputElement || y instanceof HTMLTextAreaElement) && (y.defaultValue = y.value)
                }), (0, u.AC)(".js-comment-minimize", async function(e, t) {
                    await t.json();
                    const o = e.closest(".js-comment"),
                        n = o.querySelector(".js-minimize-comment");
                    if (n && n.classList.contains("js-update-minimized-content")) {
                        const i = e.querySelector("input[type=submit], button[type=submit]");
                        i && i.classList.add("disabled");
                        const a = o.closest(".js-comment-container");
                        a && await (0, E.x0)(a)
                    } else {
                        n && n.classList.add("d-none");
                        const i = e.closest(".unminimized-comment");
                        i.classList.add("d-none"), i.classList.remove("js-comment");
                        const l = e.closest(".js-minimizable-comment-group").querySelector(".minimized-comment");
                        l && l.classList.remove("d-none"), l && l.classList.add("js-comment")
                    }
                }), (0, u.AC)(".js-comment-unminimize", async function(e, t) {
                    await t.json();
                    const o = e.closest(".js-minimizable-comment-group"),
                        n = o.querySelector(".unminimized-comment"),
                        i = o.querySelector(".minimized-comment");
                    if (n) n.classList.remove("d-none"), n.classList.add("js-comment"), i && i.classList.add("d-none"), i && i.classList.remove("js-comment");
                    else {
                        if (i) {
                            const l = i.querySelector(".timeline-comment-actions");
                            l && l.classList.add("d-none"), i.classList.remove("js-comment")
                        }
                        const a = o.closest(".js-comment-container");
                        await (0, E.x0)(a)
                    }
                }), (0, h.on)("details-menu-select", ".js-comment-edit-history-menu", e => {
                    const t = e.detail.relatedTarget.getAttribute("data-edit-history-url");
                    if (!t) return;
                    e.preventDefault();
                    const o = (0, T.a)(document, t);
                    (0, M.W)({
                        content: o,
                        dialogClass: "Box-overlay--wide"
                    })
                }, {
                    capture: !0
                })
            },
            90087: (D, L, m) => {
                m.d(L, {
                    G: () => E
                });
                var h = m(84570),
                    M = m(64463),
                    T = m(59753);
                const O = ["input[pattern]", "input[required]", "textarea[required]", "input[data-required-change]", "textarea[data-required-change]", "input[data-required-value]", "textarea[data-required-value]"].join(",");

                function A(r) {
                    const s = r.getAttribute("data-required-value"),
                        g = r.getAttribute("data-required-value-prefix");
                    if (r.value === s) r.setCustomValidity("");
                    else {
                        let d = s;
                        g && (d = g + d), r.setCustomValidity(d)
                    }
                }
                p(A, "checkValidityForRequiredValueField"), (0, h.q6)("[data-required-value]", function(r) {
                    const s = r.currentTarget;
                    A(s)
                }), (0, T.on)("change", "[data-required-value]", function(r) {
                    const s = r.currentTarget;
                    A(s), E(s.form)
                }), (0, h.q6)("[data-required-trimmed]", function(r) {
                    const s = r.currentTarget;
                    s.value.trim() === "" ? s.setCustomValidity(s.getAttribute("data-required-trimmed")) : s.setCustomValidity("")
                }), (0, T.on)("change", "[data-required-trimmed]", function(r) {
                    const s = r.currentTarget;
                    s.value.trim() === "" ? s.setCustomValidity(s.getAttribute("data-required-trimmed")) : s.setCustomValidity(""), E(s.form)
                }), (0, h.ZG)(O, r => {
                    let s = r.checkValidity();

                    function g() {
                        const d = r.checkValidity();
                        d !== s && r.form && E(r.form), s = d
                    }
                    p(g, "inputHandler"), r.addEventListener("input", g), r.addEventListener("blur", p(function d() {
                        r.removeEventListener("input", g), r.removeEventListener("blur", d)
                    }, "blurHandler"))
                });
                const v = new WeakMap;

                function u(r) {
                    v.get(r) || (r.addEventListener("change", () => E(r)), v.set(r, !0))
                }
                p(u, "installHandlers");

                function E(r) {
                    const s = r.checkValidity();
                    for (const g of r.querySelectorAll("button[data-disable-invalid]")) g.disabled = !s
                }
                p(E, "validate"), (0, M.N7)("button[data-disable-invalid]", {
                    constructor: HTMLButtonElement,
                    initialize(r) {
                        const s = r.form;
                        s && (u(s), r.disabled = !s.checkValidity())
                    }
                }), (0, M.N7)("input[data-required-change], textarea[data-required-change]", function(r) {
                    const s = r,
                        g = s.type === "radio" && s.form ? s.form.elements.namedItem(s.name).value : null;

                    function d(C) {
                        const c = s.form;
                        if (C && s.type === "radio" && c && g)
                            for (const f of c.elements.namedItem(s.name)) f instanceof HTMLInputElement && f.setCustomValidity(s.value === g ? "unchanged" : "");
                        else s.setCustomValidity(s.value === (g || s.defaultValue) ? "unchanged" : "")
                    }
                    p(d, "customValidity"), s.addEventListener("input", d), s.addEventListener("change", d), d(), s.form && E(s.form)
                }), document.addEventListener("reset", function(r) {
                    if (r.target instanceof HTMLFormElement) {
                        const s = r.target;
                        setTimeout(() => E(s))
                    }
                })
            },
            74136: (D, L, m) => {
                m.d(L, {
                    H5: () => E,
                    Of: () => g,
                    x0: () => s,
                    z8: () => r
                });
                var h = m(78694),
                    M = m(64463),
                    T = m(10900),
                    O = m(96776),
                    A = m(40728);
                const v = new WeakMap,
                    u = {};

                function E() {
                    for (const f of Object.keys(u)) delete u[f];
                    const c = history.state || {};
                    c.staleRecords = u, (0, A.lO)(c, "", location.href), window.location.reload()
                }
                p(E, "reload");

                function r() {
                    if (Object.keys(u).length > 0) {
                        const c = history.state || {};
                        c.staleRecords = u, (0, A.lO)(c, "", location.href)
                    }
                }
                p(r, "registerStaleRecords");
                async function s(c) {
                    if (v.get(c)) return;
                    const f = c.hasAttribute("data-retain-focus"),
                        e = c.getAttribute("data-url");
                    if (!e) throw new Error("could not get url");
                    const t = new AbortController;
                    v.set(c, t);
                    try {
                        const o = await fetch(e, {
                            signal: t.signal,
                            headers: {
                                Accept: "text/html",
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        });
                        if (!o.ok) return;
                        const n = await o.text();
                        if ((0, h.M)(c, f)) {
                            console.warn("Failed to update content with interactions", c);
                            return
                        }
                        return u[e] = n, d(c, n, f)
                    } catch {} finally {
                        v.delete(c)
                    }
                }
                p(s, "updateContent");
                async function g(c, f, e = !1) {
                    const t = v.get(c);
                    t == null || t.abort();
                    const o = c.closest(".js-updatable-content[data-url], .js-updatable-content [data-url]");
                    return !e && o && o === c && (u[o.getAttribute("data-url") || ""] = f), d(c, f)
                }
                p(g, "replaceContent");

                function d(c, f, e = !1) {
                    return (0, O._8)(document, () => {
                        const t = (0, T.r)(document, f.trim()),
                            o = e && c.ownerDocument && c === c.ownerDocument.activeElement ? t.querySelector("*") : null,
                            n = Array.from(c.querySelectorAll("details[open][id]")).map(i => i.id);
                        c.tagName === "DETAILS" && c.id && c.hasAttribute("open") && n.push(c.id);
                        for (const i of c.querySelectorAll(".js-updatable-content-preserve-scroll-position")) {
                            const a = i.getAttribute("data-updatable-content-scroll-position-id") || "";
                            C.set(a, i.scrollTop)
                        }
                        for (const i of n) {
                            const a = t.querySelector(`#${i}`);
                            a && a.setAttribute("open", "")
                        }
                        c.replaceWith(t), o instanceof HTMLElement && o.focus()
                    })
                }
                p(d, "replace");
                const C = new Map;
                (0, M.N7)(".js-updatable-content-preserve-scroll-position", {
                    constructor: HTMLElement,
                    add(c) {
                        const f = c.getAttribute("data-updatable-content-scroll-position-id");
                        if (!f) return;
                        const e = C.get(f);
                        e != null && (c.scrollTop = e)
                    }
                })
            }
        }
    ]);
})();

//# sourceMappingURL=5222-194d353d515b.js.map