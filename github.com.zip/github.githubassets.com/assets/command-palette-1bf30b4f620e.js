"use strict";
(() => {
    var bt = Object.defineProperty;
    var i = (y, v) => bt(y, "name", {
        value: v,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [9016], {
            92191: (y, v, l) => {
                var c = l(90420),
                    g = Object.defineProperty,
                    x = Object.getOwnPropertyDescriptor,
                    m = i((t, e, s, r) => {
                        for (var o = r > 1 ? void 0 : r ? x(e, s) : e, n = t.length - 1, a; n >= 0; n--)(a = t[n]) && (o = (r ? a(e, s, o) : a(o)) || o);
                        return r && o && g(e, s, o), o
                    }, "__decorateClass");
                const p = "*";
                let h = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.scopeTypes = ""
                    }
                    active(t, e) {
                        return this.scopeTypeMatch(t.type) && this.modeMatch(e)
                    }
                    scopeTypeMatch(t) {
                        return this.scopeTypes ? this.scopeTypes && JSON.parse(this.scopeTypes).includes(t) : !0
                    }
                    modeMatch(t) {
                        return this.char === p || this.char === t
                    }
                    character() {
                        return this.char === p ? "" : this.char
                    }
                }, "CommandPaletteModeElement");
                m([c.Lj], h.prototype, "char", 2), m([c.Lj], h.prototype, "placeholder", 2), m([c.Lj], h.prototype, "scopeTypes", 2), h = m([c.Ih], h);
                var u = Object.defineProperty,
                    b = Object.getOwnPropertyDescriptor,
                    S = i((t, e, s, r) => {
                        for (var o = r > 1 ? void 0 : r ? b(e, s) : e, n = t.length - 1, a; n >= 0; n--)(a = t[n]) && (o = (r ? a(e, s, o) : a(o)) || o);
                        return r && o && u(e, s, o), o
                    }, "command_palette_tip_element_decorateClass");
                const H = "*",
                    G = "";
                let C = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.scopeTypes = G, this.mode = H, this.matchMode = G, this.value = H, this.onEmpty = !1, this.onError = !1
                    }
                    connectedCallback() {
                        this.hidden = !0
                    }
                    available(t, e = !1, s = !1) {
                        return this.valueMatch(t.text) && this.scopeTypeMatch(t.scope.type) && this.modeMatch(t.mode) && this.showOnEmpty(e) && this.showOnError(s)
                    }
                    toggle(t, e = !1, s = !1) {
                        this.hidden = !this.available(t, e, s)
                    }
                    valueMatch(t) {
                        return this.value === H || this.value === t
                    }
                    scopeTypeMatch(t) {
                        return this.scopeTypes !== G && (this.scopeTypes === H || JSON.parse(this.scopeTypes).includes(t))
                    }
                    modeMatch(t) {
                        if (this.matchMode === G) return this.mode === H || this.mode === t; {
                            const e = new RegExp(this.matchMode);
                            return t.match(e) !== null
                        }
                    }
                    showOnEmpty(t) {
                        return this.onEmpty ? t : !0
                    }
                    showOnError(t) {
                        return this.onError ? t : !0
                    }
                }, "CommandPaletteTipElement");
                S([c.Lj], C.prototype, "scopeTypes", 2), S([c.Lj], C.prototype, "mode", 2), S([c.Lj], C.prototype, "matchMode", 2), S([c.Lj], C.prototype, "value", 2), S([c.Lj], C.prototype, "onEmpty", 2), S([c.Lj], C.prototype, "onError", 2), C = S([c.Ih], C);
                var St = l(34348),
                    qe = Object.defineProperty,
                    Fe = Object.getOwnPropertyDescriptor,
                    k = i((t, e, s, r) => {
                        for (var o = r > 1 ? void 0 : r ? Fe(e, s) : e, n = t.length - 1, a; n >= 0; n--)(a = t[n]) && (o = (r ? a(e, s, o) : a(o)) || o);
                        return r && o && qe(e, s, o), o
                    }, "command_palette_token_element_decorateClass");
                let _ = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.type = "", this.id = "", this.text = "", this.value = ""
                    }
                }, "CommandPaletteTokenElement");
                k([c.Lj], _.prototype, "type", 2), k([c.Lj], _.prototype, "id", 2), k([c.Lj], _.prototype, "text", 2), k([c.Lj], _.prototype, "value", 2), _ = k([c.Ih], _);
                var O = l(65881),
                    Re = l(55623),
                    se = l(46263),
                    Ge = Object.defineProperty,
                    ze = Object.getOwnPropertyDescriptor,
                    q = i((t, e, s, r) => {
                        for (var o = r > 1 ? void 0 : r ? ze(e, s) : e, n = t.length - 1, a; n >= 0; n--)(a = t[n]) && (o = (r ? a(e, s, o) : a(o)) || o);
                        return r && o && Ge(e, s, o), o
                    }, "command_palette_item_stack_element_decorateClass");
                let A = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.topGroupThreshold = 6.5, this.maxHeightVh = 65, this.showDebugInfo = !1, this.octicons = {}, this.tryDefaultSelection = !1, this.eventListenersBound = !1, this.currentHeight = 0, this.items = {}, this.history = {}
                    }
                    get commandPalette() {
                        return this.closest("command-palette")
                    }
                    connectedCallback() {
                        if (this.classList.add("rounded-bottom-2"), this.commandPalette && !this.commandPalette.multiPageEnabled) {
                            const t = this.commandPalette.querySelector(".js-command-local-provider-octicons");
                            if (t) {
                                const e = Array.from(t.children).map(s => ({
                                    id: s.getAttribute("data-local-provider-octicon-id"),
                                    svg: s.innerHTML
                                }));
                                this.commandPalette.cacheIcons(e)
                            }
                        }
                    }
                    get selectedItem() {
                        return this.findSelectedElement()
                    }
                    set selectedItem(t) {
                        const e = this.findSelectedElement();
                        e && (e.selected = !1), t && (t.selected = !0, this.selectedItemChanged(t.item))
                    }
                    get selectedItemIsTopResult() {
                        var t;
                        const e = this.findGroup(O.O.topGroupId);
                        return e && e.itemNodes.length > 0 ? e.firstItem.itemId === ((t = this.selectedItem) == null ? void 0 : t.itemId) : !1
                    }
                    findSelectedElement() {
                        return this.querySelector("command-palette-item[data-selected]")
                    }
                    navigate(t) {
                        var e, s;
                        this.tryDefaultSelection = !1;
                        const r = t > 0,
                            o = {
                                behavior: "smooth",
                                block: "nearest"
                            };
                        if (this.selectedItem) {
                            let n;
                            if (r ? n = (e = this.selectedItem) == null ? void 0 : e.nextElementSibling : n = (s = this.selectedItem) == null ? void 0 : s.previousElementSibling, n) this.selectedItem = n, this.selectedItem.scrollIntoView(o);
                            else if (this.selectedItem) {
                                const a = this.visibleGroups[this.calculateIndex(t)];
                                a.scrollIntoView(o), r ? this.selectedItem = a.firstItem : this.selectedItem = a.lastItem
                            }
                        } else this.selectedItem = this.firstItem
                    }
                    calculateIndex(t) {
                        var e;
                        let s = this.visibleGroups.findIndex(n => {
                            var a;
                            return n.groupId === ((a = this.selectedItem) == null ? void 0 : a.item.group)
                        });
                        ((e = this.findGroup(O.O.topGroupId)) == null ? void 0 : e.firstItem) === this.selectedItem && (s = 0);
                        const r = s + t,
                            o = this.visibleGroups.length;
                        return (r % o + o) % o
                    }
                    historyItems(t) {
                        return this.history[t] || (this.history[t] = {}), this.history[t]
                    }
                    addItemToHistory(t, e, s) {
                        const r = this.historyItems(e),
                            o = s.calculateScore(t);
                        r[s.id] = o
                    }
                    addItems(t, e, s = !1) {
                        for (const r of e) this.addItemToHistory(t.text, t.path, r), this.items[r.id] = r, s && this.prefillHistory(r, t);
                        (0, se.D)(this.renderCurrentItems.bind(this), this.debounceWait)()
                    }
                    removeItem(t) {
                        return delete this.items[t.id]
                    }
                    removeItems(t) {
                        const e = t.map(s => ({
                            item: s,
                            removed: this.removeItem(s)
                        }));
                        return (0, se.D)(this.renderCurrentItems.bind(this), this.debounceWait)(), e
                    }
                    prefillHistory(t, e) {
                        for (const s of t.matchingFields) {
                            const o = Math.min(s.length, 15);
                            for (let n = 0; n <= o; n++) {
                                const a = s.slice(0, n);
                                this.addItemToHistory(a, e.buildPath(e, a), t)
                            }
                        }
                    }
                    get debounceWait() {
                        return 16
                    }
                    renderCurrentItems() {
                        const t = this.getQuery().immutableCopy();
                        this.currentPath !== t.path && this.reset();
                        const e = [...this.currentItems];
                        if (t.isPresent() && e.length > 0) {
                            const s = this.findGroup(O.O.topGroupId);
                            for (let r = 0; s && r < s.limit; r++) {
                                const o = e[r],
                                    n = o.calculateScore(t.queryText),
                                    a = o.priority + n;
                                o && a > this.topGroupThreshold && this.renderItem(e.shift(), O.O.topGroupId)
                            }
                        }
                        this.renderItems(e), this.updateSelectedItem(), this.itemsUpdated()
                    }
                    itemsUpdated() {
                        const t = new CustomEvent("itemsUpdated", {
                            cancelable: !0,
                            detail: {
                                items: this.currentItems,
                                queryPath: this.getQuery().immutableCopy().path
                            }
                        });
                        return this.dispatchEvent(t)
                    }
                    selectedItemChanged(t) {
                        const e = new CustomEvent("selectedItemChanged", {
                            bubbles: !0,
                            cancelable: !0,
                            detail: {
                                item: t,
                                isDefaultSelection: this.tryDefaultSelection
                            }
                        });
                        return this.dispatchEvent(e)
                    }
                    renderItems(t) {
                        for (const e of t) this.renderItem(e, e.group);
                        this.setGroupBorders(), this.setMaxHeight()
                    }
                    get maximumHeight() {
                        const s = window.innerHeight * .5;
                        return Math.min(s, 475)
                    }
                    get innerContentHeight() {
                        let t = 0;
                        for (const e of this.children) {
                            const s = e,
                                r = getComputedStyle(s),
                                o = parseInt(r.marginTop.replace("px", ""), 10),
                                n = parseInt(r.marginBottom.replace("px", ""), 10),
                                a = s.offsetHeight + o + n;
                            s.offsetHeight > 0 && (t += a)
                        }
                        return t
                    }
                    setMaxHeight() {
                        const e = this.maximumHeight * .6,
                            s = Math.round(Math.min(this.maximumHeight, this.innerContentHeight));
                        Math.abs(this.currentHeight - s) > e ? this.classList.add("no-transition") : this.classList.remove("no-transition"), this.setAttribute("style", `max-height:${s}px; min-height:${s}px;`), this.currentHeight = s
                    }
                    setGroupBorders() {
                        if (this.visibleGroups.length > 0) {
                            this.visibleGroups[0].classList.remove("border-top");
                            for (const t of this.visibleGroups) this.visibleGroups.indexOf(t) === 0 ? (t.classList.remove("border-top"), t.header && (t.classList.remove("py-2"), t.classList.add("mb-2", "mt-3"))) : (t.classList.add("border-top"), t.header && (t.classList.remove("mb-2", "mt-3"), t.classList.add("py-2")))
                        }
                    }
                    createItemElementAndRender(t, e, s) {
                        const r = new Re.F;
                        return r.setItemAttributes(t), r.render(e, s), r
                    }
                    renderItem(t, e) {
                        var s;
                        const r = this.findGroup(e);
                        if (!r || (r.hasItem(t) || r.atLimit || ((s = this.topGroup) == null ? void 0 : s.hasItem(t))) && !(r == null ? void 0 : r.topGroup)) return;
                        const o = this.createItemElementAndRender(t, !1, this.getQuery().immutableCopy().queryText);
                        if (this.showDebugInfo && (o.score = t.score), r.push(o), o.containerElement) {
                            const a = r.list.children.length.toString();
                            t.position = a
                        }
                        if (t.icon)
                            if (t.icon.type === "octicon") {
                                const a = this.octicons[t.icon.id],
                                    D = this.octicons["dash-color-fg-muted"];
                                o.renderOcticon(a || D)
                            } else t.icon.type === "avatar" && o.renderAvatar(t.icon.url, t.icon.alt);
                        else o.iconElement.hidden = !0;
                        o.addEventListener("mousemove", a => {
                            (a.movementX !== 0 || a.movementY !== 0) && this.selectedItem !== o && (this.tryDefaultSelection = !1, this.selectedItem = o)
                        })
                    }
                    findGroup(t) {
                        return this.groups.find(e => e.groupId === t)
                    }
                    get topGroup() {
                        return this.findGroup(O.O.topGroupId)
                    }
                    get groupIds() {
                        return this.groups.map(t => t.groupId)
                    }
                    updateSelectedItem() {
                        this.isSelectedItemInvalid() && this.clearSelection(), this.setDefaultSelection() && (this.selectedItem = this.firstItem)
                    }
                    setDefaultSelection() {
                        const t = this.getQuery().hasScope() || this.getQuery().isPresent();
                        return this.tryDefaultSelection && t
                    }
                    noItemSelected() {
                        return !this.selectedItem || this.isSelectedItemInvalid()
                    }
                    isSelectedItemInvalid() {
                        return !this.currentItems.some(t => {
                            var e;
                            return t.id === ((e = this.selectedItem) == null ? void 0 : e.itemId)
                        })
                    }
                    isEmpty() {
                        return !this.currentItems || this.currentItems.length === 0
                    }
                    clearSelection() {
                        this.selectedItem = void 0
                    }
                    clear() {
                        this.history = {}, this.items = {}, this.reset()
                    }
                    reset() {
                        this.tryDefaultSelection = !0, this.currentPath = this.getQuery().immutableCopy().path;
                        for (const t of this.groups) t.prepareForNewItems()
                    }
                    clearItemsFor(t) {
                        const e = this.groups.filter(r => t.includes(r.groupId));
                        for (const r of e) r.prepareForNewItems();
                        const s = Object.values(this.items).filter(r => t.includes(r.group));
                        this.removeItems(s)
                    }
                    get visibleGroups() {
                        return this.groups.filter(t => !t.hidden)
                    }
                    get firstItem() {
                        const t = this.visibleGroups;
                        if (t.length > 0) return t[0].querySelector("command-palette-item")
                    }
                    get currentItems() {
                        const t = this.getQuery().immutableCopy(),
                            e = this.historyItems(t.path),
                            s = Object.entries(e).map(([r, o]) => {
                                const n = this.items[r];
                                return n ? (n.score = o, n) : (delete e[r], null)
                            }).filter(r => r !== null);
                        return s ? t.isBlank() ? s.sort((r, o) => o.priority - r.priority) : s.sort((r, o) => o.score - r.score || o.priority - r.priority) : []
                    }
                    disconnectedCallback() {
                        this.unbindListeners()
                    }
                    bindListeners() {
                        this.eventListenersBound || (window.addEventListener("resize", this.setMaxHeight.bind(this)), this.eventListenersBound = !0)
                    }
                    unbindListeners() {
                        window.removeEventListener("resize", this.setMaxHeight.bind(this)), this.eventListenersBound = !1
                    }
                }, "CommandPaletteItemStackElement");
                q([c.Lj], A.prototype, "topGroupThreshold", 2), q([c.Lj], A.prototype, "maxHeightVh", 2), q([c.Lj], A.prototype, "showDebugInfo", 2), q([c.GO], A.prototype, "groups", 2), A = q([c.Ih], A);
                var $e = l(58070),
                    Ct = l(23001),
                    Ue = l(74365),
                    U = l(99780),
                    re = l(12374),
                    Ne = l(26850);
                class oe extends re.t {
                    async fetchSrc(e) {
                        if (!this.src) throw new Error("No src provided");
                        const s = new URL(this.src, window.location.origin);
                        s.search = e.params().toString();
                        const o = await (await fetch(s.toString(), {
                            headers: {
                                Accept: "application/json",
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        })).json();
                        if (!o.results) return;
                        const n = o.results[0];
                        if (n.base_file_path) {
                            const a = n.base_file_path,
                                D = n.paths;
                            o.results = D.map(f => U.s.from({
                                title: f,
                                path: `${a}/${f}`,
                                icon: "file-color-fg-muted",
                                group: "files"
                            }))
                        } else n.action && n.action.type === "access_policy" ? o.results = [new Ue.i(n)] : o.results = [];
                        return o
                    }
                    async fetch(e, s = !1) {
                        const r = e.text.match(/(.+):(\d*)\s*$/);
                        return r ? this.fetchWithLineNumbers(e, r) : super.fetch(e, s)
                    }
                    async fetchWithLineNumbers(e, s) {
                        const r = s[1],
                            o = s[2],
                            n = new Ne.A(r, e.mode, {
                                scope: e.scope
                            }),
                            a = [],
                            D = (await super.fetch(n, !1)).results;
                        for (const f of D) f instanceof U.s && a.push(this.convert(f, o));
                        return {
                            results: a
                        }
                    }
                    convert(e, s) {
                        return s === "" || !(e instanceof U.s) || (e.title = `${e.title}:${s}`, e.action.path = `${e.action.path}#L${s}`), e
                    }
                }
                i(oe, "FilesProvider");
                var N = l(43832);
                class ie extends N.j {
                    enabledFor(e) {
                        return !0
                    }
                    clearCache() {}
                    get hasCommands() {
                        return !1
                    }
                    get debounce() {
                        return 0
                    }
                    async fetch(e, s = !1) {
                        return e.mode === "?" || s ? {
                            results: Array.from(this.element.querySelectorAll("command-palette-help")).filter(n => n.show(e)).map((n, a) => n.toItem(a))
                        } : {
                            results: []
                        }
                    }
                }
                i(ie, "HelpProvider");
                var We = l(46635);
                class d {
                    constructor() {
                        this.iconType = "octicon", this.group = "commands", this.priority = 0, this.dismissAfterRun = !0
                    }
                    static item(e = {}) {
                        return new We.U(new this, e)
                    }
                    run(e) {
                        new Error("Not implemented")
                    }
                    isApplicable(e) {
                        return !0
                    }
                }
                i(d, "MainWindowCommand");
                class z extends d {
                    constructor() {
                        super(...arguments);
                        this.group = "global_commands"
                    }
                }
                i(z, "MainWindowGlobalCommand");
                var ne = l(33241);
                class E extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "2 spaces", this.iconType = "none", this.tabSize = "2"
                    }
                    async run(e) {
                        this.updateTabSize(), this.saveSettings(e)
                    }
                    updateTabSize() {
                        const e = document.querySelectorAll("[data-tab-size]");
                        for (const s of e) s.setAttribute("data-tab-size", this.tabSize)
                    }
                    async saveSettings(e) {
                        const s = document.querySelector(".js-tab-size-csrf").value,
                            r = document.querySelector(".js-tab-size-path").value,
                            o = new FormData;
                        o.set("tab_size_rendering_preference", this.tabSize);
                        const n = "Failed to save tab size preference";
                        try {
                            (await fetch(r, {
                                method: "PUT",
                                body: o,
                                mode: "same-origin",
                                headers: {
                                    "Scoped-CSRF-Token": s,
                                    "X-Requested-With": "XMLHttpRequest"
                                }
                            })).ok ? e.displayFlash("success", "Tab size rendering updated") : e.displayFlash("error", n)
                        } catch {
                            e.displayFlash("error", n)
                        }
                    }
                }
                i(E, "TabSizeTwo");
                class ae extends E {
                    constructor() {
                        super(...arguments);
                        this.title = "3 spaces", this.tabSize = "3"
                    }
                }
                i(ae, "TabSizeThree");
                class ce extends E {
                    constructor() {
                        super(...arguments);
                        this.title = "4 spaces", this.tabSize = "4"
                    }
                }
                i(ce, "TabSizeFour");
                class le extends E {
                    constructor() {
                        super(...arguments);
                        this.title = "6 spaces", this.tabSize = "6"
                    }
                }
                i(le, "TabSizeSix");
                class ue extends E {
                    constructor() {
                        super(...arguments);
                        this.title = "8 spaces", this.tabSize = "8"
                    }
                }
                i(ue, "TabSizeEight");
                class de extends E {
                    constructor() {
                        super(...arguments);
                        this.title = "10 spaces", this.tabSize = "10"
                    }
                }
                i(de, "TabSizeTen");
                class he extends E {
                    constructor() {
                        super(...arguments);
                        this.title = "12 spaces", this.tabSize = "12"
                    }
                }
                i(he, "TabSizeTwelve");
                class me extends z {
                    constructor() {
                        super(...arguments);
                        this.title = "Change tab size rendering", this.icon = "gear-color-fg-muted", this.priority = 10, this.dismissAfterRun = !1
                    }
                    run(e) {
                        e.pushPage(new ne.Z4(this.title, "tab-sizes", this.pageItems))
                    }
                    get pageItems() {
                        return [E, ae, ce, le, ue, de, he].map(e => e.item())
                    }
                }
                i(me, "SwitchTabSize");
                var w = l(74030);
                class pe extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Open in github.dev editor", this.icon = "codespaces-color-fg-muted", this.priority = 10
                    }
                    isApplicable() {
                        return this.fetchLink() instanceof HTMLAnchorElement
                    }
                    fetchLink() {
                        return document.querySelector(".js-github-dev-shortcut")
                    }
                    run() {
                        var e;
                        (e = this.fetchLink()) == null || e.click()
                    }
                }
                i(pe, "OpenInDotDev");
                class fe extends z {
                    constructor() {
                        super(...arguments);
                        this.title = "Switch theme", this.icon = "paintbrush-color-fg-muted", this.priority = 9, this.dismissAfterRun = !1
                    }
                    run(e) {
                        e.pushPage(new ne.Z4(this.title, "switch-theme-page-1", this.pageItems))
                    }
                    get pageItems() {
                        return [P.item({
                            group: "commands",
                            title: "Default dark"
                        }), V.item({
                            group: "commands",
                            title: "Default light"
                        }), Z.item({
                            group: "commands",
                            title: "Dark dimmed"
                        }), W.item({
                            group: "commands",
                            title: "Dark high contrast"
                        }), K.item({
                            group: "commands",
                            title: "Sync with system settings"
                        })]
                    }
                    select(e) {
                        this.run(e)
                    }
                }
                i(fe, "SwitchTheme");
                class P extends z {
                    constructor() {
                        super(...arguments);
                        this.title = "Switch theme to default dark", this.icon = "moon-color-fg-muted", this.mode = "dark", this.theme = "dark"
                    }
                    applyTheme() {
                        this.loadStyles(this.theme), this.mode !== "auto" && (0, w.on)(this.theme, this.mode), (0, w.h5)(this.mode)
                    }
                    async run() {
                        this.applyTheme(), this.saveSettings(this.mode, this.lightTheme, this.darkTheme)
                    }
                    async saveSettings(e = this.mode, s, r) {
                        const o = document.querySelector(".js-color-mode-csrf").value,
                            n = document.querySelector(".js-color-mode-path").value,
                            a = new FormData;
                        a.set("color_mode", e), s && a.set("light_theme", s), r && a.set("dark_theme", r);
                        const f = await (await fetch(n, {
                            method: "PUT",
                            body: a,
                            mode: "same-origin",
                            headers: {
                                "Scoped-CSRF-Token": o,
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        })).json();
                        this.loadStyles(f.light_theme), this.loadStyles(f.dark_theme), (0, w.on)(f.light_theme, "light"), (0, w.on)(f.dark_theme, "dark"), (0, w.h5)(f.color_mode)
                    }
                    loadStyles(e) {
                        const s = document.querySelector(`link[data-color-theme='${e}']`);
                        s && !s.hasAttribute("href") && s.hasAttribute("data-href") && s.setAttribute("href", s.getAttribute("data-href"))
                    }
                    get darkTheme() {
                        return this.mode === "dark" ? this.theme : (0, w.yn)("dark")
                    }
                    get lightTheme() {
                        return this.mode === "light" ? this.theme : (0, w.yn)("light")
                    }
                }
                i(P, "SwitchToDark");
                class W extends P {
                    constructor() {
                        super(...arguments);
                        this.title = "Switch theme to dark high contrast", this.theme = "dark_high_contrast"
                    }
                }
                i(W, "SwitchToDarkHighContrast");
                class Z extends P {
                    constructor() {
                        super(...arguments);
                        this.title = "Switch theme to dark dimmed", this.theme = "dark_dimmed"
                    }
                }
                i(Z, "SwitchToDarkDimmed");
                class V extends P {
                    constructor() {
                        super(...arguments);
                        this.title = "Switch theme to default light", this.icon = "sun-color-fg-muted", this.mode = "light", this.theme = "light"
                    }
                }
                i(V, "SwitchToLight");
                class K extends P {
                    constructor() {
                        super(...arguments);
                        this.title = "Switch theme settings to sync with system", this.icon = "sun-color-fg-muted", this.mode = "auto"
                    }
                    get darkTheme() {}
                    get lightTheme() {}
                }
                i(K, "SwitchToAuto");
                class ye extends d {
                    constructor() {
                        super();
                        const e = this.isSubscribe();
                        this.title = `${e?"Subscribe":"Unsubscribe"}`, this.icon = `${e?"bell":"bell-slash"}-color-fg-muted`
                    }
                    isApplicable() {
                        var e;
                        return this.fetchButton() instanceof HTMLButtonElement && ((e = this.fetchButton()) == null ? void 0 : e.disabled) === !1
                    }
                    isSubscribe() {
                        var e, s;
                        return ((s = (e = this.fetchButton()) == null ? void 0 : e.textContent) == null ? void 0 : s.trim()) === "Subscribe"
                    }
                    fetchButton() {
                        return document.querySelector(".thread-subscribe-button")
                    }
                    run() {
                        var e;
                        (e = this.fetchButton()) == null || e.click()
                    }
                }
                i(ye, "UpdateSubscription");
                const Ze = [pe, V, P, Z, W, K, ye];
                class ve extends N.j {
                    enabledFor(e) {
                        return e.mode === ">"
                    }
                    async fetch(e) {
                        return {
                            results: this.fuzzyFilter(this.items, e)
                        }
                    }
                    get items() {
                        return [fe.item(), me.item()]
                    }
                    clearCache() {}
                }
                i(ve, "MultiPageCommandsProvider");
                var Ve = l(45979),
                    Ke = l(3404);
                class ge extends N.j {
                    enabledFor(e) {
                        return !(e.isBlank() || e.mode === "?" || e.mode === ">")
                    }
                    clearCache() {}
                    get hasCommands() {
                        return !1
                    }
                    async fetch(e, s = !1) {
                        return {
                            results: [Ke.K.create(e)]
                        }
                    }
                }
                i(ge, "SearchLinksProvider");
                class Q {
                    static create(e) {
                        const s = this.providers[e.type];
                        if (!s) throw new Error(`Unknown provider type: ${e.type}`);
                        return new s(e)
                    }
                }
                i(Q, "ServerDefinedProviderFactory"), Q.providers = {
                    remote: Ve.x,
                    prefetched: re.t,
                    files: oe,
                    help: ie,
                    "search-links": ge,
                    "multi-page-commands": ve
                };
                var Qe = Object.defineProperty,
                    Xe = Object.getOwnPropertyDescriptor,
                    L = i((t, e, s, r) => {
                        for (var o = r > 1 ? void 0 : r ? Xe(e, s) : e, n = t.length - 1, a; n >= 0; n--)(a = t[n]) && (o = (r ? a(e, s, o) : a(o)) || o);
                        return r && o && Qe(e, s, o), o
                    }, "server_defined_provider_element_decorateClass");
                let I = i(class extends $e.b {
                    constructor() {
                        super(...arguments);
                        this._wildcard = "*"
                    }
                    get debounce() {
                        return parseInt(this.fetchDebounce, 10)
                    }
                    get hasCommands() {
                        return this.supportsCommands
                    }
                    get hasWildCard() {
                        return this.modes.includes(this._wildcard)
                    }
                    get modes() {
                        return this.supportedModes === "" && (this._modes = [""]), this._modes || (this._modes = JSON.parse(this.supportedModes)), this._modes
                    }
                    get scopeTypes() {
                        return this.supportedScopeTypes === "" ? [] : (this._scopeTypes || (this._scopeTypes = JSON.parse(this.supportedScopeTypes)), this._scopeTypes)
                    }
                    connectedCallback() {
                        this.provider = Q.create(this)
                    }
                }, "ServerDefinedProviderElement");
                L([c.Lj], I.prototype, "type", 2), L([c.Lj], I.prototype, "supportedModes", 2), L([c.Lj], I.prototype, "fetchDebounce", 2), L([c.Lj], I.prototype, "supportedScopeTypes", 2), L([c.Lj], I.prototype, "src", 2), L([c.Lj], I.prototype, "supportsCommands", 2), I = L([c.Ih], I);
                var Je = l(52815),
                    Ye = Object.defineProperty,
                    et = Object.getOwnPropertyDescriptor,
                    M = i((t, e, s, r) => {
                        for (var o = r > 1 ? void 0 : r ? et(e, s) : e, n = t.length - 1, a; n >= 0; n--)(a = t[n]) && (o = (r ? a(e, s, o) : a(o)) || o);
                        return r && o && Ye(e, s, o), o
                    }, "command_palette_help_element_decorateClass");
                let j = i(class extends HTMLElement {
                    connectedCallback() {
                        this.hidden = !0
                    }
                    show(t) {
                        return this.isEnabledScopeType(t)
                    }
                    isEnabledScopeType(t) {
                        return this.scopeTypes ? this.scopeTypes && JSON.parse(this.scopeTypes).includes(t.scope.type) : !0
                    }
                    toItem(t) {
                        const e = {
                            group: this.group,
                            title: this.titleElement.innerHTML,
                            index: t
                        };
                        return this.prefix && (e.prefix = this.prefix), this.hintElement.textContent && (e.persistentHint = this.hintElement.innerHTML), Je.B.from(e)
                    }
                }, "CommandPaletteHelpElement");
                M([c.Lj], j.prototype, "group", 2), M([c.Lj], j.prototype, "prefix", 2), M([c.Lj], j.prototype, "scopeTypes", 2), M([c.fA], j.prototype, "titleElement", 2), M([c.fA], j.prototype, "hintElement", 2), j = M([c.Ih], j);
                var Et = l(9731),
                    It = l(16517),
                    Tt = l(20181),
                    xt = l(94634),
                    wt = l(32004);
                class be extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Delete discussion\u2026", this.icon = "trash-color-fg-muted"
                    }
                    get deleteButton() {
                        return document.querySelector("button#dialog-show-delete-discussion")
                    }
                    get dialogElement() {
                        return document.querySelector("#delete-discussion")
                    }
                    fetchDetails() {
                        return document.querySelector("details.js-delete-discussion-details")
                    }
                    isApplicable() {
                        return this.deleteButton != null || this.fetchDetails() instanceof HTMLDetailsElement
                    }
                    run() {
                        const e = this.deleteButton;
                        if (e) {
                            e.click(), setTimeout(() => {
                                var r, o;
                                (o = (r = this.dialogElement) == null ? void 0 : r.querySelector('button[type="submit"]')) == null || o.focus()
                            }, 0);
                            return
                        }
                        const s = this.fetchDetails();
                        s && (s.open = !0, setTimeout(() => {
                            var r;
                            (r = s == null ? void 0 : s.querySelector('button[type="submit"]')) == null || r.focus()
                        }, 0))
                    }
                }
                i(be, "DeleteDiscussion");
                class Se extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Edit discussion body", this.icon = "pencil-color-fg-muted"
                    }
                    get editButton() {
                        return document.querySelector(".js-discussions-comment-edit-button")
                    }
                    isApplicable() {
                        return this.editButton != null
                    }
                    run() {
                        var e;
                        (e = this.editButton) == null || e.click()
                    }
                }
                i(Se, "EditDiscussion");
                class Ce extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Transfer discussion\u2026", this.icon = "arrow-right-color-fg-muted"
                    }
                    fetchDetails() {
                        return document.querySelector("details.js-transfer-discussion-details")
                    }
                    isApplicable() {
                        return this.fetchDetails() instanceof HTMLDetailsElement
                    }
                    run() {
                        var e;
                        const s = this.fetchDetails();
                        if (s) {
                            const r = i(() => {
                                setTimeout(() => {
                                    var o;
                                    (o = s == null ? void 0 : s.querySelector("[data-menu-button]")) == null || o.focus()
                                }, 0)
                            }, "focusMenu");
                            (e = s.querySelector("include-fragment")) == null || e.addEventListener("load", r), s.open = !0, r()
                        }
                    }
                }
                i(Ce, "TransferDiscussion");
                const tt = [be, Ce, Se];

                function Ee(t) {
                    t.focus(), t.selectionStart = t.selectionEnd = t.value.length
                }
                i(Ee, "moveCursorToEnd");
                class X extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Edit issue body", this.icon = "pencil-color-fg-muted"
                    }
                    issueBody() {
                        return document.querySelector(".js-command-palette-issue-body")
                    }
                    isIssue() {
                        return !!this.issueBody()
                    }
                    isApplicable() {
                        return this.isIssue()
                    }
                    run() {
                        const e = document.createElement("button");
                        e.hidden = !0, e.classList.add("js-comment-edit-button");
                        const s = document.querySelector("div.js-comment");
                        s == null || s.appendChild(e), e.click(), e.remove(), setTimeout(() => {
                            var r;
                            const o = (r = s == null ? void 0 : s.parentElement) == null ? void 0 : r.querySelector("textarea.js-comment-field");
                            o && Ee(o)
                        }, 0)
                    }
                }
                i(X, "EditIssueBody");
                class J extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Edit issue title", this.icon = "pencil-color-fg-muted"
                    }
                    issueBody() {
                        return document.querySelector(".js-command-palette-issue-body")
                    }
                    isIssue() {
                        return !!this.issueBody()
                    }
                    isApplicable() {
                        return this.fetchButton() instanceof HTMLButtonElement && this.isIssue()
                    }
                    fetchButton() {
                        return document.querySelector(".js-title-edit-button")
                    }
                    run() {
                        var e;
                        (e = this.fetchButton()) == null || e.click(), setTimeout(() => {
                            const s = document.querySelector("input#issue_title[autofocus]");
                            s && Ee(s)
                        }, 0)
                    }
                }
                i(J, "EditIssueTitle");
                class Ie extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Transfer issue\u2026", this.icon = "arrow-right-color-fg-muted"
                    }
                    isApplicable() {
                        return this.fetchDetails() instanceof HTMLDetailsElement
                    }
                    fetchDetails() {
                        return document.querySelector("details.js-transfer-issue")
                    }
                    run() {
                        var e;
                        const s = this.fetchDetails();
                        if (s) {
                            const r = i(() => {
                                setTimeout(() => {
                                    var o;
                                    (o = s.querySelector("[data-menu-button]")) == null || o.focus()
                                }, 0)
                            }, "focusMenu");
                            (e = s.querySelector("include-fragment")) == null || e.addEventListener("load", r), s.open = !0, r()
                        }
                    }
                }
                i(Ie, "TransferIssue");
                class Te extends d {
                    constructor() {
                        super();
                        const e = this.isLock();
                        this.title = `${e?"Lock":"Unlock"} conversation`, this.icon = `${e?"lock":"key"}-color-fg-muted`
                    }
                    isApplicable() {
                        return this.fetchDetails() instanceof HTMLDetailsElement
                    }
                    isLock() {
                        var e, s;
                        return ((s = (e = document.querySelector("summary.lock-toggle-link")) == null ? void 0 : e.textContent) == null ? void 0 : s.trim()) === "Lock conversation"
                    }
                    fetchDetails() {
                        return document.querySelector("details.js-lock-issue")
                    }
                    run() {
                        const e = this.fetchDetails();
                        e && (e.open = !0, setTimeout(() => {
                            var s;
                            (s = document.querySelector("#unlock-reason")) == null || s.focus()
                        }, 0))
                    }
                }
                i(Te, "LockIssue");
                class xe extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Delete issue\u2026", this.icon = "trash-color-fg-muted"
                    }
                    isApplicable() {
                        return this.fetchDetails() instanceof HTMLDetailsElement
                    }
                    fetchDetails() {
                        return document.querySelector("details.js-delete-issue")
                    }
                    run() {
                        const e = this.fetchDetails();
                        e && (e.open = !0, setTimeout(() => {
                            var s;
                            (s = e.querySelector('button[type="submit"]')) == null || s.focus()
                        }, 0))
                    }
                }
                i(xe, "DeleteIssue");
                class we extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Convert issue to discussion\u2026", this.icon = "comment-discussion-color-fg-muted"
                    }
                    isApplicable() {
                        return this.fetchDetails() instanceof HTMLDetailsElement
                    }
                    fetchDetails() {
                        return document.querySelector("details.js-convert-to-discussion")
                    }
                    run() {
                        var e;
                        const s = this.fetchDetails();
                        if (s) {
                            const r = i(() => {
                                setTimeout(() => {
                                    var o;
                                    (o = s.querySelector("[data-menu-button]")) == null || o.focus()
                                }, 0)
                            }, "focusMenu");
                            (e = s.querySelector("include-fragment")) == null || e.addEventListener("load", r), s.open = !0, r()
                        }
                    }
                }
                i(we, "ConvertToDiscussion");
                const st = [J, X, Te, Ie, xe, we];
                var rt = l(21314),
                    T = l(76745);
                class Y extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Open in new codespace", this.icon = "codespaces-color-fg-muted", this.priority = 11
                    }
                    isApplicable() {
                        const e = this.fetchElements();
                        return !!(e.codeModal && e.codespacesForm && e.newCodespacesButton && e.codespacesTab)
                    }
                    run() {
                        const {
                            codeModal: e,
                            codespacesTab: s,
                            newCodespacesButton: r
                        } = this.fetchElements();
                        !(e && s && r) || (e.open = !0, s.click(), r instanceof HTMLButtonElement ? r.click() : (r.parentElement.open = !0, setTimeout(() => {
                            var o;
                            (o = document.querySelector(".js-create-codespace-with-sku-button")) == null || o.focus()
                        }, 0)))
                    }
                    fetchElements() {
                        const e = document.querySelector(".js-create-codespaces-form-command"),
                            s = (e == null ? void 0 : e.closest("details")) || null,
                            r = (s == null ? void 0 : s.querySelector('[data-tab="cloud"]')) || null,
                            o = (e == null ? void 0 : e.querySelector('summary[role="button"], button[type="submit"]')) || null;
                        return {
                            codespacesForm: e,
                            codeModal: s,
                            codespacesTab: r,
                            newCodespacesButton: o
                        }
                    }
                }
                i(Y, "OpenCodespace");
                var F = l(76612);
                class Pe extends X {
                    constructor() {
                        super(...arguments);
                        this.title = "Edit pull request body"
                    }
                    pullRequestBody() {
                        return document.querySelector(".js-command-palette-pull-body")
                    }
                    isPullRequest() {
                        return !!this.pullRequestBody()
                    }
                    isApplicable() {
                        return this.isPullRequest()
                    }
                }
                i(Pe, "EditPullRequestBody");
                class Le extends J {
                    constructor() {
                        super(...arguments);
                        this.title = "Edit pull request title"
                    }
                    pullRequestBody() {
                        return document.querySelector(".js-command-palette-pull-body")
                    }
                    isPullRequest() {
                        return !!this.pullRequestBody()
                    }
                    isApplicable() {
                        return this.fetchButton() instanceof HTMLButtonElement && this.isPullRequest()
                    }
                }
                i(Le, "EditPullRequestTitle");
                class je extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Update current branch", this.icon = "sync-color-fg-muted"
                    }
                    isApplicable() {
                        return this.fetchButton() instanceof HTMLButtonElement
                    }
                    fetchButton() {
                        return document.querySelector(".js-update-branch-form button")
                    }
                    run() {
                        const e = this.fetchButton();
                        e && (e.scrollIntoView({
                            behavior: "smooth",
                            block: "center"
                        }), e.click())
                    }
                }
                i(je, "UpdateBranch");
                class De extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Convert to draft", this.icon = "git-pull-request-draft-color-fg-muted"
                    }
                    isApplicable() {
                        return this.fetchButton() instanceof HTMLButtonElement
                    }
                    fetchButton() {
                        return document.querySelector(".js-convert-to-draft")
                    }
                    run() {
                        var e;
                        const s = (e = this.fetchButton()) == null ? void 0 : e.closest("details");
                        s && (s.open = !0, setTimeout(() => {
                            var r;
                            (r = s.querySelector(".js-convert-to-draft")) == null || r.focus()
                        }, 0))
                    }
                }
                i(De, "ConvertToDraft");
                class _e extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Copy current branch name", this.icon = "copy-color-fg-muted"
                    }
                    isApplicable() {
                        return this.fetchClipboardCopy() instanceof T.Z
                    }
                    fetchClipboardCopy() {
                        return document.querySelector(".js-copy-branch")
                    }
                    async run(e) {
                        const s = this.fetchClipboardCopy();
                        if (s instanceof T.Z) {
                            const r = s.value;
                            try {
                                await (0, F.z)(r), e.displayFlash("success", "Branch name copied to clipboard!")
                            } catch {
                                e.displayFlash("error", "Unable to copy branch name to clipboard!")
                            }
                        }
                    }
                }
                i(_e, "CopyBranchName");
                const ot = [_e, Le, Pe, je, De, Y];
                class Ae extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Copy file permalink", this.icon = "copy-color-fg-muted"
                    }
                    isApplicable() {
                        return this.fetchPermalinkContainer() instanceof HTMLAnchorElement
                    }
                    fetchPermalinkContainer() {
                        return document.querySelector(".js-permalink-shortcut")
                    }
                    async run(e) {
                        const s = this.fetchPermalinkContainer();
                        if (s) {
                            const r = `${s.href}${window.location.hash}`;
                            try {
                                await (0, F.z)(r), e.displayFlash("success", "Copied permalink!")
                            } catch {
                                e.displayFlash("error", "Failed to copy permalink!")
                            }
                        }
                    }
                }
                i(Ae, "CopyPermalink");
                class Me extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Clone repository: Copy HTTPS", this.icon = "copy-color-fg-muted", this.priority = 4
                    }
                    isApplicable() {
                        return this.backendCommandsDisabled() && this.fetchClipboardCopy() instanceof T.Z
                    }
                    fetchClipboardCopy() {
                        return document.querySelector(".js-clone-url-http")
                    }
                    backendCommandsDisabled() {
                        return !!window.commandPalette && !window.commandPalette.hasAttribute("data-commands-path")
                    }
                    async run(e) {
                        const s = this.fetchClipboardCopy();
                        if (s instanceof T.Z) {
                            const r = s.value;
                            try {
                                await (0, F.z)(r), e.displayFlash("success", "Clone URL copied!")
                            } catch {
                                e.displayFlash("error", "Clone URL couldn't be copied")
                            }
                        }
                    }
                }
                i(Me, "CloneCopyHttps");
                class Be extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Clone repository: Copy SSH", this.icon = "copy-color-fg-muted", this.priority = 3
                    }
                    isApplicable() {
                        return this.backendCommandsDisabled() && this.fetchClipboardCopy() instanceof T.Z
                    }
                    fetchClipboardCopy() {
                        return document.querySelector(".js-clone-url-ssh")
                    }
                    backendCommandsDisabled() {
                        return !!window.commandPalette && !window.commandPalette.hasAttribute("data-commands-path")
                    }
                    async run(e) {
                        const s = this.fetchClipboardCopy();
                        if (s instanceof T.Z) {
                            const r = s.value;
                            try {
                                await (0, F.z)(r), e.displayFlash("success", "Clone URL copied!")
                            } catch {
                                e.displayFlash("error", "Clone URL couldn't be copied")
                            }
                        }
                    }
                }
                i(Be, "CloneCopySsh");
                class He extends d {
                    constructor() {
                        super(...arguments);
                        this.title = "Clone repository: Copy GitHub CLI", this.icon = "copy-color-fg-muted", this.priority = 2
                    }
                    isApplicable() {
                        return this.backendCommandsDisabled() && this.fetchClipboardCopy() instanceof T.Z
                    }
                    fetchClipboardCopy() {
                        return document.querySelector(".js-clone-url-gh-cli")
                    }
                    backendCommandsDisabled() {
                        return !!window.commandPalette && !window.commandPalette.hasAttribute("data-commands-path")
                    }
                    async run(e) {
                        const s = this.fetchClipboardCopy();
                        if (s instanceof T.Z) {
                            const r = s.value;
                            try {
                                await (0, F.z)(r), e.displayFlash("success", "Clone URL copied!")
                            } catch {
                                e.displayFlash("error", "Clone URL couldn't be copied")
                            }
                        }
                    }
                }
                i(He, "CloneCopyCli");
                const it = [Me, Be, He, Ae, Y];
                class ee extends rt.B {
                    constructor() {
                        super(...arguments);
                        this.itemsByType = {}, this.items = [], this.needsFetch = !0
                    }
                    enabledFor(e) {
                        return e.mode === ">"
                    }
                    get hasCommands() {
                        return !0
                    }
                    async fetch(e, s = !1) {
                        return this.loadCommandItems(e), {
                            results: e.isBlank() ? this.items : this.fuzzyFilter(this.items, e)
                        }
                    }
                    get debounce() {
                        return 0
                    }
                    loadCommandItems(e) {
                        this.needsFetch && (this.items = [...st.map(s => s.item()), ...ot.map(s => s.item()), ...it.map(s => s.item()), ...tt.map(s => s.item()), ...Ze.map(s => s.item())].filter(s => s.isApplicable(e)), this.needsFetch = !1)
                    }
                    clearCache() {
                        this.needsFetch = !0
                    }
                }
                i(ee, "MainWindowCommandsProvider"), window.commandPalette ? window.commandPalette.registerProvider("main-window-commands-provider", new ee) : window.addEventListener("command-palette-ready", () => {
                    var t;
                    (t = window.commandPalette) == null || t.registerProvider("main-window-commands-provider", new ee)
                });
                var B = l(1648),
                    nt = Object.defineProperty,
                    at = Object.getOwnPropertyDescriptor,
                    ke = i((t, e, s, r) => {
                        for (var o = r > 1 ? void 0 : r ? at(e, s) : e, n = t.length - 1, a; n >= 0; n--)(a = t[n]) && (o = (r ? a(e, s, o) : a(o)) || o);
                        return r && o && nt(e, s, o), o
                    }, "command_palette_input_element_decorateClass");
                let R = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.setupComplete = !1, this.connected = !1, this.multiPageEnabled = !1
                    }
                    static get observedAttributes() {
                        return ["value", "typeahead", "scope"]
                    }
                    setup() {
                        this.classList.add("d-flex", "flex-items-center", "flex-nowrap", "py-1", "pl-3", "pr-2", "border-bottom"), this.input = this.querySelector("input.js-input"), this.overlayInput = this.querySelector("input.js-overlay-input"), this.clearButton = this.querySelector(".js-clear"), this.scopeElement = this.querySelector("command-palette-scope"), this.searchIcon = this.querySelector(".js-search-icon"), this.spinner = this.querySelector(".js-spinner"), this.defaultScope = this.scope, this.hasAttribute("autofocus") && this.input.focus(), this.clearButton.hidden = !0, this.value.length !== 0 && this._dispatchEvent("command-palette-input"), this.setupComplete = !0
                    }
                    connectedCallback() {
                        this.setupComplete || this.setup(), this.value = this.getAttribute("value") || "", this.typeahead = this.getAttribute("typeahead") || "", this.placeholder = this.getAttribute("placeholder") || "", this.connected = !0
                    }
                    attributeChangedCallback(t, e, s) {
                        !this.input || (t === "typeahead" ? this.typeahead = s : t === "value" && (this.value = s, this._dispatchEvent("command-palette-input")))
                    }
                    focus() {
                        this.input.focus()
                    }
                    setRemovedTokenAndSelect(t) {
                        t && (this.value = t), this.focus(), this.input.select()
                    }
                    get scope() {
                        return this.scopeElement.scope
                    }
                    set scope(t) {
                        this.scopeElement.scope = t, this.clearButton.hidden = !this.hasSomethingToClear()
                    }
                    hasScope() {
                        return this.scopeElement.hasScope()
                    }
                    clearScope() {
                        return this.scopeElement.clearScope()
                    }
                    removeToken() {
                        return this.scopeElement.removeToken()
                    }
                    get placeholder() {
                        return this.input.getAttribute("placeholder") || ""
                    }
                    set placeholder(t) {
                        this.input.setAttribute("placeholder", t)
                    }
                    get typeaheadPlaceholder() {
                        var t;
                        return ((t = (0, c.P4)(this, "typeaheadPlaceholder")) == null ? void 0 : t.textContent) || ""
                    }
                    set typeaheadPlaceholder(t) {
                        const e = (0, c.P4)(this, "typeaheadPlaceholder");
                        e.textContent = t
                    }
                    get value() {
                        var t;
                        return ((t = this.input) == null ? void 0 : t.value) || ""
                    }
                    set value(t) {
                        this.input.value = t, this.typeahead = t, this.resetPlaceholder(), this.onInput()
                    }
                    get overlay() {
                        return this.overlayInput.value
                    }
                    set overlay(t) {
                        this.overlayInput.value = t
                    }
                    set mirror(t) {
                        const e = (0, c.P4)(this, "mirror");
                        e.textContent = t
                    }
                    get typeaheadText() {
                        return (0, c.P4)(this, "typeaheadText").textContent || ""
                    }
                    set typeaheadText(t) {
                        const e = (0, c.P4)(this, "typeaheadText");
                        e.textContent = t
                    }
                    get typeahead() {
                        return this.typeaheadValue
                    }
                    set typeahead(t) {
                        if (this.typeaheadValue = this.overlay + t, this.mirror = this.value, t === "") this.typeaheadText = "";
                        else if (this.placeholder = "", this.typeaheadPlaceholder = "", this.valueStartsWithTypeahead) {
                            const e = this.value.length - (this.overlay ? 1 : 0);
                            this.typeaheadText = t.substring(e)
                        } else this.typeaheadText = ` \u2013 ${t}`
                    }
                    showModePlaceholder(t = "") {
                        this.typeaheadPlaceholder = t
                    }
                    get valueStartsWithTypeahead() {
                        return this.typeaheadValue.toLowerCase().startsWith(this.value.toLowerCase())
                    }
                    get isCursorAtEnd() {
                        return this.value.length === this.input.selectionStart
                    }
                    set loading(t) {
                        this.spinner.hidden = !t, this.searchIcon.hidden = t
                    }
                    resetScopeIfNeeded() {
                        !this.multiPageEnabled && this.value === "" && this.scope.id !== this.defaultScope.id && (this.scope = this.defaultScope)
                    }
                    resetPlaceholder() {
                        this.value.replace(this.overlay, "") && this.overlay && (this.typeaheadPlaceholder = ""), this.placeholder = this.getAttribute("placeholder") || ""
                    }
                    onInput() {
                        this.resetPlaceholder(), this.clearButton.hidden = !this.hasSomethingToClear(), !!this.connected && this._dispatchEvent("command-palette-input")
                    }
                    onClear(t) {
                        t instanceof KeyboardEvent && t.key !== "Escape" || (this.value = "", this.input.focus(), this._dispatchEvent("command-palette-cleared"))
                    }
                    onKeydown(t) {
                        if (this.isSelectKeystroke(t.key) && (this._dispatchEvent("command-palette-select"), t.stopImmediatePropagation(), t.preventDefault()), this.hasSomethingToClear() && (0, B.o)(t) && t.key === "Backspace") {
                            this.onClear();
                            return
                        }
                        if (this.input.selectionStart === 0 && this.input.selectionEnd === 0 && (this.hasScope() || this.multiPageEnabled) && t.key === "Backspace") {
                            this._dispatchEvent("command-palette-descope"), t.stopImmediatePropagation(), t.preventDefault();
                            return
                        }
                    }
                    hasSomethingToClear() {
                        return this.scopeElement.hasScope() || this.value.length > 0
                    }
                    isSelectKeystroke(t) {
                        return t === "Tab" || t === "ArrowRight" && this.isCursorAtEnd
                    }
                    textSelected() {
                        return this.input.selectionStart !== this.input.selectionEnd
                    }
                    _dispatchEvent(t) {
                        const e = new CustomEvent(t, {
                            cancelable: !0,
                            detail: {
                                typeahead: this.typeahead,
                                value: this.value
                            }
                        });
                        return this.dispatchEvent(e)
                    }
                }, "CommandPaletteInputElement");
                R.tagName = "command-palette-input", ke([c.Lj], R.prototype, "multiPageEnabled", 2), R = ke([c.Ih], R);
                var ct = l(11793),
                    lt = l(86404),
                    ut = l(34078),
                    Oe = l(64463);
                window.customElements.get(B.Z.tagName) || window.customElements.define(B.Z.tagName, B.Z);

                function dt() {
                    document.addEventListener("keydown", ht), (0, Oe.N7)(".js-command-palette-dialog", t => {
                        if (!t) return;
                        const e = te();
                        !e || t.addEventListener("toggle", () => {
                            t.open ? e.activate() : e.deactivate()
                        })
                    }), (0, Oe.N7)(".js-socket-channel.js-updatable-content", {
                        subscribe: t => (0, lt.RB)(t, "socket:message", () => {
                            const e = te();
                            !e || e.clearCommands(!1)
                        })
                    })
                }
                i(dt, "observeCommandPalette");

                function te() {
                    return document.querySelector(B.Z.tagName)
                }
                i(te, "findCommandPalette");

                function ht(t) {
                    if (!t.code) return;
                    const e = te();
                    if (!e) return;
                    const s = yt(),
                        r = $(e.platformCommandModeHotkey, t),
                        o = !mt(t) && !s && ($(e.platformActivationHotkey, t) || r),
                        n = !s && ($(e.platformSecondardActivationHotkey, t) || r),
                        a = e.hasAttribute("data-memex-hotkey-enabled") && s && $(e.platformMemexActivationHotkey, t);
                    (o || n || a) && (vt(r), t.preventDefault(), t.stopPropagation())
                }
                i(ht, "handleKeyDown");

                function $(t, e) {
                    let s = (0, ct.EL)(e);
                    return s = s.replace("\u02DA", "k"), t.split(",").some(r => s === r)
                }
                i($, "hotkeyMatchesEvent");

                function mt(t) {
                    return pt(t) || ft(t)
                }
                i(mt, "shouldIgnoreActivation");

                function pt(t) {
                    const e = t.target;
                    return e ? e.closest(".js-previewable-comment-form") !== null : !1
                }
                i(pt, "triggeredInsideAPreviewableCommentForm");

                function ft(t) {
                    const e = t.target;
                    if (!e) return !1;
                    const s = e.closest(".js-code-editor");
                    if (!s) return !1;
                    const r = (0, ut.P)(s);
                    if (!r) return !1;
                    const o = r.editor;
                    if (!o) return !1;
                    const n = o.getMode().name;
                    return n === "gfm" || n === "markdown"
                }
                i(ft, "triggeredInsideAMarkdownCodeEditor");

                function yt() {
                    return !!document.querySelector("#memex-root")
                }
                i(yt, "triggeredInsideMemex");

                function vt(t) {
                    for (const e of document.querySelectorAll(".js-command-palette-dialog")) {
                        const s = e.querySelector(R.tagName);
                        if (!s) return;
                        if (e.open) e.open = !1;
                        else {
                            gt(s, t);
                            const r = e.querySelector(B.Z.tagName);
                            r && (r.previouslyActiveElement = document.activeElement), e.open = !0
                        }
                    }
                }
                i(vt, "toggleCommandPalette");

                function gt(t, e) {
                    const s = t.value.startsWith(">");
                    return e && !s ? (t.value = `>${t.value}`, !0) : !e && s ? (t.value = t.value.substring(1), !0) : !1
                }
                i(gt, "toggleCommandMode"), dt()
            },
            34078: (y, v, l) => {
                l.d(v, {
                    P: () => x,
                    g: () => m
                });
                var c = l(59753);
                const g = new WeakMap;

                function x(u) {
                    return g.get(u)
                }
                i(x, "getCodeEditor");
                async function m(u) {
                    return g.get(u) || p(await h(u, "codeEditor:ready"))
                }
                i(m, "getAsyncCodeEditor");

                function p(u) {
                    if (!(u instanceof CustomEvent)) throw new Error("assert: event is not a CustomEvent");
                    const b = u.detail.editor;
                    if (!u.target) throw new Error("assert: event.target is null");
                    return g.set(u.target, b), b
                }
                i(p, "onEditorFromEvent"), (0, c.on)("codeEditor:ready", ".js-code-editor", p);

                function h(u, b) {
                    return new Promise(S => {
                        u.addEventListener(b, S, {
                            once: !0
                        })
                    })
                }
                i(h, "nextEvent")
            },
            74030: (y, v, l) => {
                l.d(v, {
                    I3: () => c,
                    h5: () => x,
                    on: () => m,
                    yn: () => p
                });

                function c() {
                    if (g("dark")) return "dark";
                    if (g("light")) return "light"
                }
                i(c, "getPreferredColorMode");

                function g(h) {
                    return window.matchMedia && window.matchMedia(`(prefers-color-scheme: ${h})`).matches
                }
                i(g, "prefersColorScheme");

                function x(h) {
                    const u = document.querySelector("html[data-color-mode]");
                    !u || u.setAttribute("data-color-mode", h)
                }
                i(x, "setClientMode");

                function m(h, u) {
                    const b = document.querySelector("html[data-color-mode]");
                    !b || b.setAttribute(`data-${u}-theme`, h)
                }
                i(m, "setClientTheme");

                function p(h) {
                    const u = document.querySelector("html[data-color-mode]");
                    if (!!u) return u.getAttribute(`data-${h}-theme`)
                }
                i(p, "getClientTheme")
            },
            86404: (y, v, l) => {
                l.d(v, {
                    RB: () => g,
                    qC: () => x,
                    w0: () => c
                });
                class c {
                    constructor(p) {
                        this.closed = !1, this.unsubscribe = () => {
                            p(), this.closed = !0
                        }
                    }
                }
                i(c, "Subscription");

                function g(m, p, h, u = {
                    capture: !1
                }) {
                    return m.addEventListener(p, h, u), new c(() => {
                        m.removeEventListener(p, h, u)
                    })
                }
                i(g, "fromEvent");

                function x(...m) {
                    return new c(() => {
                        for (const p of m) p.unsubscribe()
                    })
                }
                i(x, "compose")
            }
        },
        y => {
            var v = i(c => y(y.s = c), "__webpack_exec__");
            y.O(0, [5724, 6319, 9255, 5623], () => v(92191));
            var l = y.O()
        }
    ]);
})();

//# sourceMappingURL=command-palette-2e40c087079d.js.map