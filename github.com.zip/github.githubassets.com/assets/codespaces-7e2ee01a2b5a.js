"use strict";
(() => {
    var le = Object.defineProperty;
    var c = (x, L) => le(x, "name", {
        value: L,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [7807], {
            79535: (x, L, h) => {
                var g = h(64463),
                    m = h(59753),
                    f = h(65935),
                    d = h(82036);
                (0, m.on)("click", ".js-codespaces-update-skus-url", e => {
                    const t = e.currentTarget;
                    if (!t) return;
                    const n = t.getAttribute("data-refname");
                    if (document.querySelector("form.js-prefetch-codespace-location") && n) {
                        const a = document.querySelector("[data-codespace-skus-url]"),
                            S = a ? a.getAttribute("data-codespace-skus-url") : "";
                        if (S) {
                            const _ = new URL(S, window.location.origin);
                            _.searchParams.set("ref_name", n), a && a.setAttribute("data-codespace-skus-url", _.toString()), a && a.setAttribute("data-branch-has-changed", "true")
                        }
                    }
                }), (0, m.on)("remote-input-error", "#js-codespaces-repository-select", () => {
                    const e = document.querySelector("#js-codespaces-unable-load-repositories-warning");
                    e.hidden = !1
                }), (0, f.AC)(".js-new-codespace-form", async function(e, t) {
                    const n = e.closest("[data-replace-remote-form-target]"),
                        r = n.querySelector(".js-new-codespace-submit-button");
                    r instanceof HTMLInputElement && (r.disabled = !0), e.classList.remove("is-error"), e.classList.add("is-loading");
                    try {
                        const a = await t.html();
                        n.replaceWith(a.html)
                    } catch {
                        e.classList.remove("is-loading"), e.classList.add("is-error")
                    }
                });
                let l = null;

                function o(e) {
                    l = e, e !== null && document.querySelector(".js-codespace-loading-steps").setAttribute("data-current-state", l)
                }
                c(o, "advanceLoadingState"), (0, g.N7)(".js-codespace-loading-steps", {
                    constructor: HTMLElement,
                    add: e => {
                        const t = e.getAttribute("data-current-state");
                        t && o(t)
                    }
                }), (0, g.N7)(".js-codespace-advance-state", {
                    constructor: HTMLElement,
                    add: e => {
                        const t = e.getAttribute("data-state");
                        t && o(t)
                    }
                });
                let u = null;

                function E(e) {
                    (0, f.AC)(".js-fetch-cascade-token", async function(t, n) {
                        try {
                            u = (await n.json()).json.token
                        } catch {}
                    }), (0, d.Bt)(e)
                }
                c(E, "fetchCascadeToken");

                function v(e, t, n) {
                    if (document.querySelector(e)) {
                        const a = Date.now(),
                            _ = setInterval(c(() => {
                                const U = Date.now() - a;
                                if (u || U >= n) {
                                    clearInterval(_), t(u || void 0);
                                    return
                                }
                            }, "checkToken"), 50)
                    }
                }
                c(v, "waitForCascadeTokenWithTimeout"), (0, g.N7)(".js-auto-submit-form", {
                    constructor: HTMLFormElement,
                    initialize: d.Bt
                }), (0, g.N7)(".js-workbench-form-container", {
                    constructor: HTMLElement,
                    add: e => {
                        const t = e.querySelector(".js-cascade-token");
                        y(e, t)
                    }
                });

                function y(e, t) {
                    if (t.value !== "") {
                        const n = e.querySelector("form");
                        (0, d.Bt)(n)
                    } else {
                        const n = document.querySelector(".js-fetch-cascade-token");
                        E(n), v(".js-workbench-form-container", A, 1e4)
                    }
                }
                c(y, "resolveCascadeToken");

                function A(e) {
                    const t = document.querySelector(".js-workbench-form-container form");
                    t && e ? (I(t, e), b(t, e), (0, d.Bt)(t)) : o("failed")
                }
                c(A, "insertCodespaceTokenIntoShowAuthForm");

                function I(e, t) {
                    const n = e.querySelector(".js-cascade-token");
                    n && n.setAttribute("value", t)
                }
                c(I, "insertCodespaceTokenIntoCascadeField");

                function b(e, t) {
                    const n = e.querySelector(".js-partner-info");
                    if (n) {
                        let r = n.getAttribute("value");
                        r && (r = r.replace("%CASCADE_TOKEN_PLACEHOLDER%", t), n.setAttribute("value", r))
                    }
                }
                c(b, "insertCodespaceTokenIntoPartnerInfo");
                var i = h(90420),
                    k = h(69567),
                    s = h(51374),
                    p = h(10900),
                    w = h(83956);
                (0, m.on)("submit", ".js-toggle-hidden-codespace-form", function(e) {
                    const t = e.currentTarget;
                    T(t)
                }), (0, m.on)("click", ".js-create-codespace-with-sku-button", async function(e) {
                    const t = e.currentTarget,
                        n = t.closest("[data-target*='new-codespace.createCodespaceForm']") || t.closest("[data-target*='new-codespace.createCodespaceWithSkuSelectForm']");
                    await (0, w.M)(n), n.classList.contains("js-open-in-vscode-form") ? (T(n), H(n)) : (n.submit(), D())
                });

                function T(e) {
                    const t = e.querySelectorAll(".js-toggle-hidden");
                    for (const r of t) r.hidden = !r.hidden;
                    const n = e.querySelectorAll(".js-toggle-disabled");
                    for (const r of n) r.getAttribute("aria-disabled") ? r.removeAttribute("aria-disabled") : r.setAttribute("aria-disabled", "true")
                }
                c(T, "toggleFormSubmissionInFlight");

                function C(e) {
                    return e.closest("[data-replace-remote-form-target]")
                }
                c(C, "getFormTarget");
                async function D() {
                    const e = document.querySelector(".js-codespaces-details-container");
                    e && (e.open = !1);
                    const t = document.querySelector("new-codespace");
                    if (t && !t.getAttribute("data-no-submit-on-create")) try {
                        const n = await fetch("/codespaces/new");
                        if (n && n.ok) {
                            const r = (0, p.r)(document, await n.text());
                            t.replaceWith(r)
                        }
                    } catch {}
                }
                c(D, "createFormSubmitted"), (0, m.on)("submit", ".js-create-codespaces-form-command", function(e) {
                    const t = e.currentTarget;
                    t.classList.contains("js-open-in-vscode-form") || (D(), T(t))
                }), (0, m.on)("submit", "form.js-codespaces-delete-form", async function(e) {
                    e.preventDefault();
                    const t = e.currentTarget;
                    try {
                        const n = await fetch(t.action, {
                            method: t.method,
                            body: new FormData(t),
                            headers: {
                                Accept: "text/fragment+html",
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        });
                        if (n.ok) {
                            const r = (0, p.r)(document, await n.text());
                            C(t).replaceWith(r)
                        } else if (n.status === 401) t.submit();
                        else throw new Error(`Unexpected response: ${n.statusText}`)
                    } finally {
                        T(t)
                    }
                }), (0, m.on)("submit", "form.js-open-in-vscode-form", async function(e) {
                    e.preventDefault();
                    const t = e.currentTarget;
                    await H(t)
                });
                async function M(e, t) {
                    const n = document.querySelector(`#${e}`),
                        r = await (0, s.W)({
                            content: n.content.cloneNode(!0),
                            dialogClass: "project-dialog"
                        });
                    return t && t.setAttribute("aria-expanded", "true"), r.addEventListener("dialog:remove", function() {
                        t && T(t)
                    }, {
                        once: !0
                    }), r
                }
                c(M, "openDialog");
                async function H(e) {
                    const t = await fetch(e.action, {
                        method: e.method,
                        body: new FormData(e),
                        headers: {
                            Accept: "application/json",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    });
                    if (t.ok) {
                        const n = await t.json();
                        n.codespace_url ? (window.location.href = n.codespace_url, T(e), D(), $()) : (e.closest("get-repo") || e.closest("new-codespace") ? (e.setAttribute("data-src", n.loading_url), e.dispatchEvent(new CustomEvent("pollvscode"))) : e.closest("prefetch-pane") && (e.setAttribute("data-src", n.loading_url), e.dispatchEvent(new CustomEvent("prpollvscode"))), T(e))
                    } else if (t.status === 422) {
                        const n = await t.json();
                        if (n.error_type === "concurrency_limit_error") await M("concurrency-error", e);
                        else {
                            const r = document.querySelector("template.js-flash-template"),
                                a = n.error;
                            r.after(new k.R(r, {
                                className: "flash-error",
                                message: a
                            })), T(e)
                        }
                    }
                }
                c(H, "createCodespaceIntoVscode");
                async function $() {
                    const e = document.querySelector(".js-codespaces-completable"),
                        t = e && e.getAttribute("data-src");
                    if (!t) return;
                    const n = await fetch(t, {
                        method: "GET",
                        headers: {
                            Accept: "text/fragment+html",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    });
                    if (n.ok) {
                        const r = (0, p.r)(document, await n.text());
                        e.replaceWith(r)
                    } else throw new Error(`Unexpected response: ${n.statusText}`)
                }
                c($, "renderAllDone");
                var q = Object.defineProperty,
                    X = Object.getOwnPropertyDescriptor,
                    K = c((e, t, n, r) => {
                        for (var a = r > 1 ? void 0 : r ? X(t, n) : t, S = e.length - 1, _; S >= 0; S--)(_ = e[S]) && (a = (r ? _(t, n, a) : _(a)) || a);
                        return r && a && q(t, n, a), a
                    }, "__decorateClass");
                let Z = c(class extends HTMLElement {
                    async connectedCallback() {
                        M("concurrency-error")
                    }
                }, "ConcurrencyLimitElement");
                Z = K([i.Ih], Z);
                var J = Object.defineProperty,
                    Y = Object.getOwnPropertyDescriptor,
                    P = c((e, t, n, r) => {
                        for (var a = r > 1 ? void 0 : r ? Y(t, n) : t, S = e.length - 1, _; S >= 0; S--)(_ = e[S]) && (a = (r ? _(t, n, a) : _(a)) || a);
                        return r && a && J(t, n, a), a
                    }, "new_codespace_element_decorateClass");
                let O = c(class extends HTMLElement {
                    async connectedCallback() {
                        const e = this.formForLocations();
                        if (e) {
                            const t = await (0, w.M)(e, !this.vscsLocationList);
                            this.updatePickableLocations(t)
                        }
                    }
                    formForLocations() {
                        return this.advancedOptionsForm || this.createCodespaceForm
                    }
                    toggleLoadingVscode() {
                        const e = this.loadingVscode.hidden,
                            t = this.children;
                        for (let n = 0; n < t.length; n++) t[n].hidden = e;
                        this.loadingVscode.hidden = !e
                    }
                    machineTypeSelected(e) {
                        const n = e.currentTarget.getAttribute("data-sku-name");
                        this.skuNameInput && n && (this.skuNameInput.value = n), this.advancedOptionsForm && this.advancedOptionsForm.requestSubmit()
                    }
                    pollForVscode(e) {
                        this.toggleLoadingVscode();
                        const t = e.currentTarget.getAttribute("data-src");
                        t && this.vscodePoller.setAttribute("src", t)
                    }
                    async updatePickableLocations(e) {
                        const t = this.formForLocations();
                        if (!e && t) {
                            const a = t.getAttribute("data-codespace-locations-url");
                            if (!a) return;
                            e = await (0, w.W)(a)
                        }
                        const n = e.current,
                            r = e.available;
                        this.hideUnavailableLocations(r), this.preventSubmissionOfUnavailableLocation(r, n)
                    }
                    hideUnavailableLocations(e) {
                        if (!!this.vscsLocationList)
                            if (this.advancedOptionsForm) {
                                const t = this.vscsLocationList.querySelectorAll(".select-menu-item");
                                for (const n of t) {
                                    const r = n.querySelector("input");
                                    if (r && e.includes(r.getAttribute("data-location"))) {
                                        n.removeAttribute("hidden");
                                        continue
                                    }
                                    r && (r.removeAttribute("checked"), r.setAttribute("aria-checked", "false")), n.setAttribute("hidden", "hidden")
                                }
                            } else {
                                const t = this.vscsLocationList.querySelectorAll(".SelectMenu-item");
                                for (const n of t) e.includes(n.getAttribute("data-location")) ? n.removeAttribute("hidden") : n.setAttribute("hidden", "hidden")
                            }
                    }
                    preventSubmissionOfUnavailableLocation(e, t) {
                        if (this.createCodespaceForm) {
                            const n = this.createCodespaceForm.querySelector('[name="codespace[location]"]');
                            n && !e.includes(n.value) && (n.value = t, this.vscsLocationSummary && (this.vscsLocationSummary.textContent = this.vscsLocationSummary.getAttribute("data-blank-title")))
                        }
                        if (this.advancedOptionsForm) {
                            const n = this.advancedOptionsForm.querySelector('[name="location"]');
                            n && !e.includes(n.value) && (n.value = t), !this.advancedOptionsForm.querySelector('[name="location"]:checked') && this.autoSelectLocation && this.autoSelectLocation.hidden && (this.selectedLocation && this.selectedLocation.setAttribute("hidden", "hidden"), this.needsSelectedLocation && this.needsSelectedLocation.removeAttribute("hidden"))
                        }
                    }
                    vscsTargetUrlUpdated(e) {
                        const t = e.currentTarget;
                        this.vscsTargetUrl.value = t.value
                    }
                }, "NewCodespaceElement");
                P([i.fA], O.prototype, "form", 2), P([i.fA], O.prototype, "createCodespaceForm", 2), P([i.fA], O.prototype, "createCodespaceWithSkuSelectForm", 2), P([i.fA], O.prototype, "vscsTargetUrl", 2), P([i.fA], O.prototype, "vscsLocationList", 2), P([i.fA], O.prototype, "vscsLocationSummary", 2), P([i.fA], O.prototype, "loadingVscode", 2), P([i.fA], O.prototype, "vscodePoller", 2), P([i.fA], O.prototype, "advancedOptionsForm", 2), P([i.fA], O.prototype, "locationResubmitParam", 2), P([i.fA], O.prototype, "skuNameInput", 2), P([i.fA], O.prototype, "selectedLocation", 2), P([i.fA], O.prototype, "autoSelectLocation", 2), P([i.fA], O.prototype, "needsSelectedLocation", 2), O = P([i.Ih], O);
                var ee = Object.defineProperty,
                    te = Object.getOwnPropertyDescriptor,
                    N = c((e, t, n, r) => {
                        for (var a = r > 1 ? void 0 : r ? te(t, n) : t, S = e.length - 1, _; S >= 0; S--)(_ = e[S]) && (a = (r ? _(t, n, a) : _(a)) || a);
                        return r && a && ee(t, n, a), a
                    }, "export_branch_element_decorateClass");
                let W = c(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.abortPoll = null
                    }
                    connectedCallback() {
                        this.abortPoll = new AbortController, this.loadingIndicator.hidden || this.startPoll()
                    }
                    disconnectedCallback() {
                        var e;
                        (e = this.abortPoll) == null || e.abort()
                    }
                    async exportBranch(e) {
                        e.preventDefault(), this.form.hidden = !0, this.loadingIndicator.hidden = !1, (await fetch(this.form.action, {
                            method: this.form.method,
                            body: new FormData(this.form),
                            headers: {
                                Accept: "text/fragment+html",
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        })).ok ? this.startPoll() : (this.form.hidden = !1, this.loadingIndicator.hidden = !0)
                    }
                    async startPoll() {
                        const e = this.getAttribute("data-exported-codespace-url") || "",
                            t = await this.poll(e);
                        if (t)
                            if (t.ok) this.loadingIndicator.hidden = !0, this.viewBranchLink.hidden = !1;
                            else {
                                const n = this.getAttribute("data-export-error-redirect-url") || "";
                                window.location.href = n
                            }
                    }
                    async poll(e, t = 1e3) {
                        var n, r;
                        if ((n = this.abortPoll) == null ? void 0 : n.signal.aborted) return;
                        const a = await fetch(e, {
                            signal: (r = this.abortPoll) == null ? void 0 : r.signal
                        });
                        return a.status === 202 ? (await new Promise(S => setTimeout(S, t)), this.poll(e, t * 1.5)) : a
                    }
                }, "ExportBranchElement");
                N([i.fA], W.prototype, "form", 2), N([i.fA], W.prototype, "loadingIndicator", 2), N([i.fA], W.prototype, "viewBranchLink", 2), W = N([i.Ih], W);
                var ne = h(52660),
                    se = Object.defineProperty,
                    oe = Object.getOwnPropertyDescriptor,
                    j = c((e, t, n, r) => {
                        for (var a = r > 1 ? void 0 : r ? oe(t, n) : t, S = e.length - 1, _; S >= 0; S--)(_ = e[S]) && (a = (r ? _(t, n, a) : _(a)) || a);
                        return r && a && se(t, n, a), a
                    }, "options_popover_element_decorateClass");
                let B = c(class extends HTMLElement {
                    reset(e) {
                        for (e.preventDefault(), this.dropdownDetails.hidden = !1, this.modalDetails.hidden = !0, this.exportDetails.hidden = !0, this.skuForm.hidden = !1; this.resultMessage.firstChild;) this.resultMessage.removeChild(this.resultMessage.firstChild);
                        this.resultMessage.hidden = !0, this.errorMessage.hidden = !0
                    }
                    showSettingsModal() {
                        this.dropdownDetails.hidden = !0, this.modalDetails.open = !0, this.modalDetails.hidden = !1
                    }
                    showExportModal() {
                        this.dropdownDetails.hidden = !0, this.exportDetails.open = !0, this.exportDetails.hidden = !1, this.insertBranchExportComponent()
                    }
                    async insertBranchExportComponent() {
                        const e = this.querySelector("[data-branch-export-url]");
                        if (!e) return;
                        const t = e.getAttribute("data-branch-export-url");
                        if (!t) return;
                        const n = await (0, ne.a)(document, t);
                        !n || (e.innerHTML = "", e.appendChild(n))
                    }
                }, "OptionsPopoverElement");
                j([i.fA], B.prototype, "dropdownDetails", 2), j([i.fA], B.prototype, "modalDetails", 2), j([i.fA], B.prototype, "settingsModal", 2), j([i.fA], B.prototype, "skuForm", 2), j([i.fA], B.prototype, "resultMessage", 2), j([i.fA], B.prototype, "errorMessage", 2), j([i.fA], B.prototype, "exportDetails", 2), B = j([i.Ih], B);
                var re = Object.defineProperty,
                    ie = Object.getOwnPropertyDescriptor,
                    F = c((e, t, n, r) => {
                        for (var a = r > 1 ? void 0 : r ? ie(t, n) : t, S = e.length - 1, _; S >= 0; S--)(_ = e[S]) && (a = (r ? _(t, n, a) : _(a)) || a);
                        return r && a && re(t, n, a), a
                    }, "prefetch_pane_element_decorateClass");
                let R = c(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.prefetching = !1, this.remainingRetries = 3
                    }
                    async connectedCallback() {
                        this.openSkuButton && this.skipSkuButton ? (await this.prefetchLocationAndSkus(), this.hideSpinner(), this.hidden = !1) : this.showOpenSkuButton()
                    }
                    async prefetchLocationAndSkus() {
                        const e = this.getAttribute("data-branch-has-changed") === "true";
                        if (this.prefetching && !e) return;
                        const t = document.querySelector("form.js-prefetch-codespace-location") || document.querySelector("form.js-open-in-vscode-form");
                        if (t) {
                            this.prefetching = !0;
                            const n = await (0, w.M)(t);
                            if (n && (this.currentLocation = n.current), !this.skuSelect) return;
                            const r = this.getAttribute("data-codespace-skus-url");
                            if (this.currentLocation && r) {
                                const a = await fetch(`${r}&location=${this.currentLocation}`, {
                                    headers: {
                                        "X-Requested-With": "XMLHttpRequest",
                                        Accept: "text/html_fragment"
                                    }
                                });
                                if (a.ok) {
                                    this.setAttribute("data-branch-has-changed", "false");
                                    const S = (0, p.r)(document, await a.text()),
                                        U = Array.from(S.querySelectorAll("input[name='codespace[sku_name]']")).filter(V => !V.disabled),
                                        G = U.find(V => V.checked);
                                    G && this.defaultSkuPreview ? (this.defaultSkuPreview.innerHTML = G.getAttribute("data-preview") || "", this.showSkipSkuButton()) : U.length === 1 ? (G || U[0].select(), this.showSkipSkuButton()) : this.disableDropDownButton(), this.skuSelect.replaceWith(S), this.skuSelect.hidden = !1, this.skuError && (this.skuError.hidden = !0)
                                } else this.showOpenSkuButton(), this.remainingRetries -= 1, this.remainingRetries > 0 && (this.prefetching = !1), this.skuSelect.hidden = !0, this.skuError && (this.skuError.hidden = !1)
                            }
                        }
                    }
                    showOpenSkuButton() {
                        var e;
                        this.shownButton === void 0 && this.openSkuButton && (this.shownButton = this.openSkuButton, this.shownButton.hidden = !1, (e = this.skipSkuButton) == null || e.remove())
                    }
                    hideSpinner() {
                        const e = document.querySelector("[data-target='codespacesCreateButtonSpinner']");
                        e && (e.hidden = !0)
                    }
                    disableDropDownButton() {
                        this.dropdownButton && (this.useAdvancedCreation(), this.dropdownButton.style.pointerEvents = "none", this.dropdownButton.classList.add("color-fg-muted"))
                    }
                    showSkipSkuButton() {
                        var e, t;
                        if (this.shownButton === void 0 && this.skipSkuButton) {
                            this.shownButton = this.skipSkuButton, this.shownButton.hidden = !1;
                            const n = (e = this.openSkuButton) == null ? void 0 : e.parentElement;
                            n && n instanceof HTMLDetailsElement && (n.hidden = !0), (t = this.openSkuButton) == null || t.remove()
                        }
                    }
                    toggleLoadingVscode() {
                        if (this.loadingVscode) {
                            const e = this.loadingVscode.hidden,
                                t = this.children;
                            for (let n = 0; n < t.length; n++) t[n].hidden = e;
                            this.loadingVscode.hidden = !e
                        }
                    }
                    pollForVscode(e) {
                        if (this.vscodePoller) {
                            this.toggleLoadingVscode();
                            const t = e.currentTarget.getAttribute("data-src");
                            t && this.vscodePoller.setAttribute("src", t)
                        }
                    }
                    useBasicCreation() {
                        this.advancedOptionsLink && (this.openSkuButton && (this.openSkuButton.hidden = !1), this.skipSkuButton && (this.skipSkuButton.hidden = !1), this.advancedOptionsLink && (this.advancedOptionsLink.hidden = !0)), this.basicOptionsCheck && this.basicOptionsCheck.classList.remove("v-hidden"), this.advancedOptionsCheck && this.advancedOptionsCheck.classList.add("v-hidden"), this.selectionDetails.open = !1
                    }
                    useAdvancedCreation() {
                        this.advancedOptionsLink && (this.openSkuButton && (this.openSkuButton.hidden = !0), this.skipSkuButton && (this.skipSkuButton.hidden = !0), this.advancedOptionsLink.hidden = !1), this.basicOptionsCheck && this.basicOptionsCheck.classList.add("v-hidden"), this.advancedOptionsCheck && this.advancedOptionsCheck.classList.remove("v-hidden"), this.selectionDetails.open = !1
                    }
                }, "PrefetchPaneElement");
                F([i.fA], R.prototype, "skuSelect", 2), F([i.fA], R.prototype, "skuError", 2), F([i.fA], R.prototype, "selectionDetails", 2), F([i.fA], R.prototype, "loadingVscode", 2), F([i.fA], R.prototype, "vscodePoller", 2), F([i.fA], R.prototype, "openSkuButton", 2), F([i.fA], R.prototype, "skipSkuButton", 2), F([i.fA], R.prototype, "defaultSkuPreview", 2), F([i.fA], R.prototype, "dropdownButton", 2), F([i.fA], R.prototype, "advancedOptionsLink", 2), F([i.fA], R.prototype, "basicOptionsCheck", 2), F([i.fA], R.prototype, "advancedOptionsCheck", 2), R = F([i.Ih], R);
                var ae = Object.defineProperty,
                    ce = Object.getOwnPropertyDescriptor,
                    Q = c((e, t, n, r) => {
                        for (var a = r > 1 ? void 0 : r ? ce(t, n) : t, S = e.length - 1, _; S >= 0; S--)(_ = e[S]) && (a = (r ? _(t, n, a) : _(a)) || a);
                        return r && a && ae(t, n, a), a
                    }, "vscode_forwarder_element_decorateClass");
                let z = c(class extends HTMLElement {
                    async connectedCallback() {
                        this.closeDetailsPopover();
                        const e = this.getAttribute("data-codespace-url");
                        e && (window.location.href = e)
                    }
                    closeDetailsPopover() {
                        const e = document.querySelector(".js-codespaces-details-container");
                        e && (e.open = !1)
                    }
                }, "VscodeForwarderElement");
                Q([i.fA], z.prototype, "vscodeLink", 2), z = Q([i.Ih], z);
                var de = h(9115),
                    ue = h(68906)
            },
            52134: (x, L, h) => {
                h.d(L, {
                    H: () => f,
                    v: () => m
                });
                var g = h(59753);

                function m() {
                    const d = document.getElementById("ajax-error-message");
                    d && (d.hidden = !1)
                }
                c(m, "showGlobalError");

                function f() {
                    const d = document.getElementById("ajax-error-message");
                    d && (d.hidden = !0)
                }
                c(f, "hideGlobalError"), (0, g.on)("deprecatedAjaxError", "[data-remote]", function(d) {
                    const l = d.detail,
                        {
                            error: o,
                            text: u
                        } = l;
                    d.currentTarget === d.target && (o === "abort" || o === "canceled" || (/<html/.test(u) ? (m(), d.stopImmediatePropagation()) : setTimeout(function() {
                        d.defaultPrevented || m()
                    }, 0)))
                }), (0, g.on)("deprecatedAjaxSend", "[data-remote]", function() {
                    f()
                }), (0, g.on)("click", ".js-ajax-error-dismiss", function() {
                    f()
                })
            },
            51374: (x, L, h) => {
                h.d(L, {
                    W: () => m
                });
                var g = h(59753);
                async function m(f) {
                    const l = document.querySelector("#site-details-dialog").content.cloneNode(!0),
                        o = l.querySelector("details"),
                        u = o.querySelector("details-dialog"),
                        E = o.querySelector(".js-details-dialog-spinner");
                    f.detailsClass && o.classList.add(...f.detailsClass.split(" ")), f.dialogClass && u.classList.add(...f.dialogClass.split(" ")), f.label ? u.setAttribute("aria-label", f.label) : f.labelledBy && u.setAttribute("aria-labelledby", f.labelledBy), document.body.append(l);
                    const v = await f.content;
                    return E.remove(), u.prepend(v), o.addEventListener("toggle", () => {
                        o.hasAttribute("open") || ((0, g.f)(u, "dialog:remove"), o.remove())
                    }), u
                }
                c(m, "dialog")
            },
            34782: (x, L, h) => {
                h.d(L, {
                    C: () => m,
                    x: () => g
                });
                const g = function() {
                        return document.readyState === "interactive" || document.readyState === "complete" ? Promise.resolve() : new Promise(f => {
                            document.addEventListener("DOMContentLoaded", () => {
                                f()
                            })
                        })
                    }(),
                    m = function() {
                        return document.readyState === "complete" ? Promise.resolve() : new Promise(f => {
                            window.addEventListener("load", f)
                        })
                    }()
            },
            52660: (x, L, h) => {
                h.d(L, {
                    D: () => d,
                    a: () => f
                });
                var g = h(2699),
                    m = h(10900);
                async function f(l, o, u) {
                    const E = new Request(o, u);
                    E.headers.append("X-Requested-With", "XMLHttpRequest");
                    const v = await self.fetch(E);
                    if (v.status < 200 || v.status >= 300) throw new Error(`HTTP ${v.status}${v.statusText||""}`);
                    return (0, g.t)((0, g.P)(l), v), (0, m.r)(l, await v.text())
                }
                c(f, "fetchSafeDocumentFragment");

                function d(l, o, u = 1e3) {
                    return c(async function E(v) {
                        const y = new Request(l, o);
                        y.headers.append("X-Requested-With", "XMLHttpRequest");
                        const A = await self.fetch(y);
                        if (A.status < 200 || A.status >= 300) throw new Error(`HTTP ${A.status}${A.statusText||""}`);
                        if (A.status === 200) return A;
                        if (A.status === 202) return await new Promise(I => setTimeout(I, v)), E(v * 1.5);
                        throw new Error(`Unexpected ${A.status} response status from poll endpoint`)
                    }, "poll")(u)
                }
                c(d, "fetchPoll")
            },
            82036: (x, L, h) => {
                h.d(L, {
                    Bt: () => l,
                    DN: () => E,
                    KL: () => A,
                    Se: () => u,
                    qC: () => I,
                    sw: () => v
                });
                var g = h(59753),
                    m = h(90137),
                    f = h(52134);
                (0, g.on)("click", ".js-remote-submit-button", async function(b) {
                    const k = b.currentTarget.form;
                    b.preventDefault();
                    let s;
                    try {
                        s = await fetch(k.action, {
                            method: k.method,
                            body: new FormData(k),
                            headers: {
                                Accept: "application/json",
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        })
                    } catch {}
                    s && !s.ok && (0, f.v)()
                });

                function d(b, i, k) {
                    return b.dispatchEvent(new CustomEvent(i, {
                        bubbles: !0,
                        cancelable: k
                    }))
                }
                c(d, "fire");

                function l(b, i) {
                    i && (o(b, i), (0, m.j)(i)), d(b, "submit", !0) && b.submit()
                }
                c(l, "requestSubmit");

                function o(b, i) {
                    if (!(b instanceof HTMLFormElement)) throw new TypeError("The specified element is not of type HTMLFormElement.");
                    if (!(i instanceof HTMLElement)) throw new TypeError("The specified element is not of type HTMLElement.");
                    if (i.type !== "submit") throw new TypeError("The specified element is not a submit button.");
                    if (!b || b !== i.form) throw new Error("The specified element is not owned by the form element.")
                }
                c(o, "checkButtonValidity");

                function u(b, i) {
                    if (typeof i == "boolean")
                        if (b instanceof HTMLInputElement) b.checked = i;
                        else throw new TypeError("only checkboxes can be set to boolean value");
                    else {
                        if (b.type === "checkbox") throw new TypeError("checkbox can't be set to string value");
                        b.value = i
                    }
                    d(b, "change", !1)
                }
                c(u, "changeValue");

                function E(b, i) {
                    for (const k in i) {
                        const s = i[k],
                            p = b.elements.namedItem(k);
                        (p instanceof HTMLInputElement || p instanceof HTMLTextAreaElement) && (p.value = s)
                    }
                }
                c(E, "fillFormValues");

                function v(b) {
                    if (!(b instanceof HTMLElement)) return !1;
                    const i = b.nodeName.toLowerCase(),
                        k = (b.getAttribute("type") || "").toLowerCase();
                    return i === "select" || i === "textarea" || i === "input" && k !== "submit" && k !== "reset" || b.isContentEditable
                }
                c(v, "isFormField");

                function y(b) {
                    return new URLSearchParams(b)
                }
                c(y, "searchParamsFromFormData");

                function A(b, i) {
                    const k = new URLSearchParams(b.search),
                        s = y(i);
                    for (const [p, w] of s) k.append(p, w);
                    return k.toString()
                }
                c(A, "combineGetFormSearchParams");

                function I(b) {
                    return y(new FormData(b)).toString()
                }
                c(I, "serialize")
            },
            2699: (x, L, h) => {
                h.d(L, {
                    P: () => g,
                    t: () => f
                });

                function g(d) {
                    const l = [...d.querySelectorAll("meta[name=html-safe-nonce]")].map(o => o.content);
                    if (l.length < 1) throw new Error("could not find html-safe-nonce on document");
                    return l
                }
                c(g, "getDocumentHtmlSafeNonces");
                class m extends Error {
                    constructor(l, o) {
                        super(`${l} for HTTP ${o.status}`);
                        this.response = o
                    }
                }
                c(m, "ResponseError");

                function f(d, l, o = !1) {
                    const u = l.headers.get("content-type") || "";
                    if (!o && !u.startsWith("text/html")) throw new m(`expected response with text/html, but was ${u}`, l);
                    if (o && !(u.startsWith("text/html") || u.startsWith("application/json"))) throw new m(`expected response with text/html or application/json, but was ${u}`, l);
                    const E = l.headers.get("x-html-safe");
                    if (E) {
                        if (!d.includes(E)) throw new m("response X-HTML-Safe nonce did not match", l)
                    } else throw new m("missing X-HTML-Safe nonce", l)
                }
                c(f, "verifyResponseHtmlSafeNonce")
            },
            9115: (x, L, h) => {
                var g = h(90420),
                    m = Object.defineProperty,
                    f = Object.getOwnPropertyDescriptor,
                    d = c((o, u, E, v) => {
                        for (var y = v > 1 ? void 0 : v ? f(u, E) : u, A = o.length - 1, I; A >= 0; A--)(I = o[A]) && (y = (v ? I(u, E, y) : I(y)) || y);
                        return v && y && m(u, E, y), y
                    }, "__decorateClass");
                let l = c(class extends HTMLElement {
                    connectedCallback() {
                        this.control && (this.storedInput = Array(this.control.children.length).fill("")), this.addEventListener("input", this.relayInput.bind(this)), this.addEventListener("keydown", this.relayKeydown.bind(this));
                        const o = this.closest("details");
                        o && o.addEventListener("toggle", () => {
                            o.open && this.source.focus()
                        })
                    }
                    relayKeydown(o) {
                        if ((this.isControlTab(o.target) || o.target === this.source) && (o.key === "ArrowDown" || o.key === "Tab")) o.preventDefault(), o.stopPropagation(), this.routeCustomEvent(new CustomEvent("focus-list"));
                        else if (o.key === "Escape") {
                            const u = this.closest("details");
                            u && u.removeAttribute("open")
                        }
                    }
                    isControlTab(o) {
                        return !o || !this.control ? !1 : Array.from(this.control.children).includes(o)
                    }
                    relayInput(o) {
                        if (!o.target) return;
                        const E = o.target.value;
                        this.routeCustomEvent(new CustomEvent("input-entered", {
                            detail: E
                        }))
                    }
                    routeCustomEvent(o) {
                        this.sinks[this.selectedIndex].dispatchEvent(o)
                    }
                    get selectedIndex() {
                        if (!this.control) return 0;
                        const o = this.control.querySelector('[aria-selected="true"]');
                        return o ? Array.from(this.control.children).indexOf(o) : 0
                    }
                    storeInput() {
                        this.storedInput[this.selectedIndex] = this.source.value
                    }
                    updateInput(o) {
                        this.source.value = this.storedInput[this.selectedIndex];
                        const u = o.detail.relatedTarget.getAttribute("data-filter-placeholder");
                        this.source.placeholder = u, this.source.setAttribute("aria-label", u), this.notifySelected()
                    }
                    notifySelected() {
                        const o = this.sinks[this.selectedIndex],
                            u = new CustomEvent("tab-selected");
                        o.dispatchEvent(u)
                    }
                }, "InputDemuxElement");
                d([g.fA], l.prototype, "source", 2), d([g.GO], l.prototype, "sinks", 2), d([g.fA], l.prototype, "control", 2), l = d([g.Ih], l)
            },
            10900: (x, L, h) => {
                h.d(L, {
                    r: () => g
                });

                function g(m, f) {
                    const d = m.createElement("template");
                    return d.innerHTML = f, m.importNode(d.content, !0)
                }
                c(g, "parseHTML")
            },
            83956: (x, L, h) => {
                h.d(L, {
                    M: () => m,
                    W: () => f
                });
                var g = h(59753);
                async function m(d, l = !0) {
                    const o = d.querySelectorAll('[name="codespace[location]"], [name="location"]');
                    if (o.length === 0) return;
                    for (const y of o)
                        if (y.value) return;
                    const u = d.querySelector("button[type=submit]");
                    u instanceof HTMLInputElement && (u.disabled = !0);
                    const E = d.getAttribute("data-codespace-locations-url");
                    if (!E) return;
                    const v = await f(E);
                    if (l && v)
                        for (const y of o) y.value = v.current;
                    return v
                }
                c(m, "prefetchCodespaceLocation");
                async function f(d) {
                    const l = await fetch(d, {
                        headers: {
                            "X-Requested-With": "XMLHttpRequest",
                            Accept: "application/json"
                        }
                    });
                    if (!l.ok) {
                        const o = new Error,
                            u = l.statusText ? ` ${l.statusText}` : "";
                        throw o.message = `HTTP ${l.status}${u}`, o
                    }
                    return l.json()
                }
                c(f, "fetchLocationValues"), (0, g.on)("submit", ".js-prefetch-codespace-location", async function(d) {
                    const l = d.currentTarget;
                    d.preventDefault(), await m(l), l.submit()
                })
            },
            43452: (x, L, h) => {
                h.d(L, {
                    Z: () => g
                });

                function g(m) {
                    var f, d;
                    const l = (d = (f = m.head) == null ? void 0 : f.querySelector('meta[name="expected-hostname"]')) == null ? void 0 : d.content;
                    if (!l) return !1;
                    const o = l.replace(/\.$/, "").split(".").slice(-2).join("."),
                        u = m.location.hostname.replace(/\.$/, "").split(".").slice(-2).join(".");
                    return o !== u
                }
                c(g, "detectProxySite")
            },
            68906: (x, L, h) => {
                var g = h(60785),
                    m = h(83476);
                const {
                    getItem: f,
                    setItem: d,
                    removeItem: l
                } = (0, g.Z)("localStorage", {
                    throwQuotaErrorsOnSet: !0
                });
                var o = (s => (s.Branch = "branch", s.Tag = "tag", s))(o || {});
                const u = c(class {
                    constructor(s, p, w, T, C) {
                        this.knownItems = [], this.currentSearchResult = [], this.exactMatchFound = !1, this.isLoading = !0, this.fetchInProgress = !1, this.fetchFailed = !1, this.refType = s, this.selector = p, this.refEndpoint = w, this.cacheKey = T, this.nameWithOwner = C
                    }
                    render() {
                        this.selector.render()
                    }
                    async fetchData() {
                        try {
                            if (!this.isLoading || this.fetchInProgress) return;
                            if (!this.bootstrapFromLocalStorage()) {
                                this.fetchInProgress = !0, this.fetchFailed = !1;
                                const s = await fetch(`${this.refEndpoint}?type=${this.refType}`, {
                                    headers: {
                                        Accept: "application/json"
                                    }
                                });
                                await this.processResponse(s)
                            }
                            this.isLoading = !1, this.fetchInProgress = !1, this.render()
                        } catch {
                            this.fetchInProgress = !1, this.fetchFailed = !0
                        }
                    }
                    async processResponse(s) {
                        if (this.emitStats(s), !s.ok) {
                            this.fetchFailed = !0;
                            return
                        }
                        const p = s.clone(),
                            w = await s.json();
                        this.knownItems = w.refs, this.cacheKey = w.cacheKey, this.flushToLocalStorage(await p.text())
                    }
                    emitStats(s) {
                        if (!s.ok) {
                            (0, m.b)({
                                incrementKey: "REF_SELECTOR_BOOT_FAILED"
                            }, !0);
                            return
                        }
                        switch (s.status) {
                            case 200:
                                {
                                    (0, m.b)({
                                        incrementKey: "REF_SELECTOR_BOOTED_FROM_UNCACHED_HTTP"
                                    });
                                    break
                                }
                            case 304:
                                {
                                    (0, m.b)({
                                        incrementKey: "REF_SELECTOR_BOOTED_FROM_HTTP_CACHE"
                                    });
                                    break
                                }
                            default:
                                (0, m.b)({
                                    incrementKey: "REF_SELECTOR_UNEXPECTED_RESPONSE"
                                })
                        }
                    }
                    search(s) {
                        if (s === "") {
                            this.currentSearchResult = this.knownItems;
                            return
                        }
                        const p = [],
                            w = [];
                        this.exactMatchFound = !1;
                        let T;
                        for (const C of this.knownItems)
                            if (T = C.indexOf(s), !(T < 0)) {
                                if (T === 0) {
                                    s === C ? (w.unshift(C), this.exactMatchFound = !0) : w.push(C);
                                    continue
                                }
                                p.push(C)
                            }
                        this.currentSearchResult = [...w, ...p]
                    }
                    bootstrapFromLocalStorage() {
                        const s = f(this.localStorageKey);
                        if (!s) return !1;
                        const p = JSON.parse(s);
                        return p.cacheKey !== this.cacheKey || !("refs" in p) ? (l(this.localStorageKey), !1) : (this.knownItems = p.refs, this.isLoading = !1, (0, m.b)({
                            incrementKey: "REF_SELECTOR_BOOTED_FROM_LOCALSTORAGE"
                        }), !0)
                    }
                    async flushToLocalStorage(s) {
                        try {
                            d(this.localStorageKey, s)
                        } catch (p) {
                            if (p.message.toLowerCase().includes("quota")) {
                                this.clearSiblingLocalStorage(), (0, m.b)({
                                    incrementKey: "REF_SELECTOR_LOCALSTORAGE_OVERFLOWED"
                                });
                                try {
                                    d(this.localStorageKey, s)
                                } catch (w) {
                                    w.message.toLowerCase().includes("quota") && (0, m.b)({
                                        incrementKey: "REF_SELECTOR_LOCALSTORAGE_GAVE_UP"
                                    })
                                }
                            } else throw p
                        }
                    }
                    clearSiblingLocalStorage() {
                        for (const s of Object.keys(localStorage)) s.startsWith(u.LocalStoragePrefix) && l(s)
                    }
                    get localStorageKey() {
                        return `${u.LocalStoragePrefix}:${this.nameWithOwner}:${this.refType}`
                    }
                }, "_SearchIndex");
                let E = u;
                E.LocalStoragePrefix = "ref-selector";
                var v = h(69567),
                    y = h(90420),
                    A = h(17945),
                    I = Object.defineProperty,
                    b = Object.getOwnPropertyDescriptor,
                    i = c((s, p, w, T) => {
                        for (var C = T > 1 ? void 0 : T ? b(p, w) : p, D = s.length - 1, M; D >= 0; D--)(M = s[D]) && (C = (T ? M(p, w, C) : M(C)) || C);
                        return T && C && I(p, w, C), C
                    }, "__decorateClass");
                let k = c(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.isCurrentVisible = !1, this.currentSelectionIndex = null
                    }
                    connectedCallback() {
                        this.refType = this.getRequiredAttr("type") === "branch" ? o.Branch : o.Tag;
                        const s = this.getAttribute("current-committish");
                        this.currentCommittish = s ? atob(s) : null, this.input = this.hasAttribute("initial-filter") && this.currentCommittish || "", this.defaultBranch = atob(this.getRequiredAttr("default-branch")), this.nameWithOwner = atob(this.getRequiredAttr("name-with-owner")), this.canCreate = this.hasAttribute("can-create"), this.prefetchOnMouseover = this.hasAttribute("prefetch-on-mouseover");
                        const p = this.getRequiredAttr("query-endpoint"),
                            w = this.getRequiredAttr("cache-key");
                        this.index = new E(this.refType, this, p, w, this.nameWithOwner), this.setupFetchListeners()
                    }
                    inputEntered(s) {
                        this.input = s.detail, this.render()
                    }
                    tabSelected() {
                        this.index.fetchData()
                    }
                    renderTemplate(s, p) {
                        return new v.R(s, p, v.XK)
                    }
                    renderRow(s) {
                        const p = this.index.currentSearchResult[s];
                        if (!p && s >= this.listLength) return document.createElement("span");
                        if (this.index.fetchFailed) return this.renderTemplate(this.fetchFailedTemplate, {
                            index: s,
                            refName: this.input
                        });
                        if (!p) {
                            const M = this.input === this.currentCommittish;
                            return this.isCurrentVisible || (this.isCurrentVisible = M), this.renderTemplate(this.noMatchTemplate, {
                                index: s,
                                isCurrent: M,
                                refName: this.input
                            })
                        }
                        const w = this.input.length > 0,
                            T = w ? "is-filtering" : "",
                            C = p === this.currentCommittish;
                        this.isCurrentVisible || (this.isCurrentVisible = C);
                        const D = this.renderTemplate(this.itemTemplate, {
                            refName: p,
                            index: s,
                            isFilteringClass: T,
                            urlEncodedRefName: this.urlEncodeRef(p),
                            isCurrent: C,
                            isNotDefault: p !== this.defaultBranch
                        });
                        if (w) {
                            const M = D.querySelector("span");
                            M.textContent = "";
                            const H = p.split(this.input),
                                $ = H.length - 1;
                            for (let q = 0; q < H.length; q++) {
                                const X = H[q];
                                if (M.appendChild(document.createTextNode(X)), q < $) {
                                    const K = document.createElement("b");
                                    K.textContent = this.input, M.appendChild(K)
                                }
                            }
                        }
                        return D
                    }
                    urlEncodeRef(s) {
                        return encodeURIComponent(s).replaceAll("%2F", "/").replaceAll("%3A", ":").replaceAll("%2B", "+")
                    }
                    render() {
                        if (this.currentSelectionIndex = null, !this.index.isLoading) {
                            if (!this.virtualizedList) {
                                this.index.search(this.input), this.setupVirtualizedList();
                                return
                            }
                            this.listContainer.scrollTop = 0, this.index.search(this.input), this.virtualizedList.setRowCount(this.listLength)
                        }
                    }
                    get listLength() {
                        const s = this.index.currentSearchResult.length;
                        return this.showCreateRow ? s + 1 : s || 1
                    }
                    get showCreateRow() {
                        return !this.index.fetchFailed && !this.index.exactMatchFound && this.input !== "" && this.canCreate
                    }
                    getRequiredAttr(s, p = this) {
                        const w = p.getAttribute(s);
                        if (!w) throw new Error(`Missing attribute for ${p}: ${s}`);
                        return w
                    }
                    setupFetchListeners() {
                        const s = this.closest("details");
                        let p = !1;
                        const w = c(() => {
                            p || (this.index.fetchData(), p = !0)
                        }, "fetch");
                        if (!s || s.open) {
                            w();
                            return
                        }
                        this.prefetchOnMouseover && s.addEventListener("mouseover", w, {
                            once: !0
                        }), this.addEventListener("keydown", this.keydown), this.addEventListener("change", this.updateCurrent);
                        const T = s.querySelector("input[data-ref-filter]");
                        T && (T.addEventListener("input", () => {
                            this.input = T.value, this.render()
                        }), T.addEventListener("keydown", C => {
                            if (C.key === "ArrowDown" || C.key === "Tab") C.preventDefault(), C.stopPropagation(), this.focusFirstListMember();
                            else if (C.key === "Enter") {
                                let D = this.index.currentSearchResult.indexOf(this.input);
                                if (D === -1)
                                    if (this.showCreateRow) D = this.listLength - 1;
                                    else return;
                                s.querySelector(`[data-index="${D}"]`).click(), C.preventDefault()
                            }
                        }))
                    }
                    focusFirstListMember() {
                        !this.virtualizedList || (this.currentSelectionIndex = 0, this.focusItemAtIndex(this.currentSelectionIndex))
                    }
                    updateCurrent(s) {
                        s.target instanceof HTMLInputElement && s.target.checked && s.target.value && (this.currentCommittish = s.target.value)
                    }
                    keydown(s) {
                        if (this.currentSelectionIndex !== null) {
                            if (s.key === "Enter") {
                                const p = document.activeElement;
                                if (!p) return;
                                p.click(), s.preventDefault();
                                return
                            }
                            if (!(s.key === "Tab" && s.shiftKey) && s.key !== "Escape") switch (s.preventDefault(), s.stopPropagation(), s.key) {
                                case "ArrowUp":
                                    {
                                        this.currentSelectionIndex--,
                                        this.currentSelectionIndex < 0 && (this.currentSelectionIndex = this.listLength - 1),
                                        this.focusItemAtIndex(this.currentSelectionIndex);
                                        break
                                    }
                                case "Home":
                                    {
                                        this.currentSelectionIndex = 0,
                                        this.focusItemAtIndex(this.currentSelectionIndex);
                                        break
                                    }
                                case "End":
                                    {
                                        this.currentSelectionIndex = this.listLength - 1,
                                        this.focusItemAtIndex(this.currentSelectionIndex);
                                        break
                                    }
                                case "Tab":
                                case "ArrowDown":
                                    {
                                        this.currentSelectionIndex++,
                                        this.currentSelectionIndex > this.listLength - 1 && (this.currentSelectionIndex = 0),
                                        this.focusItemAtIndex(this.currentSelectionIndex);
                                        break
                                    }
                            }
                        }
                    }
                    focusItemAtIndex(s) {
                        this.virtualizedList.scrollToIndex(s, "center"), setTimeout(() => {
                            const p = this.listContainer.querySelector(`[data-index="${s}"]`);
                            p && p.focus()
                        }, 20)
                    }
                    setupVirtualizedList() {
                        this.listContainer.innerHTML = "", this.virtualizedList = new A.Z(this.listContainer, {
                            height: 330,
                            rowCount: this.listLength,
                            renderRow: this.renderRow.bind(this),
                            rowHeight: s => this.showCreateRow && s === this.listLength - 1 ? 51 : 33,
                            onRowsRendered: () => {
                                var s;
                                this.hiddenCurrentElement && (this.listContainer.removeChild(this.hiddenCurrentElement), delete this.hiddenCurrentElement), this.isCurrentVisible ? this.isCurrentVisible = !1 : this.hiddenCurrentItemTemplate && (this.hiddenCurrentElement = document.createElement("div"), (s = this.hiddenCurrentElement) == null || s.appendChild(this.renderTemplate(this.hiddenCurrentItemTemplate, {
                                    refName: this.currentCommittish
                                })), this.listContainer.appendChild(this.hiddenCurrentElement))
                            },
                            initialIndex: 0,
                            overscanCount: 6
                        })
                    }
                }, "RefSelectorElement");
                i([y.fA], k.prototype, "listContainer", 2), i([y.fA], k.prototype, "itemTemplate", 2), i([y.fA], k.prototype, "noMatchTemplate", 2), i([y.fA], k.prototype, "fetchFailedTemplate", 2), i([y.fA], k.prototype, "hiddenCurrentItemTemplate", 2), k = i([y.Ih], k)
            },
            90137: (x, L, h) => {
                h.d(L, {
                    j: () => g,
                    u: () => m
                });

                function g(f) {
                    const d = f.closest("form");
                    if (!(d instanceof HTMLFormElement)) return;
                    let l = m(d);
                    if (f.name) {
                        const o = f.matches("input[type=submit]") ? "Submit" : "",
                            u = f.value || o;
                        l || (l = document.createElement("input"), l.type = "hidden", l.classList.add("is-submit-button-value"), d.prepend(l)), l.name = f.name, l.value = u
                    } else l && l.remove()
                }
                c(g, "persistSubmitButtonValue");

                function m(f) {
                    const d = f.querySelector("input.is-submit-button-value");
                    return d instanceof HTMLInputElement ? d : null
                }
                c(m, "findPersistedSubmitButtonValue")
            },
            60785: (x, L, h) => {
                h.d(L, {
                    Z: () => m
                });
                class g {
                    getItem() {
                        return null
                    }
                    setItem() {}
                    removeItem() {}
                    clear() {}
                    key() {
                        return null
                    }
                    get length() {
                        return 0
                    }
                }
                c(g, "NoOpStorage");

                function m(f, d = {
                    throwQuotaErrorsOnSet: !1
                }, l = window) {
                    let o;
                    try {
                        o = l[f]
                    } catch {
                        o = new g
                    }
                    const {
                        throwQuotaErrorsOnSet: u
                    } = d;

                    function E(A) {
                        try {
                            return o.getItem(A)
                        } catch {
                            return null
                        }
                    }
                    c(E, "getItem");

                    function v(A, I) {
                        try {
                            o.setItem(A, I)
                        } catch (b) {
                            if (u && b.message.toLowerCase().includes("quota")) throw b
                        }
                    }
                    c(v, "setItem");

                    function y(A) {
                        try {
                            o.removeItem(A)
                        } catch {}
                    }
                    return c(y, "removeItem"), {
                        getItem: E,
                        setItem: v,
                        removeItem: y
                    }
                }
                c(m, "safeStorage")
            },
            83476: (x, L, h) => {
                h.d(L, {
                    b: () => d
                });
                var g = h(43452),
                    m = h(34782);
                let f = [];

                function d(v, y = !1) {
                    v.timestamp === void 0 && (v.timestamp = new Date().getTime()), v.loggedIn = E(), v.bundler = "webpack", f.push(v), y ? u() : o()
                }
                c(d, "sendStats");
                let l = null;
                async function o() {
                    await m.C, l == null && (l = window.requestIdleCallback(u))
                }
                c(o, "scheduleSendStats");

                function u() {
                    var v, y;
                    if (l = null, !f.length || (0, g.Z)(document)) return;
                    const A = (y = (v = document.head) == null ? void 0 : v.querySelector('meta[name="browser-stats-url"]')) == null ? void 0 : y.content;
                    if (!A) return;
                    const I = JSON.stringify({
                        stats: f
                    });
                    try {
                        navigator.sendBeacon && navigator.sendBeacon(A, I)
                    } catch {}
                    f = []
                }
                c(u, "flushStats");

                function E() {
                    var v, y;
                    return !!((y = (v = document.head) == null ? void 0 : v.querySelector('meta[name="user-login"]')) == null ? void 0 : y.content)
                }
                c(E, "isLoggedIn"), document.addEventListener("pagehide", u), document.addEventListener("visibilitychange", u)
            }
        },
        x => {
            var L = c(g => x(x.s = g), "__webpack_exec__");
            x.O(0, [5724, 90, 3878], () => L(79535));
            var h = x.O()
        }
    ]);
})();

//# sourceMappingURL=codespaces-72d5e5d71f5d.js.map