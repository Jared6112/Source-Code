(() => {
    var Jd = Object.defineProperty;
    var i = (O, x) => Jd(O, "name", {
        value: x,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [1436], {
            48776: (O, x, u) => {
                "use strict";
                var w = u(47142);
                const A = i((e, t, n) => {
                        if (!(0, w.CD)(e, t)) return -1 / 0;
                        const o = (0, w.Gs)(e, t);
                        return o < n ? -1 / 0 : o
                    }, "getScore"),
                    P = i((e, t, n) => {
                        e.innerHTML = "";
                        let o = 0;
                        for (const s of (0, w.m7)(t, n)) {
                            n.slice(o, s) !== "" && e.appendChild(document.createTextNode(n.slice(o, s))), o = s + 1;
                            const a = document.createElement("mark");
                            a.textContent = n[s], e.appendChild(a)
                        }
                        e.appendChild(document.createTextNode(n.slice(o)))
                    }, "highlightElement"),
                    M = new WeakMap,
                    y = new WeakMap,
                    m = new WeakMap,
                    b = i(e => {
                        if (!m.has(e) && e instanceof HTMLElement) {
                            const t = (e.getAttribute("data-value") || e.textContent || "").trim();
                            return m.set(e, t), t
                        }
                        return m.get(e) || ""
                    }, "getTextCache");
                class h extends HTMLElement {
                    connectedCallback() {
                        const t = this.querySelector("ul");
                        if (!t) return;
                        const n = new Set(t.querySelectorAll("li")),
                            o = this.querySelector("input");
                        o instanceof HTMLInputElement && o.addEventListener("input", () => {
                            this.value = o.value
                        });
                        const s = new MutationObserver(a => {
                            let c = !1;
                            for (const l of a)
                                if (l.type === "childList" && l.addedNodes.length) {
                                    for (const d of l.addedNodes)
                                        if (d instanceof HTMLLIElement && !n.has(d)) {
                                            const p = b(d);
                                            c = c || (0, w.CD)(this.value, p), n.add(d)
                                        }
                                }
                            c && this.sort()
                        });
                        s.observe(t, {
                            childList: !0
                        });
                        const r = {
                            handler: s,
                            items: n,
                            lazyItems: new Map,
                            timer: null
                        };
                        y.set(this, r)
                    }
                    disconnectedCallback() {
                        const t = y.get(this);
                        t && (t.handler.disconnect(), y.delete(this))
                    }
                    addLazyItems(t, n) {
                        const o = y.get(this);
                        if (!o) return;
                        const {
                            lazyItems: s
                        } = o, {
                            value: r
                        } = this;
                        let a = !1;
                        for (const c of t) s.set(c, n), a = a || Boolean(r) && (0, w.CD)(r, c);
                        a && this.sort()
                    }
                    sort() {
                        const t = M.get(this);
                        t && (t.aborted = !0);
                        const n = {
                            aborted: !1
                        };
                        M.set(this, n);
                        const {
                            minScore: o,
                            markSelector: s,
                            maxMatches: r,
                            value: a
                        } = this, c = y.get(this);
                        if (!c || !this.dispatchEvent(new CustomEvent("fuzzy-list-will-sort", {
                                cancelable: !0,
                                detail: a
                            }))) return;
                        const {
                            items: l,
                            lazyItems: d
                        } = c, p = this.hasAttribute("mark-selector"), j = this.querySelector("ul");
                        if (!j) return;
                        const T = [];
                        if (a) {
                            for (const k of l) {
                                const B = b(k),
                                    $ = A(a, B, o);
                                $ !== -1 / 0 && T.push({
                                    item: k,
                                    score: $
                                })
                            }
                            for (const [k, B] of d) {
                                const $ = A(a, k, o);
                                $ !== -1 / 0 && T.push({
                                    text: k,
                                    render: B,
                                    score: $
                                })
                            }
                            T.sort((k, B) => B.score - k.score).splice(r)
                        } else {
                            let k = T.length;
                            for (const B of l) {
                                if (k >= r) break;
                                T.push({
                                    item: B,
                                    score: 1
                                }), k += 1
                            }
                            for (const [B, $] of d) {
                                if (k >= r) break;
                                T.push({
                                    text: B,
                                    render: $,
                                    score: 1
                                }), k += 1
                            }
                        }
                        requestAnimationFrame(() => {
                            if (n.aborted) return;
                            const k = j.querySelector('input[type="radio"]:checked');
                            j.innerHTML = "";
                            let B = 0;
                            const $ = i(() => {
                                if (n.aborted) return;
                                const G = Math.min(T.length, B + 100),
                                    ee = document.createDocumentFragment();
                                for (let W = B; W < G; W += 1) {
                                    const F = T[W];
                                    let te = null;
                                    if ("render" in F && "text" in F) {
                                        const {
                                            render: be,
                                            text: Ne
                                        } = F;
                                        te = be(Ne), l.add(te), m.set(te, Ne), d.delete(Ne)
                                    } else "item" in F && (te = F.item);
                                    te instanceof HTMLElement && (p && P(s && te.querySelector(s) || te, p ? a : "", b(te)), ee.appendChild(te))
                                }
                                B = G;
                                let V = !1;
                                if (k instanceof HTMLInputElement)
                                    for (const W of ee.querySelectorAll('input[type="radio"]:checked')) W instanceof HTMLInputElement && W.value !== k.value && (W.checked = !1, V = !0);
                                if (j.appendChild(ee), k && V && k.dispatchEvent(new Event("change", {
                                        bubbles: !0
                                    })), G < T.length) requestAnimationFrame($);
                                else {
                                    j.hidden = T.length === 0;
                                    const W = this.querySelector("[data-fuzzy-list-show-on-empty]");
                                    W && (W.hidden = T.length > 0), this.dispatchEvent(new CustomEvent("fuzzy-list-sorted", {
                                        detail: T.length
                                    }))
                                }
                            }, "nextBatch");
                            $()
                        })
                    }
                    get value() {
                        return this.getAttribute("value") || ""
                    }
                    set value(t) {
                        this.setAttribute("value", t)
                    }
                    get markSelector() {
                        return this.getAttribute("mark-selector") || ""
                    }
                    set markSelector(t) {
                        t ? this.setAttribute("mark-selector", t) : this.removeAttribute("mark-selector")
                    }
                    get minScore() {
                        return Number(this.getAttribute("min-score") || 0)
                    }
                    set minScore(t) {
                        Number.isNaN(t) || this.setAttribute("min-score", String(t))
                    }
                    get maxMatches() {
                        return Number(this.getAttribute("max-matches") || 1 / 0)
                    }
                    set maxMatches(t) {
                        Number.isNaN(t) || this.setAttribute("max-matches", String(t))
                    }
                    static get observedAttributes() {
                        return ["value", "mark-selector", "min-score", "max-matches"]
                    }
                    attributeChangedCallback(t, n, o) {
                        if (n === o) return;
                        const s = y.get(this);
                        !s || (s.timer && window.clearTimeout(s.timer), s.timer = window.setTimeout(() => this.sort(), 100))
                    }
                }
                i(h, "FuzzyListElement");
                const E = h;
                window.customElements.get("fuzzy-list") || (window.FuzzyListElement = h, window.customElements.define("fuzzy-list", h));
                var L = i((e, t, n) => {
                        if (!t.has(e)) throw TypeError("Cannot " + n)
                    }, "__accessCheck"),
                    g = i((e, t, n) => (L(e, t, "read from private field"), n ? n.call(e) : t.get(e)), "__privateGet"),
                    C = i((e, t, n) => {
                        if (t.has(e)) throw TypeError("Cannot add the same private member more than once");
                        t instanceof WeakSet ? t.add(e) : t.set(e, n)
                    }, "__privateAdd"),
                    q = i((e, t, n, o) => (L(e, t, "write to private field"), o ? o.call(e, n) : t.set(e, n), n), "__privateSet"),
                    _, N, J, Y, ce, le, se;
                class Ae extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        C(this, _, !1), C(this, N, new Set), C(this, J, new Map), C(this, Y, 1 / 0), C(this, ce, new Map), C(this, le, new Map), C(this, se, 0)
                    }
                    static get observedAttributes() {
                        return ["data-updating"]
                    }
                    get updating() {
                        return this.getAttribute("data-updating") === "lazy" ? "lazy" : "eager"
                    }
                    set updating(t) {
                        this.setAttribute("data-updating", t)
                    }
                    get size() {
                        return g(this, N).size
                    }
                    get range() {
                        const t = this.getBoundingClientRect().height,
                            {
                                scrollTop: n
                            } = this,
                            o = `${n}-${t}`;
                        if (g(this, ce).has(o)) return g(this, ce).get(o);
                        let s = 0,
                            r = 0,
                            a = 0,
                            c = 0;
                        const l = g(this, J);
                        for (const d of g(this, N)) {
                            const p = l.get(d) || g(this, Y);
                            if (a + p < n) a += p, s += 1, r += 1;
                            else if (c - p < t) c += p, r += 1;
                            else if (c >= t) break
                        }
                        return [s, r]
                    }
                    attributeChangedCallback(t, n, o) {
                        if (n === o || !this.isConnected) return;
                        const s = t === "data-updating" && o === "eager",
                            r = t === "data-sorted" && this.hasAttribute("data-sorted");
                        (s || r) && this.update()
                    }
                    connectedCallback() {
                        this.addEventListener("scroll", () => this.update()), this.updateSync = this.updateSync.bind(this)
                    }
                    update() {
                        g(this, se) && cancelAnimationFrame(g(this, se)), !g(this, _) && this.hasAttribute("data-sorted") ? q(this, se, requestAnimationFrame(() => {
                            this.dispatchEvent(new CustomEvent("virtual-list-sort", {
                                cancelable: !0
                            })) && this.sort()
                        })) : q(this, se, requestAnimationFrame(this.updateSync))
                    }
                    renderItem(t) {
                        const n = {
                            item: t,
                            fragment: document.createDocumentFragment()
                        };
                        return this.dispatchEvent(new CustomEvent("virtual-list-render-item", {
                            detail: n
                        })), n.fragment.children[0]
                    }
                    recalculateHeights(t) {
                        const n = this.querySelector("ul, ol, tbody");
                        n && (n.append(this.renderItem(t)), q(this, Y, n.children[0].getBoundingClientRect().height), g(this, J).set(t, g(this, Y)), n.replaceChildren())
                    }
                    updateSync() {
                        const t = this.querySelector("ul, ol");
                        if (!t) return;
                        const [n, o] = this.range;
                        if (o < n || !this.dispatchEvent(new CustomEvent("virtual-list-update", {
                                cancelable: !0
                            }))) return;
                        const r = new Map,
                            a = g(this, le);
                        let c = -1,
                            l = !0,
                            d = 0;
                        for (const B of g(this, N)) {
                            if (c === -1 && (!Number.isFinite(g(this, Y)) || g(this, Y) === 0) && this.recalculateHeights(B), c += 1, c < n) {
                                d += g(this, J).get(B) || g(this, Y);
                                continue
                            }
                            if (c > o) {
                                l = !1;
                                break
                            }
                            let $ = null;
                            if (a.has(B)) $ = a.get(B);
                            else {
                                if ($ = this.renderItem(B), !$) continue;
                                a.set(B, $)
                            }
                            r.set(B, $)
                        }
                        t.replaceChildren(...r.values()), t.style.paddingTop = `${d}px`;
                        const p = this.size * g(this, Y);
                        t.style.height = `${p||0}px`;
                        let j = !1;
                        const T = this.getBoundingClientRect().bottom;
                        for (const [B, $] of r) {
                            const {
                                height: G,
                                bottom: ee
                            } = $.getBoundingClientRect();
                            j = j || ee >= T, g(this, J).set(B, G)
                        }
                        if (!l && this.size > r.size && !j) return g(this, ce).delete(`${this.scrollTop}-${this.getBoundingClientRect().height}`), this.update();
                        this.dispatchEvent(new CustomEvent("virtual-list-updated"))
                    }
                    has(t) {
                        return g(this, N).has(t)
                    }
                    add(t) {
                        return g(this, N).add(t), q(this, _, !1), Number.isFinite(g(this, Y)) || this.recalculateHeights(t), this.updating === "eager" && this.update(), this
                    }
                    delete(t) {
                        const n = g(this, N).delete(t);
                        return q(this, _, !1), g(this, J).delete(t), this.updating === "eager" && this.update(), n
                    }
                    clear() {
                        g(this, N).clear(), g(this, J).clear(), q(this, Y, 1 / 0), q(this, _, !0), this.updating === "eager" && this.update()
                    }
                    forEach(t, n) {
                        for (const o of this) t.call(n, o, o, this)
                    }
                    entries() {
                        return g(this, N).entries()
                    }
                    values() {
                        return g(this, N).values()
                    }
                    keys() {
                        return g(this, N).keys()
                    }[Symbol.iterator]() {
                        return g(this, N)[Symbol.iterator]()
                    }
                    sort(t) {
                        return q(this, N, new Set(Array.from(this).sort(t))), q(this, _, !0), this.updating === "eager" && this.update(), this
                    }
                }
                i(Ae, "VirtualListElement"), _ = new WeakMap, N = new WeakMap, J = new WeakMap, Y = new WeakMap, ce = new WeakMap, le = new WeakMap, se = new WeakMap;
                const Ct = null;
                window.customElements.get("virtual-list") || (window.VirtualListElement = Ae, window.customElements.define("virtual-list", Ae));
                var U = i((e, t, n) => {
                        if (!t.has(e)) throw TypeError("Cannot " + n)
                    }, "virtual_filter_input_element_accessCheck"),
                    S = i((e, t, n) => (U(e, t, "read from private field"), n ? n.call(e) : t.get(e)), "virtual_filter_input_element_privateGet"),
                    I = i((e, t, n) => {
                        if (t.has(e)) throw TypeError("Cannot add the same private member more than once");
                        t instanceof WeakSet ? t.add(e) : t.set(e, n)
                    }, "virtual_filter_input_element_privateAdd"),
                    D = i((e, t, n, o) => (U(e, t, "write to private field"), o ? o.call(e, n) : t.set(e, n), n), "virtual_filter_input_element_privateSet"),
                    z, Q, ae, ye, He, re;

                function Ve(e) {
                    return Boolean(e instanceof Set || e && typeof e == "object" && "size" in e && "add" in e && "delete" in e && "clear" in e)
                }
                i(Ve, "isSetAlike");
                class wn extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        I(this, z, void 0), I(this, Q, 0), I(this, ae, null), I(this, ye, void 0), I(this, He, new Set), I(this, re, null), this.filter = (t, n) => String(t).includes(n)
                    }
                    static get observedAttributes() {
                        return ["src", "loading", "data-property", "aria-owns"]
                    }
                    get filtered() {
                        if (S(this, re)) return S(this, re);
                        if (this.hasAttribute("aria-owns")) {
                            const t = this.ownerDocument.getElementById(this.getAttribute("aria-owns") || "");
                            t && Ve(t) && D(this, re, t)
                        }
                        return S(this, re) || D(this, re, new Set)
                    }
                    set filtered(t) {
                        D(this, re, t)
                    }
                    get input() {
                        return this.querySelector("input, textarea")
                    }
                    get src() {
                        return this.getAttribute("src") || ""
                    }
                    set src(t) {
                        this.setAttribute("src", t)
                    }
                    get loading() {
                        return this.getAttribute("loading") === "lazy" ? "lazy" : "eager"
                    }
                    set loading(t) {
                        this.setAttribute("loading", t)
                    }
                    get accept() {
                        return this.getAttribute("accept") || ""
                    }
                    set accept(t) {
                        this.setAttribute("accept", t)
                    }
                    get property() {
                        return this.getAttribute("data-property") || ""
                    }
                    set property(t) {
                        this.setAttribute("data-property", t)
                    }
                    reset() {
                        this.filtered.clear(), D(this, He, new Set)
                    }
                    clear() {
                        !this.input || (this.input.value = "", this.input.dispatchEvent(new Event("input")))
                    }
                    attributeChangedCallback(t, n, o) {
                        const s = this.isConnected && this.src,
                            r = this.loading === "eager",
                            a = t === "src" || t === "loading" || t === "accept" || t === "data-property",
                            c = t === "src" || t === "data-property",
                            l = n !== o;
                        c && l && (D(this, ae, null), S(this, ye) && clearTimeout(S(this, ye))), s && r && a && l ? (cancelAnimationFrame(S(this, Q)), D(this, Q, requestAnimationFrame(() => this.load()))) : t === "aria-owns" && D(this, re, null)
                    }
                    connectedCallback() {
                        this.src && this.loading === "eager" && (cancelAnimationFrame(S(this, Q)), D(this, Q, requestAnimationFrame(() => this.load())));
                        const t = this.input;
                        if (!t) return;
                        const n = this.getAttribute("aria-owns");
                        n !== null && this.attributeChangedCallback("aria-owns", "", n), t.setAttribute("autocomplete", "off"), t.setAttribute("spellcheck", "false"), this.src && this.loading === "lazy" && (document.activeElement === t ? this.load() : t.addEventListener("focus", () => {
                            this.load()
                        }, {
                            once: !0
                        })), t.addEventListener("input", this)
                    }
                    disconnectedCallback() {
                        var t;
                        (t = this.input) == null || t.removeEventListener("input", this)
                    }
                    handleEvent(t) {
                        var n, o;
                        t.type === "input" && (S(this, ye) && clearTimeout(S(this, ye)), D(this, ye, window.setTimeout(() => this.filterItems(), ((o = (n = this.input) == null ? void 0 : n.value) == null ? void 0 : o.length) || 0 < 3 ? 300 : 0)))
                    }
                    async load() {
                        var t;
                        (t = S(this, z)) == null || t.abort(), D(this, z, new AbortController);
                        const {
                            signal: n
                        } = S(this, z);
                        if (!this.src) throw new Error("missing src");
                        if (await new Promise(o => setTimeout(o, 0)), !n.aborted) {
                            this.dispatchEvent(new Event("loadstart"));
                            try {
                                const o = await this.fetch(this.request(), {
                                    signal: n
                                });
                                if (location.origin + this.src !== o.url) return;
                                if (!o.ok) throw new Error(`Failed to load resource: the server responded with a status of ${o.status}`);
                                D(this, He, new Set((await o.json())[this.property])), D(this, ae, null), this.dispatchEvent(new Event("loadend"))
                            } catch (o) {
                                if (n.aborted) {
                                    this.dispatchEvent(new Event("loadend"));
                                    return
                                }
                                throw (async () => (this.dispatchEvent(new Event("error")), this.dispatchEvent(new Event("loadend"))))(), o
                            }
                            this.filtered.clear(), this.filterItems()
                        }
                    }
                    request() {
                        return new Request(this.src, {
                            method: "GET",
                            credentials: "same-origin",
                            headers: {
                                Accept: this.accept || "application/json"
                            }
                        })
                    }
                    fetch(t, n) {
                        return fetch(t, n)
                    }
                    filterItems() {
                        var t, n;
                        const o = (n = (t = this.input) == null ? void 0 : t.value.trim()) != null ? n : "",
                            s = S(this, ae);
                        if (D(this, ae, o), o === s) return;
                        this.dispatchEvent(new CustomEvent("virtual-filter-input-filter"));
                        let r;
                        s && o.includes(s) ? r = this.filtered : (r = S(this, He), this.filtered.clear());
                        for (const a of r) this.filter(a, o) ? this.filtered.add(a) : this.filtered.delete(a);
                        this.dispatchEvent(new CustomEvent("virtual-filter-input-filtered"))
                    }
                }
                i(wn, "VirtualFilterInputElement"), z = new WeakMap, Q = new WeakMap, ae = new WeakMap, ye = new WeakMap, He = new WeakMap, re = new WeakMap;
                const Yd = null;
                window.customElements.get("virtual-filter-input") || (window.VirtualFilterInputElement = wn, window.customElements.define("virtual-filter-input", wn));
                var Po = i((e, t, n) => {
                        if (!t.has(e)) throw TypeError("Cannot " + n)
                    }, "marked_text_element_accessCheck"),
                    Oe = i((e, t, n) => (Po(e, t, "read from private field"), n ? n.call(e) : t.get(e)), "marked_text_element_privateGet"),
                    kt = i((e, t, n) => {
                        if (t.has(e)) throw TypeError("Cannot add the same private member more than once");
                        t instanceof WeakSet ? t.add(e) : t.set(e, n)
                    }, "marked_text_element_privateAdd"),
                    xt = i((e, t, n, o) => (Po(e, t, "write to private field"), o ? o.call(e, n) : t.set(e, n), n), "marked_text_element_privateSet"),
                    Mt, qt, Ke, rt;

                function ui(e, t) {
                    const n = [];
                    let o = 0;
                    for (let s = 0; s < e.length; s++) {
                        const r = e[s],
                            a = t.indexOf(r, o);
                        if (a === -1) return n;
                        o = a + 1, n.push(a)
                    }
                    return n
                }
                i(ui, "defaultPositions");
                class Pt extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        kt(this, Mt, ""), kt(this, qt, ""), kt(this, Ke, void 0), kt(this, rt, void 0)
                    }
                    get query() {
                        return this.ownerInput ? this.ownerInput.value : this.getAttribute("query") || ""
                    }
                    set query(t) {
                        this.setAttribute("query", t)
                    }
                    get ownerInput() {
                        const t = this.ownerDocument.getElementById(this.getAttribute("data-owner-input") || "");
                        return t instanceof HTMLInputElement ? t : null
                    }
                    connectedCallback() {
                        var t;
                        this.handleEvent(), (t = this.ownerInput) == null || t.addEventListener("input", this), xt(this, Ke, new MutationObserver(() => this.handleEvent()))
                    }
                    handleEvent() {
                        Oe(this, rt) && cancelAnimationFrame(Oe(this, rt)), xt(this, rt, requestAnimationFrame(() => this.mark()))
                    }
                    disconnectedCallback() {
                        var t;
                        (t = this.ownerInput) == null || t.removeEventListener("input", this), Oe(this, Ke).disconnect()
                    }
                    mark() {
                        const t = this.textContent || "",
                            n = this.query;
                        if (t === Oe(this, Mt) && n === Oe(this, qt)) return;
                        xt(this, Mt, t), xt(this, qt, n), Oe(this, Ke).disconnect();
                        let o = 0;
                        const s = document.createDocumentFragment();
                        for (const r of (this.positions || ui)(n, t)) {
                            if (Number(r) !== r || r < o || r > t.length) continue;
                            t.slice(o, r) !== "" && s.appendChild(document.createTextNode(t.slice(o, r))), o = r + 1;
                            const c = document.createElement("mark");
                            c.textContent = t[r], s.appendChild(c)
                        }
                        s.appendChild(document.createTextNode(t.slice(o))), this.replaceChildren(s), Oe(this, Ke).observe(this, {
                            attributes: !0,
                            childList: !0,
                            subtree: !0
                        })
                    }
                }
                i(Pt, "MarkedTextElement"), Mt = new WeakMap, qt = new WeakMap, Ke = new WeakMap, rt = new WeakMap, Pt.observedAttributes = ["query", "data-owner-input"];
                const Qd = null;
                window.customElements.get("marked-text") || (window.MarkedTextElement = Pt, window.customElements.define("marked-text", Pt));
                var R = u(90420),
                    di = Object.defineProperty,
                    fi = Object.getOwnPropertyDescriptor,
                    Rt = i((e, t, n, o) => {
                        for (var s = o > 1 ? void 0 : o ? fi(t, n) : t, r = e.length - 1, a; r >= 0; r--)(a = e[r]) && (s = (o ? a(t, n, s) : a(s)) || s);
                        return o && s && di(t, n, s), s
                    }, "__decorateClass");
                let it = i(class extends HTMLElement {
                    updateURL(e) {
                        const t = e.currentTarget,
                            n = t.getAttribute("data-url") || "";
                        if (this.helpField.value = n, t.matches(".js-git-protocol-clone-url"))
                            for (const o of this.helpTexts) o.textContent = n;
                        for (const o of this.cloneURLButtons) o.classList.remove("selected");
                        t.classList.add("selected")
                    }
                }, "GitCloneHelpElement");
                Rt([R.fA], it.prototype, "helpField", 2), Rt([R.GO], it.prototype, "helpTexts", 2), Rt([R.GO], it.prototype, "cloneURLButtons", 2), it = Rt([R.Ih], it);
                var It = u(90087);
                class Nt extends HTMLElement {
                    connectedCallback() {
                        this.addEventListener("input", Ro)
                    }
                    disconnectedCallback() {
                        this.removeEventListener("input", Ro)
                    }
                }
                i(Nt, "PasswordStrengthElement"), window.customElements.get("password-strength") || (window.PasswordStrengthElement = Nt, window.customElements.define("password-strength", Nt));

                function Ro(e) {
                    const t = e.currentTarget;
                    if (!(t instanceof Nt)) return;
                    const n = e.target;
                    if (!(n instanceof HTMLInputElement)) return;
                    const o = n.form;
                    if (!(o instanceof HTMLFormElement)) return;
                    const s = mi(n.value, {
                        minimumCharacterCount: Number(t.getAttribute("minimum-character-count")),
                        passphraseLength: Number(t.getAttribute("passphrase-length"))
                    });
                    if (s.valid) {
                        n.setCustomValidity("");
                        const r = t.querySelector("dl.form-group");
                        r && (r.classList.remove("errored"), r.classList.add("successed"))
                    } else n.setCustomValidity(t.getAttribute("invalid-message") || "Invalid");
                    hi(t, s), (0, It.G)(o)
                }
                i(Ro, "onInput");

                function mi(e, t) {
                    const n = {
                        valid: !1,
                        hasMinimumCharacterCount: e.length >= t.minimumCharacterCount,
                        hasMinimumPassphraseLength: t.passphraseLength !== 0 && e.length >= t.passphraseLength,
                        hasLowerCase: /[a-z]/.test(e),
                        hasNumber: /\d/.test(e)
                    };
                    return n.valid = n.hasMinimumPassphraseLength || n.hasMinimumCharacterCount && n.hasLowerCase && n.hasNumber, n
                }
                i(mi, "validatePassword");

                function hi(e, t) {
                    var n, o;
                    const s = e.querySelector("[data-more-than-n-chars]"),
                        r = e.querySelector("[data-min-chars]"),
                        a = e.querySelector("[data-number-requirement]"),
                        c = e.querySelector("[data-letter-requirement]"),
                        l = ((n = e.getAttribute("error-class")) == null ? void 0 : n.split(" ").filter(p => p.length > 0)) || [],
                        d = ((o = e.getAttribute("pass-class")) == null ? void 0 : o.split(" ").filter(p => p.length > 0)) || [];
                    for (const p of [s, r, a, c]) p == null || p.classList.remove(...l, ...d);
                    if (t.hasMinimumPassphraseLength && s) s.classList.add(...d);
                    else if (t.valid) r.classList.add(...d), a.classList.add(...d), c.classList.add(...d);
                    else {
                        const p = t.hasMinimumCharacterCount ? d : l,
                            j = t.hasNumber ? d : l,
                            T = t.hasLowerCase ? d : l;
                        s == null || s.classList.add(...l), r.classList.add(...p), a.classList.add(...j), c.classList.add(...T)
                    }
                }
                i(hi, "highlightPasswordStrengthExplainer");
                var ef = u(20963),
                    tf = u(19935),
                    Io = u(27034);
                class En extends Io.Z {
                    async fetch(t, n = 1e3) {
                        const o = await super.fetch(t);
                        return o.status === 202 ? (await new Promise(s => setTimeout(s, n)), this.fetch(t, n * 1.5)) : o
                    }
                }
                i(En, "PollIncludeFragmentElement"), window.customElements.get("poll-include-fragment") || (window.PollIncludeFragmentElement = En, window.customElements.define("poll-include-fragment", En));
                var pi = u(75329);
                class Ln extends pi.nJ {
                    connectedCallback() {
                        at.push(this), Dt || (No(), Dt = window.setInterval(No, 1e3))
                    }
                    disconnectedCallback() {
                        const t = at.indexOf(this);
                        t !== -1 && at.splice(t, 1), at.length || (window.clearInterval(Dt), Dt = void 0)
                    }
                    getFormattedDate() {
                        const t = this.date;
                        if (!t) return;
                        const n = new Date().getTime() - t.getTime(),
                            o = Math.floor(n / 1e3),
                            s = Math.floor(o / 60),
                            r = Math.floor(s / 60),
                            a = Math.floor(r / 24),
                            c = o - s * 60,
                            l = s - r * 60,
                            d = r - a * 24;
                        return s < 1 ? this.applyPrecision([`${o}s`]) : r < 1 ? this.applyPrecision([`${s}m`, `${c}s`]) : a < 1 ? this.applyPrecision([`${r}h`, `${l}m`, `${c}s`]) : this.applyPrecision([`${a}d`, `${d}h`, `${l}m`, `${c}s`])
                    }
                    applyPrecision(t) {
                        const n = Number(this.getAttribute("data-precision") || t.length);
                        return t.slice(0, n).join(" ")
                    }
                }
                i(Ln, "PreciseTimeAgoElement");
                const at = [];
                let Dt;

                function No() {
                    for (const e of at) e.textContent = e.getFormattedDate() || ""
                }
                i(No, "updateNowElements"), window.customElements.get("precise-time-ago") || (window.PreciseTimeAgoElement = Ln, window.customElements.define("precise-time-ago", Ln));
                var Do = u(10160);
                const gi = /\s|\(|\[/;

                function bi(e, t, n) {
                    const o = e.lastIndexOf(t, n - 1);
                    if (o === -1 || e.lastIndexOf(" ", n - 1) > o) return;
                    const r = e[o - 1];
                    return r && !gi.test(r) ? void 0 : {
                        word: e.substring(o + t.length, n),
                        position: o + t.length,
                        beginningOfLine: yi(r)
                    }
                }
                i(bi, "keyword");
                const yi = i(e => e === void 0 || /\n/.test(e), "isBeginningOfLine"),
                    vi = ["position:absolute;", "overflow:auto;", "word-wrap:break-word;", "top:0px;", "left:-9999px;"],
                    Ho = ["box-sizing", "font-family", "font-size", "font-style", "font-variant", "font-weight", "height", "letter-spacing", "line-height", "max-height", "min-height", "padding-bottom", "padding-left", "padding-right", "padding-top", "border-bottom", "border-left", "border-right", "border-top", "text-decoration", "text-indent", "text-transform", "width", "word-spacing"],
                    Oo = new WeakMap;

                function wi(e, t) {
                    const n = e.nodeName.toLowerCase();
                    if (n !== "textarea" && n !== "input") throw new Error("expected textField to a textarea or input");
                    let o = Oo.get(e);
                    if (o && o.parentElement === e.parentElement) o.innerHTML = "";
                    else {
                        o = document.createElement("div"), Oo.set(e, o);
                        const c = window.getComputedStyle(e),
                            l = vi.slice(0);
                        n === "textarea" ? l.push("white-space:pre-wrap;") : l.push("white-space:nowrap;");
                        for (let d = 0, p = Ho.length; d < p; d++) {
                            const j = Ho[d];
                            l.push(`${j}:${c.getPropertyValue(j)};`)
                        }
                        o.style.cssText = l.join(" ")
                    }
                    const s = document.createElement("span");
                    s.style.cssText = "position: absolute;", s.innerHTML = "&nbsp;";
                    let r, a;
                    if (typeof t == "number") {
                        let c = e.value.substring(0, t);
                        c && (r = document.createTextNode(c)), c = e.value.substring(t), c && (a = document.createTextNode(c))
                    } else {
                        const c = e.value;
                        c && (r = document.createTextNode(c))
                    }
                    if (r && o.appendChild(r), o.appendChild(s), a && o.appendChild(a), !o.parentElement) {
                        if (!e.parentElement) throw new Error("textField must have a parentElement to mirror");
                        e.parentElement.insertBefore(o, e)
                    }
                    return o.scrollTop = e.scrollTop, o.scrollLeft = e.scrollLeft, {
                        mirror: o,
                        marker: s
                    }
                }
                i(wi, "textFieldMirror");

                function Ei(e, t = e.selectionEnd) {
                    const {
                        mirror: n,
                        marker: o
                    } = wi(e, t), s = n.getBoundingClientRect(), r = o.getBoundingClientRect();
                    return setTimeout(() => {
                        n.remove()
                    }, 5e3), {
                        top: r.top - s.top,
                        left: r.left - s.left
                    }
                }
                i(Ei, "textFieldSelectionPosition");
                const Xe = new WeakMap;
                class Bo {
                    constructor(t, n) {
                        this.expander = t, this.input = n, this.combobox = null, this.menu = null, this.match = null, this.justPasted = !1, this.oninput = this.onInput.bind(this), this.onpaste = this.onPaste.bind(this), this.onkeydown = this.onKeydown.bind(this), this.oncommit = this.onCommit.bind(this), this.onmousedown = this.onMousedown.bind(this), this.onblur = this.onBlur.bind(this), this.interactingWithMenu = !1, n.addEventListener("paste", this.onpaste), n.addEventListener("input", this.oninput), n.addEventListener("keydown", this.onkeydown), n.addEventListener("blur", this.onblur)
                    }
                    destroy() {
                        this.input.removeEventListener("paste", this.onpaste), this.input.removeEventListener("input", this.oninput), this.input.removeEventListener("keydown", this.onkeydown), this.input.removeEventListener("blur", this.onblur)
                    }
                    activate(t, n) {
                        this.input === document.activeElement && this.setMenu(t, n)
                    }
                    deactivate() {
                        const t = this.menu,
                            n = this.combobox;
                        return !t || !n ? !1 : (this.menu = null, this.combobox = null, t.removeEventListener("combobox-commit", this.oncommit), t.removeEventListener("mousedown", this.onmousedown), n.destroy(), t.remove(), !0)
                    }
                    setMenu(t, n) {
                        this.deactivate(), this.menu = n, n.id || (n.id = `text-expander-${Math.floor(Math.random()*1e5).toString()}`), this.expander.append(n);
                        const o = n.querySelector(".js-slash-command-menu-items");
                        o ? this.combobox = new Do.Z(this.input, o) : this.combobox = new Do.Z(this.input, n);
                        const {
                            top: s,
                            left: r
                        } = Ei(this.input, t.position), a = parseInt(window.getComputedStyle(this.input).fontSize);
                        n.style.top = `${s+a}px`, n.style.left = `${r}px`, this.combobox.start(), n.addEventListener("combobox-commit", this.oncommit), n.addEventListener("mousedown", this.onmousedown), this.combobox.navigate(1)
                    }
                    setValue(t) {
                        if (t == null) return;
                        const n = this.match;
                        if (!n) return;
                        const o = this.input.value.substring(0, n.position - n.key.length),
                            s = this.input.value.substring(n.position + n.text.length);
                        let {
                            cursor: r,
                            value: a
                        } = this.replaceCursorMark(t);
                        a = (a == null ? void 0 : a.length) === 0 ? a : `${a} `, this.input.value = o + a + s, this.deactivate(), this.input.focus(), r = o.length + (r || a.length), this.input.selectionStart = r, this.input.selectionEnd = r
                    }
                    replaceCursorMark(t) {
                        const n = /%cursor%/gm,
                            o = n.exec(t);
                        return o ? {
                            cursor: o.index,
                            value: t.replace(n, "")
                        } : {
                            cursor: null,
                            value: t
                        }
                    }
                    onCommit({
                        target: t
                    }) {
                        const n = t;
                        if (!(n instanceof HTMLElement) || !this.combobox) return;
                        const o = this.match;
                        if (!o) return;
                        const s = {
                            item: n,
                            key: o.key,
                            value: null
                        };
                        !this.expander.dispatchEvent(new CustomEvent("text-expander-value", {
                            cancelable: !0,
                            detail: s
                        })) || s.value && this.setValue(s.value)
                    }
                    onBlur() {
                        if (this.interactingWithMenu) {
                            this.interactingWithMenu = !1;
                            return
                        }
                        this.deactivate()
                    }
                    onPaste() {
                        this.justPasted = !0
                    }
                    async delay(t) {
                        return new Promise(n => setTimeout(n, t))
                    }
                    async onInput() {
                        if (this.justPasted) {
                            this.justPasted = !1;
                            return
                        }
                        const t = this.findMatch();
                        if (t) {
                            if (this.match = t, await this.delay(this.appropriateDelay(this.match)), this.match !== t) return;
                            const n = await this.notifyProviders(t);
                            if (!this.match) return;
                            n ? this.activate(t, n) : this.deactivate()
                        } else this.match = null, this.deactivate()
                    }
                    appropriateDelay(t) {
                        return t.beginningOfLine || t.text !== "" ? 0 : 250
                    }
                    findMatch() {
                        const t = this.input.selectionEnd,
                            n = this.input.value;
                        for (const o of this.expander.keys) {
                            const s = bi(n, o, t);
                            if (s) return {
                                text: s.word,
                                key: o,
                                position: s.position,
                                beginningOfLine: s.beginningOfLine
                            }
                        }
                    }
                    async notifyProviders(t) {
                        const n = [],
                            o = i(c => n.push(c), "provide");
                        return this.expander.dispatchEvent(new CustomEvent("text-expander-change", {
                            cancelable: !0,
                            detail: {
                                provide: o,
                                text: t.text,
                                key: t.key
                            }
                        })) ? (await Promise.all(n)).filter(c => c.matched).map(c => c.fragment)[0] : void 0
                    }
                    onMousedown() {
                        this.interactingWithMenu = !0
                    }
                    onKeydown(t) {
                        t.key === "Escape" && this.deactivate() && (t.stopImmediatePropagation(), t.preventDefault())
                    }
                }
                i(Bo, "SlashCommandExpander");
                class Sn extends HTMLElement {
                    get keys() {
                        const t = this.getAttribute("keys");
                        return t ? t.split(" ") : []
                    }
                    connectedCallback() {
                        const t = this.querySelector('input[type="text"], textarea');
                        if (!(t instanceof HTMLInputElement || t instanceof HTMLTextAreaElement)) return;
                        const n = new Bo(this, t);
                        Xe.set(this, n)
                    }
                    disconnectedCallback() {
                        const t = Xe.get(this);
                        !t || (t.destroy(), Xe.delete(this))
                    }
                    setValue(t) {
                        const n = Xe.get(this);
                        !n || n.setValue(t)
                    }
                    setMenu(t, n = !1) {
                        const o = Xe.get(this);
                        !o || !o.match || (n && (o.interactingWithMenu = !0), o.setMenu(o.match, t))
                    }
                    closeMenu() {
                        const t = Xe.get(this);
                        !t || t.setValue("")
                    }
                    isLoading() {
                        const t = this.getElementsByClassName("js-slash-command-expander-loading")[0];
                        if (t) {
                            const n = t.cloneNode(!0);
                            n.classList.remove("d-none"), this.setMenu(n)
                        }
                    }
                    showError() {
                        const t = this.getElementsByClassName("js-slash-command-expander-error")[0];
                        if (t) {
                            const n = t.cloneNode(!0);
                            n.classList.remove("d-none"), this.setMenu(n)
                        }
                    }
                }
                i(Sn, "SlashCommandExpanderElement"), window.customElements.get("slash-command-expander") || (window.SlashCommandExpanderElement = Sn, window.customElements.define("slash-command-expander", Sn));
                var ct = u(52134),
                    f = u(59753);
                (0, f.on)("deprecatedAjaxSend", "[data-remote]", function(e) {
                    e.currentTarget === e.target && (e.defaultPrevented || e.currentTarget.classList.add("loading"))
                }), (0, f.on)("deprecatedAjaxComplete", "[data-remote]", function(e) {
                    e.currentTarget === e.target && e.currentTarget.classList.remove("loading")
                });
                var K = u(65935);
                (0, K.AC)("form.js-ajax-pagination, .js-ajax-pagination form", async function(e, t) {
                    const n = e.closest(".js-ajax-pagination");
                    let o;
                    try {
                        o = await t.html()
                    } catch (s) {
                        if (s.response && s.response.status === 404) {
                            n.remove();
                            return
                        } else throw s
                    }
                    n.replaceWith(o.html), (0, f.f)(e, "page:loaded")
                });
                var Ge = u(95186);
                const Li = "analytics.click";
                (0, f.on)("click", "[data-analytics-event]", e => {
                    const n = e.currentTarget.getAttribute("data-analytics-event");
                    if (!n) return;
                    const o = JSON.parse(n);
                    (0, Ge.q)(Li, o)
                });
                var ue = u(1314);
                document.addEventListener("pjax:start", function() {
                    (0, ue.x)("Loading page")
                }), document.addEventListener("pjax:error", function() {
                    (0, ue.x)("Loading failed")
                }), document.addEventListener("pjax:end", function() {
                    (0, ue.x)("Loading complete")
                });
                var v = u(64463);
                const _o = new WeakMap;
                (0, v.N7)("auto-check", function(e) {
                    if (e.classList.contains("js-prevent-default-behavior")) return;
                    const t = e.querySelector("input");
                    if (!t) return;
                    const n = t.closest(".form-group") || e,
                        o = t.form;
                    let s;

                    function r() {
                        return s || (s = `input-check-${(Math.random()*1e4).toFixed(0)}`), s
                    }
                    i(r, "generateId");
                    const a = t.getAttribute("aria-describedby");
                    t.addEventListener("focusout:delay", () => {
                        t.setAttribute("aria-describedby", [s, a].join(" "))
                    });
                    const c = n.querySelector("p.note");
                    c && (c.id || (c.id = r()), _o.set(c, c.innerHTML)), e.addEventListener("loadstart", () => {
                        jn(t, n), n.classList.add("is-loading"), t.classList.add("is-autocheck-loading"), (0, It.G)(o)
                    }), e.addEventListener("loadend", () => {
                        n.classList.remove("is-loading"), t.classList.remove("is-autocheck-loading")
                    }), t.addEventListener("auto-check-success", async l => {
                        t.classList.add("is-autocheck-successful"), n.classList.add("successed"), (0, It.G)(o);
                        const {
                            response: d
                        } = l.detail;
                        if (!d) return;
                        const p = await d.text();
                        if (!!p) {
                            if (c instanceof HTMLElement) c.innerHTML = p, (0, ue.N)(c);
                            else {
                                const j = d.status === 200,
                                    T = n.tagName === "DL" ? "dd" : "div",
                                    k = document.createElement(T);
                                k.id = r(), k.classList.add(j ? "success" : "warning"), k.innerHTML = p, n.append(k), n.classList.add(j ? "successed" : "warn"), (0, ue.N)(k), j && (k.hidden = document.activeElement !== t)
                            }(0, f.f)(t, "auto-check-message-updated")
                        }
                    }), t.addEventListener("auto-check-error", async l => {
                        t.classList.add("is-autocheck-errored"), n.classList.add("errored"), (0, It.G)(o);
                        const {
                            response: d
                        } = l.detail;
                        if (!d) return;
                        const p = await d.text();
                        if (c instanceof HTMLElement) c.innerHTML = p || "Something went wrong", (0, ue.N)(c);
                        else {
                            const j = n.tagName === "DL" ? "dd" : "div",
                                T = document.createElement(j);
                            T.id = r(), T.classList.add("error"), T.innerHTML = p || "Something went wrong", n.append(T), (0, ue.N)(T)
                        }
                    }), t.addEventListener("input", () => {
                        t.removeAttribute("aria-describedby"), t.value || jn(t, n)
                    }), t.addEventListener("blur", () => {
                        const l = n.querySelector(".success");
                        l && (l.hidden = !0)
                    }), t.addEventListener("focus", () => {
                        const l = n.querySelector(".success");
                        l && (l.hidden = !1)
                    }), o.addEventListener("reset", () => {
                        jn(t, n)
                    })
                });

                function jn(e, t) {
                    var n, o, s, r, a, c;
                    t.classList.remove("is-loading", "successed", "errored", "warn"), e.classList.remove("is-autocheck-loading", "is-autocheck-successful", "is-autocheck-errored");
                    const l = t.querySelector("p.note");
                    if (l) {
                        const d = _o.get(l);
                        d && (l.innerHTML = d)
                    }
                    t.tagName === "DL" ? ((n = t.querySelector("dd.error")) == null || n.remove(), (o = t.querySelector("dd.warning")) == null || o.remove(), (s = t.querySelector("dd.success")) == null || s.remove()) : ((r = t.querySelector("div.error")) == null || r.remove(), (a = t.querySelector("div.warning")) == null || a.remove(), (c = t.querySelector("div.success")) == null || c.remove())
                }
                i(jn, "autocheck_reset");
                var Si = u(46481);
                (0, v.N7)("auto-complete", function(e) {
                    e.addEventListener("loadstart", () => e.classList.add("is-auto-complete-loading")), e.addEventListener("loadend", () => e.classList.remove("is-auto-complete-loading"))
                }), (0, v.N7)("auto-complete", {
                    constructor: Si.Z,
                    initialize: $o
                }), (0, f.on)("auto-complete-change", "auto-complete", function(e) {
                    $o(e.currentTarget)
                });

                function $o(e) {
                    const t = e.closest("form");
                    if (!t) return;
                    const n = t.querySelector(".js-auto-complete-button");
                    n instanceof HTMLButtonElement && (n.disabled = !e.value)
                }
                i($o, "toggleSubmitButton");
                var Z = u(82036),
                    ve = u(10900),
                    lt = u(40728);
                let Tn = null;
                (0, f.on)("submit", "[data-autosearch-results-container]", async function(e) {
                    const t = e.currentTarget;
                    if (!(t instanceof HTMLFormElement)) return;
                    e.preventDefault(), Tn == null || Tn.abort(), t.classList.add("is-sending");
                    const n = new URL(t.action, window.location.origin),
                        o = t.method,
                        s = new FormData(t),
                        r = (0, Z.KL)(n, s);
                    let a = null;
                    o === "get" ? n.search = r : a = s;
                    const {
                        signal: c
                    } = Tn = new AbortController, l = new Request(n.toString(), {
                        method: o,
                        body: a,
                        signal: c,
                        headers: {
                            Accept: "text/html",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    });
                    let d;
                    try {
                        d = await fetch(l)
                    } catch {}
                    if (t.classList.remove("is-sending"), !d || !d.ok || c.aborted) return;
                    const p = t.getAttribute("data-autosearch-results-container"),
                        j = p ? document.getElementById(p) : null;
                    j && (j.innerHTML = "", j.appendChild((0, ve.r)(document, await d.text()))), (0, lt.lO)(null, "", `?${r}`)
                });
                var Ce = u(12020),
                    X = u(84570);
                (0, X.ZG)("input[data-autoselect], textarea[data-autoselect]", async function(e) {
                    await (0, Ce.gJ)(), e.select()
                });
                var Ze = u(46263),
                    H = u(86404);
                (0, f.on)("change", "form[data-autosubmit]", function(e) {
                    const t = e.currentTarget;
                    (0, Z.Bt)(t)
                }), (0, f.on)("change", "input[data-autosubmit], select[data-autosubmit]", Fo);

                function Fo(e) {
                    const t = e.target;
                    if (!(t instanceof HTMLInputElement) && !(t instanceof HTMLSelectElement)) return;
                    const n = t.form;
                    (0, Z.Bt)(n)
                }
                i(Fo, "autosubmit_submit");
                const ji = (0, Ze.D)(Fo, 300);
                (0, v.N7)("input[data-throttled-autosubmit]", {
                    subscribe: e => (0, H.RB)(e, "input", ji)
                });
                async function Ti(e) {
                    const t = e.getAttribute("data-url") || "";
                    if (await Ai(t)) {
                        const o = e.getAttribute("data-gravatar-text");
                        o != null && (e.textContent = o)
                    }
                }
                i(Ti, "detectGravatar"), (0, v.N7)(".js-detect-gravatar", function(e) {
                    Ti(e)
                });
                async function Ai(e) {
                    const t = e;
                    if (!t) return !1;
                    try {
                        const n = await fetch(t, {
                            headers: {
                                Accept: "application/json"
                            }
                        });
                        return n.ok ? (await n.json()).has_gravatar : !1
                    } catch {
                        return !1
                    }
                }
                i(Ai, "fetchGravatarInfo");
                var Ci = Object.defineProperty,
                    ki = Object.getOwnPropertyDescriptor,
                    An = i((e, t, n, o) => {
                        for (var s = o > 1 ? void 0 : o ? ki(t, n) : t, r = e.length - 1, a; r >= 0; r--)(a = e[r]) && (s = (o ? a(t, n, s) : a(s)) || s);
                        return o && s && Ci(t, n, s), s
                    }, "batch_deferred_content_decorateClass");
                class Uo {
                    constructor(t = 50, n = 30) {
                        this.elements = [], this.timer = null, this.callbacks = [], this.csrf = null, this.timeout = t, this.limit = n
                    }
                    push(t) {
                        if (this.timer && (window.clearTimeout(this.timer), this.timer = null), t instanceof HTMLElement) {
                            const n = t.querySelector("[data-csrf]");
                            n !== null && (this.csrf = n.value)
                        }
                        this.elements.length >= this.limit && this.flush(), this.elements.push(t), this.timer = window.setTimeout(() => {
                            this.flush()
                        }, this.timeout)
                    }
                    onFlush(t) {
                        this.callbacks.push(t)
                    }
                    async flush() {
                        const t = this.elements.splice(0, this.limit);
                        t.length !== 0 && await Promise.all(this.callbacks.map(n => n(t)))
                    }
                }
                i(Uo, "AutoFlushingQueue");
                async function xi(e, t) {
                    const n = await fetch(e, {
                        method: "POST",
                        body: t,
                        headers: {
                            Accept: "application/json",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    });
                    if (n.ok) {
                        const o = await n.json(),
                            s = new Map;
                        for (const r in o) s.set(r, o[r]);
                        return s
                    } else return new Map
                }
                i(xi, "fetchContents");
                const Wo = new Map;
                let Ht = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.url = ""
                    }
                    connectedCallback() {
                        this.queue.push(this)
                    }
                    get queue() {
                        let e = Wo.get(this.url);
                        return e || (e = this.buildAutoFlushingQueue(), Wo.set(this.url, e), e)
                    }
                    buildAutoFlushingQueue() {
                        const e = new Uo;
                        return e.onFlush(async t => {
                            const n = new Map,
                                o = new FormData;
                            e.csrf !== null && o.set("authenticity_token", e.csrf);
                            for (const r in t) {
                                const a = t[r],
                                    c = `item-${r}`;
                                n.set(c, a);
                                for (const l of a.inputs) o.append(`items[${c}][${l.name}]`, l.value)
                            }
                            o.set("_method", "GET");
                            const s = await xi(this.url, o);
                            for (const [r, a] of s.entries()) n.get(r).replaceWith((0, ve.r)(document, a))
                        }), e
                    }
                }, "BatchDeferredContentElement");
                An([R.Lj], Ht.prototype, "url", 2), An([R.GO], Ht.prototype, "inputs", 2), Ht = An([R.Ih], Ht);
                var ut = u(43682),
                    zo = u(57443),
                    Ot = u(12585);
                let Cn = null;
                (0, f.on)("click", ".js-org-signup-duration-change", e => {
                    e.preventDefault();
                    const n = e.currentTarget.getAttribute("data-plan-duration");
                    qi(n), Ri(n);
                    for (const o of document.querySelectorAll(".js-seat-field")) Je(o);
                    Mi()
                }), (0, f.on)("change", ".js-org-signup-duration-toggle", function({
                    currentTarget: e
                }) {
                    const t = document.getElementById("js-pjax-container"),
                        n = new URL(e.getAttribute("data-url"), window.location.origin);
                    (0, ut.ZP)({
                        url: n.toString(),
                        container: t
                    })
                });
                async function Je(e) {
                    const t = e.getAttribute("data-item-name") || "items",
                        n = e.value,
                        o = new URL(e.getAttribute("data-url"), window.location.origin),
                        s = new URLSearchParams(o.search.slice(1)),
                        r = s.get("plan_duration") || e.getAttribute("data-plan-duration"),
                        a = parseInt(e.getAttribute("data-item-minimum")) || 0,
                        c = parseInt(e.getAttribute("data-item-maximum")) || r === "year" ? 100 : 300,
                        l = parseInt(e.getAttribute("data-item-count")) || 0,
                        d = Math.max(a, parseInt(n) || 0),
                        p = d > c,
                        j = document.querySelector(".js-downgrade-button"),
                        T = document.getElementById("downgrade-disabled-message");
                    j instanceof HTMLButtonElement && (j.disabled = d === l), T instanceof HTMLElement && j instanceof HTMLButtonElement && (T.hidden = !j.disabled), s.append(t, d.toString()), document.querySelector(".js-transform-user") && s.append("transform_user", "1"), o.search = s.toString(), Cn == null || Cn.abort();
                    const {
                        signal: B
                    } = Cn = new AbortController;
                    let $ = null;
                    try {
                        const ze = await fetch(o.toString(), {
                            signal: B,
                            headers: {
                                Accept: "application/json"
                            }
                        });
                        if (!ze.ok) return;
                        $ = await ze.json()
                    } catch {}
                    if (B.aborted || !$) return;
                    const G = document.querySelector(".js-contact-us");
                    G && G.classList.toggle("d-none", !p);
                    const ee = document.querySelector(".js-payment-summary");
                    ee && ee.classList.toggle("d-none", p);
                    const V = document.querySelector(".js-submit-billing");
                    V instanceof HTMLElement && (V.hidden = p);
                    const W = document.querySelector(".js-billing-section");
                    W && W.classList.toggle("has-removed-contents", $.free || $.is_enterprise_cloud_trial);
                    const F = document.querySelector(".js-upgrade-info");
                    F && F.classList.toggle("d-none", d <= 0);
                    const te = document.querySelector(".js-downgrade-info");
                    te && te.classList.toggle("d-none", d >= 0);
                    const be = document.querySelector(".js-extra-seats-line-item");
                    be && be.classList.toggle("d-none", $.no_additional_seats), document.querySelector(".js-seat-field") && Pi(n);
                    const Tt = document.querySelector(".js-minimum-seats-disclaimer");
                    Tt && (Tt.classList.toggle("tooltipped", $.seats === 5), Tt.classList.toggle("tooltipped-nw", $.seats === 5));
                    const De = $.selectors;
                    for (const ze in De)
                        for (const At of document.querySelectorAll(ze)) At.innerHTML = De[ze];
                    (0, lt.lO)((0, ut.y0)(), "", $.url)
                }
                i(Je, "updateTotals");

                function Mi() {
                    for (const e of document.querySelectorAll(".js-unit-price")) e.hidden = !e.hidden
                }
                i(Mi, "toggleDurationUnitPrices");

                function qi(e) {
                    const t = e === "year" ? "month" : "year";
                    for (const o of document.querySelectorAll(".js-plan-duration-text")) o.innerHTML = e;
                    for (const o of document.querySelectorAll(".unstyled-available-plan-duration-adjective")) o.innerHTML = `${e}ly`;
                    for (const o of document.querySelectorAll(".js-org-signup-duration-change")) o.setAttribute("data-plan-duration", t);
                    const n = document.getElementById("signup-plan-duration");
                    n && (n.value = e)
                }
                i(qi, "updateDurationFields");

                function Pi(e) {
                    var t;
                    for (const n of document.querySelectorAll(".js-seat-field")) {
                        const o = n.getAttribute("data-item-max-seats"),
                            s = (t = n == null ? void 0 : n.parentNode) == null ? void 0 : t.querySelector(".Popover");
                        o && o.length ? parseInt(e, 10) > parseInt(o, 10) ? (n.classList.add("color-border-danger-emphasis"), s == null || s.removeAttribute("hidden")) : (n.classList.remove("color-border-danger-emphasis"), s == null || s.setAttribute("hidden", "true"), n.value = e) : n.value = e
                    }
                }
                i(Pi, "updateSeatFields");

                function Ri(e) {
                    for (const t of document.querySelectorAll(".js-seat-field")) {
                        const n = new URL(t.getAttribute("data-url"), window.location.origin),
                            o = new URLSearchParams(n.search.slice(1));
                        o.delete("plan_duration"), o.append("plan_duration", e), n.search = o.toString(), t.setAttribute("data-url", n.toString())
                    }
                }
                i(Ri, "updateSeatFieldURLs"), (0, v.N7)(".js-addon-purchase-field", {
                    constructor: HTMLInputElement,
                    add(e) {
                        (0, Ot.Z)(e) && Je(e), (0, zo.oq)(e, function() {
                            Je(e)
                        })
                    }
                }), (0, v.N7)(".js-addon-downgrade-field", {
                    constructor: HTMLSelectElement,
                    add(e) {
                        (0, Ot.Z)(e) && Je(e), e.addEventListener("change", function() {
                            Je(e)
                        })
                    }
                });

                function Ii(e) {
                    const t = document.querySelector(".js-addon-purchase-field"),
                        n = e.target.querySelector("input:checked");
                    if (t instanceof HTMLInputElement && n instanceof HTMLInputElement) {
                        const o = n.getAttribute("data-upgrade-url");
                        o && (t.setAttribute("data-url", o), t.value = "0", Je(t))
                    }
                }
                i(Ii, "handleOrgChange"), (0, f.on)("details-menu-selected", ".js-organization-container", Ii, {
                    capture: !0
                }), (0, X.q6)(".js-csv-filter-field", function(e) {
                    const t = e.target.value.toLowerCase();
                    for (const n of document.querySelectorAll(".js-csv-data tbody tr")) n instanceof HTMLElement && (!n.textContent || (n.hidden = !!t && !n.textContent.toLowerCase().includes(t)))
                }), (0, v.N7)(".js-blob-header.is-stuck", {
                    add(e) {
                        Vo(e)
                    },
                    remove(e) {
                        Vo(e, !0)
                    }
                });

                function Vo(e, t = !1) {
                    const n = {
                        "tooltipped-nw": "tooltipped-sw",
                        "tooltipped-n": "tooltipped-s",
                        "tooltipped-ne": "tooltipped-se"
                    };
                    for (const [o, s] of Object.entries(n)) {
                        const r = t ? s : o,
                            a = t ? o : s;
                        for (const c of e.querySelectorAll(`.${r}`)) c.classList.replace(r, a)
                    }
                }
                i(Vo, "flipTooltip");

                function Ko(e) {
                    const t = e.match(/#?(?:L)(\d+)((?:C)(\d+))?/g);
                    if (t)
                        if (t.length === 1) {
                            const n = kn(t[0]);
                            return n ? Object.freeze({
                                start: n,
                                end: n
                            }) : void 0
                        } else if (t.length === 2) {
                        const n = kn(t[0]),
                            o = kn(t[1]);
                        return !n || !o ? void 0 : Yo(Object.freeze({
                            start: n,
                            end: o
                        }))
                    } else return;
                    else return
                }
                i(Ko, "parseBlobRange");

                function Ni(e) {
                    const {
                        start: t,
                        end: n
                    } = Yo(e);
                    return t.column != null && n.column != null ? `L${t.line}C${t.column}-L${n.line}C${n.column}` : t.line === n.line ? `L${t.line}` : `L${t.line}-L${n.line}`
                }
                i(Ni, "formatBlobRange");

                function Di(e) {
                    const t = e.match(/(file-.+?-)L\d+?/i);
                    return t ? t[1] : ""
                }
                i(Di, "parseAnchorPrefix");

                function Xo(e) {
                    const t = Ko(e),
                        n = Di(e);
                    return {
                        blobRange: t,
                        anchorPrefix: n
                    }
                }
                i(Xo, "parseFileAnchor");

                function Hi({
                    anchorPrefix: e,
                    blobRange: t
                }) {
                    return t ? `#${e}${Ni(t)}` : "#"
                }
                i(Hi, "formatBlobRangeAnchor");

                function kn(e) {
                    const t = e.match(/L(\d+)/),
                        n = e.match(/C(\d+)/);
                    return t ? Object.freeze({
                        line: parseInt(t[1]),
                        column: n ? parseInt(n[1]) : null
                    }) : null
                }
                i(kn, "parseBlobOffset");

                function Go(e, t) {
                    const [n, o] = Zo(e.start, !0, t), [s, r] = Zo(e.end, !1, t);
                    if (!n || !s) return;
                    let a = o,
                        c = r;
                    if (a === -1 && (a = 0), c === -1 && (c = s.childNodes.length), !n.ownerDocument) throw new Error("DOMRange needs to be inside document");
                    const l = n.ownerDocument.createRange();
                    return l.setStart(n, a), l.setEnd(s, c), l
                }
                i(Go, "DOMRangeFromBlob");

                function Zo(e, t, n) {
                    const o = [null, 0],
                        s = n(e.line);
                    if (!s) return o;
                    if (e.column == null) return [s, -1];
                    let r = e.column - 1;
                    const a = Jo(s);
                    for (let c = 0; c < a.length; c++) {
                        const l = a[c],
                            d = r - (l.textContent || "").length;
                        if (d === 0) {
                            const p = a[c + 1];
                            return t && p ? [p, 0] : [l, r]
                        } else if (d < 0) return [l, r];
                        r = d
                    }
                    return o
                }
                i(Zo, "findRangeOffset");

                function Jo(e) {
                    if (e.nodeType === Node.TEXT_NODE) return [e];
                    if (!e.childNodes || !e.childNodes.length) return [];
                    let t = [];
                    for (const n of e.childNodes) t = t.concat(Jo(n));
                    return t
                }
                i(Jo, "getAllTextNodes");

                function Yo(e) {
                    const t = [e.start, e.end];
                    return t.sort(Oi), t[0] === e.start && t[1] === e.end ? e : Object.freeze({
                        start: t[0],
                        end: t[1]
                    })
                }
                i(Yo, "ascendingBlobRange");

                function Oi(e, t) {
                    return e.line === t.line && e.column === t.column ? 0 : e.line === t.line && typeof e.column == "number" && typeof t.column == "number" ? e.column - t.column : e.line - t.line
                }
                i(Oi, "compareBlobOffsets");
                var Qo = u(76745),
                    we = u(69567),
                    Bt = u(70130);

                function es(e, t) {
                    t.appendChild(e.extractContents()), e.insertNode(t)
                }
                i(es, "surroundContents");
                let xn = !1;

                function Mn(e, t) {
                    return document.querySelector(`#${e}LC${t}`)
                }
                i(Mn, "queryLineElement");

                function Bi({
                    blobRange: e,
                    anchorPrefix: t
                }) {
                    if (document.querySelectorAll(".js-file-line").length !== 0 && (_i(), !!e)) {
                        if (e.start.column === null || e.end.column === null)
                            for (let o = e.start.line; o <= e.end.line; o += 1) {
                                const s = Mn(t, o);
                                s && s.classList.add("highlighted")
                            } else if (e.start.line === e.end.line && e.start.column != null && e.end.column != null) {
                                const o = Go(e, s => Mn(t, s));
                                if (o) {
                                    const s = document.createElement("span");
                                    s.classList.add("highlighted"), es(o, s)
                                }
                            }
                    }
                }
                i(Bi, "highlightLines");

                function _i() {
                    for (const e of document.querySelectorAll(".js-file-line.highlighted")) e.classList.remove("highlighted");
                    for (const e of document.querySelectorAll(".js-file-line .highlighted")) {
                        const t = e.closest(".js-file-line");
                        e.replaceWith(...e.childNodes), t.normalize()
                    }
                }
                i(_i, "clearHighlights");

                function $i() {
                    const e = Xo(window.location.hash);
                    Bi(e), Ki();
                    const {
                        blobRange: t,
                        anchorPrefix: n
                    } = e, o = t && Mn(n, t.start.line);
                    if (!xn && o) {
                        o.scrollIntoView();
                        const s = o.closest(".blob-wrapper, .js-blob-wrapper");
                        s.scrollLeft = 0
                    }
                    xn = !1
                }
                i($i, "scrollLinesIntoView"), (0, Bt.Z)(function() {
                    if (document.querySelector(".js-file-line-container")) {
                        setTimeout($i, 0);
                        const e = window.location.hash;
                        for (const t of document.querySelectorAll(".js-update-url-with-hash"))
                            if (t instanceof HTMLAnchorElement) t.hash = e;
                            else if (t instanceof HTMLFormElement) {
                            const n = new URL(t.action, window.location.origin);
                            n.hash = e, t.action = n.toString()
                        }
                    }
                });

                function Fi(e) {
                    const t = [];
                    for (const o of e) t.push(o.textContent);
                    const n = document.getElementById("js-copy-lines");
                    if (n instanceof Qo.Z) {
                        n.textContent = `Copy ${e.length===1?"line":"lines"}`, n.value = t.join(`
`);
                        const o = `Blob, copyLines, numLines:${e.length.toString()}`;
                        n.setAttribute("data-ga-click", o)
                    }
                }
                i(Fi, "setCopyLines");

                function Ui(e) {
                    const t = document.querySelector(".js-permalink-shortcut");
                    if (t instanceof HTMLAnchorElement) {
                        const n = `${t.href}${window.location.hash}`,
                            o = document.getElementById("js-copy-permalink");
                        if (o instanceof Qo.Z) {
                            o.value = n;
                            const s = `Blob, copyPermalink, numLines:${e.toString()}`;
                            o.setAttribute("data-ga-click", s)
                        }
                        return n
                    }
                }
                i(Ui, "setPermalink");

                function Wi(e, t) {
                    const n = document.getElementById("js-new-issue");
                    if (n instanceof HTMLAnchorElement) {
                        if (!n.href) return;
                        const o = new URL(n.href, window.location.origin),
                            s = new URLSearchParams(o.search);
                        s.set("permalink", e), o.search = s.toString(), n.href = o.toString(), n.setAttribute("data-ga-click", `Blob, newIssue, numLines:${t.toString()}`)
                    }
                }
                i(Wi, "setOpenIssueLink");

                function zi(e, t) {
                    const n = document.getElementById("js-new-discussion");
                    if (!(n instanceof HTMLAnchorElement) || !(n == null ? void 0 : n.href)) return;
                    const o = new URL(n.href, window.location.origin),
                        s = new URLSearchParams(o.search);
                    s.set("permalink", e), o.search = s.toString(), n.href = o.toString(), n.setAttribute("data-ga-click", `Blob, newDiscussion, numLines:${t.toString()}`)
                }
                i(zi, "setOpenDiscussionLink");

                function Vi(e) {
                    const t = document.getElementById("js-view-git-blame");
                    !t || t.setAttribute("data-ga-click", `Blob, viewGitBlame, numLines:${e.toString()}`)
                }
                i(Vi, "setViewGitBlame");

                function Ki() {
                    const e = document.querySelector(".js-file-line-actions");
                    if (!e) return;
                    const t = document.querySelectorAll(".js-file-line.highlighted"),
                        n = t[0];
                    if (n) {
                        Fi(t), Vi(t.length);
                        const o = Ui(t.length);
                        o && Wi(o, t.length), o && zi(o, t.length), e.style.top = `${n.offsetTop-2}px`, e.classList.remove("d-none")
                    } else e.classList.add("d-none")
                }
                i(Ki, "showOrHideLineActions");

                function Xi(e) {
                    const t = window.scrollY;
                    xn = !0, e(), window.scrollTo(0, t)
                }
                i(Xi, "preserveLineNumberScrollPosition"), (0, f.on)("click", ".js-line-number", function(e) {
                    const t = Xo(e.currentTarget.id),
                        {
                            blobRange: n
                        } = t,
                        o = Ko(window.location.hash);
                    o && e.shiftKey && (t.blobRange = {
                        start: o.start,
                        end: n.end
                    }), Xi(() => {
                        window.location.hash = Hi(t)
                    })
                }), (0, f.on)("submit", ".js-jump-to-line-form", function(e) {
                    const o = e.currentTarget.querySelector(".js-jump-to-line-field").value.replace(/[^\d-]/g, "").split("-").map(s => parseInt(s, 10)).filter(s => s > 0).sort((s, r) => s - r);
                    o.length && (window.location.hash = `L${o.join("-L")}`), e.preventDefault()
                }), (0, v.N7)(".js-check-bidi", Ji);
                const Gi = /[\u202A-\u202E]|[\u2066-\u2069]/,
                    ts = {
                        "\u202A": "U+202A",
                        "\u202B": "U+202B",
                        "\u202C": "U+202C",
                        "\u202D": "U+202D",
                        "\u202E": "U+202E",
                        "\u2066": "U+2066",
                        "\u2067": "U+2067",
                        "\u2068": "U+2068",
                        "\u2069": "U+2069"
                    };

                function ns(e, t) {
                    if (e.nodeType === Node.TEXT_NODE) return Zi(e, t);
                    if (!e.childNodes || !e.childNodes.length) return !1;
                    let n = !1;
                    for (const o of e.childNodes)
                        if (n || (n = ns(o, t)), n && !t) break;
                    return n
                }
                i(ns, "checkNodeForBidiCharacters");

                function Zi(e, t) {
                    let n = !1;
                    if (e.nodeValue)
                        for (let o = e.nodeValue.length - 1; o >= 0; o--) {
                            const s = e.nodeValue.charAt(o);
                            if (ts[s]) {
                                if (n = !0, !t) break;
                                const r = new we.R(t, {
                                        revealedCharacter: ts[s]
                                    }),
                                    a = new Range;
                                a.setStart(e, o), a.setEnd(e, o + 1), a.deleteContents(), a.insertNode(r)
                            }
                        }
                    return n
                }
                i(Zi, "checkTextNodeForBidiCharacters");

                function Ji(e) {
                    let t = !1;
                    const n = performance.now(),
                        o = e.textContent || "";
                    if (Gi.test(o)) {
                        const a = e.querySelectorAll(".diff-table .blob-code-inner, .js-file-line-container .js-file-line, .js-suggested-changes-blob .blob-code-inner"),
                            c = document.querySelector(".js-line-alert-template"),
                            l = document.querySelector(".js-revealed-character-template");
                        for (const d of a)
                            if (ns(d, l) && (t = !0, c)) {
                                const p = new we.R(c, {});
                                e.getAttribute("data-line-alert") === "before" ? d.before(p) : d.after(p)
                            }
                    }
                    const r = {
                        durationMs: (performance.now() - n).toString(),
                        result: t.toString()
                    };
                    if ((0, Ge.q)("blob_js_check_bidi_character", r), t) {
                        const a = document.querySelector(".js-file-alert-template");
                        if (a) {
                            const c = new URL(window.location.href, window.location.origin);
                            c.searchParams.get("h") === "1" ? c.searchParams.delete("h") : c.searchParams.set("h", "1");
                            const l = new we.R(a, {
                                revealButtonHref: c.href
                            });
                            e.prepend(l)
                        }
                    }
                    e.classList.remove("js-check-bidi")
                }
                i(Ji, "alertOnBidiCharacter");
                class os {
                    constructor(t, n) {
                        this.lineElement = t, this.numberElement = n
                    }
                    range(t, n) {
                        t = isNaN(t) ? 0 : t, n = isNaN(n) ? 0 : n;
                        let o = null,
                            s = 0,
                            r = 0;
                        for (const [c, l] of this.lineElement.childNodes.entries()) {
                            const d = (l.textContent || "").length;
                            if (d > t && !o && (o = l, s = c), d >= n) {
                                r = c;
                                break
                            }
                            t -= d, n -= d
                        }
                        const a = document.createRange();
                        if (s === r) {
                            for (; o && o.nodeName !== "#text";) o = o.childNodes[0];
                            if (!o) return null;
                            a.setStart(o, t), a.setEnd(o, n)
                        } else a.setStart(this.lineElement, s), a.setEnd(this.lineElement, r + 1);
                        return a
                    }
                }
                i(os, "CodeListingLine");
                class ss {
                    constructor(t) {
                        this.container = t
                    }
                    findLine(t) {
                        if (!t) return null;
                        const n = this.container.querySelector(`.js-blob-rnum[data-line-number='${t}']`);
                        if (!n) return null;
                        let o = n.nextElementSibling;
                        return !o || !o.classList.contains("js-file-line") ? null : (o = o.querySelector(".js-code-nav-pass") || o, new os(o, n))
                    }
                }
                i(ss, "CodeListing");
                const rs = new WeakMap;

                function is(e) {
                    const t = e.closest(".js-blob-code-container, .js-file-content"),
                        n = e.querySelector(".js-codeowners-error-tooltip-template"),
                        o = e.querySelector(".js-codeowners-error-line-alert-template");
                    if (!t || !n || !o) return;
                    const s = e.querySelectorAll(".js-codeowners-error"),
                        r = new ss(t);
                    for (const a of s) {
                        if (rs.get(a)) continue;
                        const c = a.getAttribute("data-line"),
                            l = a.getAttribute("data-kind"),
                            d = a.getAttribute("data-suggestion"),
                            p = parseInt(a.getAttribute("data-start-offset") || "", 10),
                            j = parseInt(a.getAttribute("data-end-offset") || "", 10),
                            T = r.findLine(c),
                            k = T == null ? void 0 : T.range(p, j);
                        if (!T || !k) continue;
                        let B = l;
                        d && (B += `: ${d}`);
                        const $ = document.createElement("SPAN");
                        $.className = "error-highlight", k.surroundContents($);
                        const G = new we.R(n, {
                            message: B
                        }).firstElementChild;
                        k.surroundContents(G);
                        const ee = new we.R(o, {});
                        T.numberElement.appendChild(ee), rs.set(a, !0)
                    }
                }
                i(is, "annotateCodeownersErrors"), (0, v.N7)(".js-codeowners-errors", is), (0, f.on)("expander:expanded", ".js-file", function(e) {
                    if (!e.target || !(e.target instanceof HTMLElement)) return;
                    const t = e.target.querySelector(".js-codeowners-errors");
                    !t || is(t)
                });

                function Yi(e) {
                    const t = e.target,
                        n = t == null ? void 0 : t.closest(".js-branch-protection-integration-select"),
                        o = n == null ? void 0 : n.querySelector(".js-branch-protection-integration-select-current"),
                        s = t == null ? void 0 : t.closest(".js-branch-protection-integration-select-item"),
                        r = s == null ? void 0 : s.querySelector(".js-branch-protection-integration-select-label");
                    o && r && n && (o.innerHTML = r.innerHTML, n.open = !1)
                }
                i(Yi, "changeSelection"), (0, f.on)("change", ".js-branch-protection-integration-select-input", Yi);

                function Qi(e) {
                    const t = new URL(e.getAttribute("data-bulk-actions-url"), window.location.origin),
                        n = new URLSearchParams(t.search.slice(1)),
                        o = e.getAttribute("data-bulk-actions-parameter"),
                        s = Array.from(e.querySelectorAll(".js-bulk-actions-toggle:checked"));
                    if (o) {
                        const r = s.map(a => a.closest(".js-bulk-actions-item").getAttribute("data-bulk-actions-id")).sort();
                        for (const a of r) n.append(`${o}[]`, a)
                    } else
                        for (const r of s.sort((a, c) => a.value > c.value ? 1 : -1)) n.append(r.name, r.value);
                    return t.search = n.toString(), t.toString()
                }
                i(Qi, "bulkUrl");
                let qn = null;
                async function ea(e) {
                    const t = e.target;
                    if (!(t instanceof HTMLElement)) return;
                    const n = t.querySelector(".js-bulk-actions"),
                        o = !!t.querySelector(".js-bulk-actions-toggle:checked");
                    qn == null || qn.abort();
                    const {
                        signal: s
                    } = qn = new AbortController;
                    let r = "";
                    try {
                        const a = await fetch(Qi(t), {
                            signal: s,
                            headers: {
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        });
                        if (!a.ok) return;
                        r = await a.text()
                    } catch {}
                    s.aborted || !r || (o ? (as(t), n.innerHTML = r) : (n.innerHTML = r, as(t)), (0, f.f)(t, "bulk-actions:updated"))
                }
                i(ea, "updateBulkActions");

                function as(e) {
                    const t = document.querySelector(".js-membership-tabs");
                    if (t) {
                        const n = e.querySelectorAll(".js-bulk-actions-toggle:checked");
                        t.classList.toggle("d-none", n.length > 0)
                    }
                }
                i(as, "toggleMembershipTabs"), (0, f.on)("change", ".js-bulk-actions-toggle", function(e) {
                    const n = e.currentTarget.closest(".js-bulk-actions-container");
                    (0, f.f)(n, "bulk-actions:update")
                }), (0, f.on)("bulk-actions:update", ".js-bulk-actions-container", (0, Ze.D)(ea, 100));
                var Ee = u(34782),
                    Le = u(83476);

                function ta(e) {
                    try {
                        const t = window.localStorage.getItem(e);
                        return {
                            kind: "ok",
                            value: t ? JSON.parse(t) : null
                        }
                    } catch (t) {
                        return {
                            kind: "err",
                            value: t
                        }
                    }
                }
                i(ta, "getLocalJSON");

                function cs(e, t) {
                    try {
                        return window.localStorage.setItem(e, JSON.stringify(t)), {
                            kind: "ok",
                            value: null
                        }
                    } catch (n) {
                        return {
                            kind: "err",
                            value: n
                        }
                    }
                }
                i(cs, "setLocalJSON");

                function na() {
                    const e = {};
                    for (const t of document.getElementsByTagName("script")) {
                        const n = t.src.match(/\/([\w-]+)-[0-9a-f]{8,}\.js$/);
                        n && (e[`${n[1]}.js`] = t.src)
                    }
                    for (const t of document.getElementsByTagName("link")) {
                        const n = t.href.match(/\/([\w-]+)-[0-9a-f]{8,}\.css$/);
                        n && (e[`${n[1]}.css`] = t.href)
                    }
                    return e
                }
                i(na, "gatherBundleURLs");

                function oa() {
                    const e = na(),
                        t = ta("bundle-urls");
                    if (t.kind === "err") {
                        cs("bundle-urls", e);
                        return
                    }
                    const n = t.value || {},
                        o = Object.keys(e).filter(s => n[s] !== e[s]);
                    o.length && cs("bundle-urls", { ...n,
                        ...e
                    }).kind === "ok" && (0, Le.b)({
                        downloadedBundles: o
                    })
                }
                i(oa, "report"), (async () => (await Ee.C, window.requestIdleCallback(oa)))();
                var nf = u(49908);

                function sa(e) {
                    e.preventDefault(), e.stopPropagation()
                }
                i(sa, "cancelEvent"), (0, v.N7)("a.btn.disabled", {
                    subscribe: e => (0, H.RB)(e, "click", sa)
                });
                var Pn = u(81266),
                    of = u(83954),
                    dt = u(81503);
                const ls = "logout-was-successful";

                function ra() {
                    for (const e of [sessionStorage, localStorage]) try {
                        e.clear()
                    } catch {}
                }
                i(ra, "clearData");

                function ia() {
                    (0, dt.$1)(ls).length > 0 && (ra(), (0, dt.kT)(ls))
                }
                i(ia, "clearDataIfJustLoggedOut"), ia();
                const us = 2e3;
                (0, f.on)("clipboard-copy", "[data-copy-feedback]", e => {
                    const t = e.currentTarget,
                        n = t.getAttribute("data-copy-feedback"),
                        o = t.getAttribute("aria-label"),
                        s = t.getAttribute("data-tooltip-direction") || "s";
                    t.setAttribute("aria-label", n), t.classList.add("tooltipped", `tooltipped-${s}`), t instanceof HTMLElement && ((0, ue.N)(t), setTimeout(() => {
                        o ? t.setAttribute("aria-label", o) : t.removeAttribute("aria-label"), t.classList.remove("tooltipped", `tooltipped-${s}`)
                    }, us))
                });

                function aa(e) {
                    Rn.delete(e), ds(e)
                }
                i(aa, "timerCallback");

                function ds(e) {
                    const t = e.querySelector(".js-clipboard-copy-icon"),
                        n = e.querySelector(".js-clipboard-check-icon");
                    e.classList.toggle("ClipboardButton--success"), t && t.classList.toggle("d-none"), n && (n.classList.contains("d-sm-none") ? n.classList.toggle("d-sm-none") : n.classList.toggle("d-none"))
                }
                i(ds, "toggleCopyButton");
                const Rn = new WeakMap;
                (0, f.on)("clipboard-copy", ".js-clipboard-copy:not([data-view-component])", function({
                    currentTarget: e
                }) {
                    if (!(e instanceof HTMLElement)) return;
                    const t = Rn.get(e);
                    t ? clearTimeout(t) : ds(e), Rn.set(e, window.setTimeout(aa, us, e))
                }), (0, f.on)("click", ".js-code-nav-retry", async function(e) {
                    if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
                    const t = document.querySelector(".js-tagsearch-popover");
                    if (!t) return;
                    const n = t.querySelector(".js-tagsearch-popover-content");
                    if (!n) return;
                    let o;
                    const s = e.currentTarget;
                    if (s.getAttribute("data-code-nav-kind") === "definitions" ? o = t.querySelector(".js-tagsearch-popover-content") : o = t.querySelector(".js-code-nav-references"), !o) return;
                    const a = s.getAttribute("data-code-nav-url");
                    if (!a) return;
                    const c = new URL(a, window.location.origin);
                    try {
                        const l = await fetch(c.toString(), {
                            headers: {
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        });
                        if (!l.ok) return;
                        const d = await l.text();
                        if (!d) return;
                        o.innerHTML = d
                    } catch {
                        return
                    }
                    n.scrollTop = 0
                }), (0, v.N7)(".js-code-nav-container", {
                    constructor: HTMLElement,
                    subscribe(e) {
                        const t = e,
                            n = document.querySelector(".js-tagsearch-popover");
                        if (!(n instanceof HTMLElement)) return {
                            unsubscribe() {}
                        };
                        const o = n.querySelector(".js-tagsearch-popover-content"),
                            s = new WeakMap,
                            r = new WeakMap;
                        let a;
                        c();

                        function c() {
                            B();
                            for (const V of document.getElementsByClassName("pl-token")) V.classList.remove("pl-token", "active")
                        }
                        i(c, "initialize");
                        async function l(V) {
                            const W = la(/\w+[!?]?/g, V.clientX, V.clientY);
                            if (!W) return;
                            const F = W.commonAncestorContainer.parentElement;
                            for (const Zd of F.classList)
                                if (["pl-token", "pl-c", "pl-s", "pl-k"].includes(Zd)) return;
                            if (F.closest(".js-skip-tagsearch")) return;
                            const te = W.toString();
                            if (!te || te.match(/\n|\s|[();&.=",]/)) return;
                            let be = r.get(F);
                            if (be || (be = new Set, r.set(F, be)), be.has(te)) return;
                            be.add(te);
                            const Ne = F.closest(".js-tagsearch-file");
                            if (!Ne) return;
                            const Tt = Ne.getAttribute("data-tagsearch-path") || "";
                            let De = Ne.getAttribute("data-tagsearch-lang") || "";
                            if (De === "HTML+ERB")
                                if (F.closest(".pl-sre")) De = "Ruby";
                                else return;
                            if (e.classList.contains("js-code-block-container") && (De = da(F) || "", !De)) return;
                            const ze = fa(W),
                                At = await ca(n, te, De, ze, Tt);
                            if (!At) return;
                            const st = document.createElement("span");
                            st.classList.add("pl-token"), st.addEventListener("click", p);
                            const ai = document.createElement("span");
                            ai.innerHTML = At;
                            const qo = ai.firstElementChild;
                            if (!qo) return;
                            const ci = qo.getAttribute("data-hydro-click"),
                                li = qo.getAttribute("data-hydro-click-hmac");
                            li && ci && (st.setAttribute("data-hydro-click", ci), st.setAttribute("data-hydro-click-hmac", li)), s.set(st, At), W.surroundContents(st)
                        }
                        i(l, "onMouseMove");

                        function d() {
                            o.scrollTop = 0
                        }
                        i(d, "resetScrollTop");

                        function p(V) {
                            if (V.altKey || V.ctrlKey || V.metaKey || V.shiftKey) return;
                            const W = V.currentTarget;
                            W === a ? B() : (j(W), k()), V.preventDefault()
                        }
                        i(p, "onClick");

                        function j(V) {
                            a && a.classList.remove("active"), a = V, a.classList.add("active"), o.innerHTML = s.get(V) || "", T(V)
                        }
                        i(j, "populatePopover");

                        function T(V) {
                            const W = t.getClientRects()[0],
                                F = V.getClientRects()[0];
                            n.style.position = "absolute", n.style.zIndex = "2", t.classList.contains("position-relative") ? (n.style.top = `${F.bottom-W.top+7}px`, n.style.left = `${F.left-W.left-10}px`) : (n.style.top = `${window.scrollY+F.bottom}px`, n.style.left = `${window.scrollX+F.left}px`)
                        }
                        i(T, "positionPopover");

                        function k() {
                            if (!n.hidden) {
                                d();
                                return
                            }
                            n.hidden = !1, d(), document.addEventListener("click", G), document.addEventListener("keyup", ee), window.addEventListener("resize", $)
                        }
                        i(k, "showPopover");

                        function B() {
                            n.hidden || (n.hidden = !0, a && a.classList.remove("active"), a = void 0, document.removeEventListener("click", G), document.removeEventListener("keyup", ee), window.removeEventListener("resize", $))
                        }
                        i(B, "hidePopover");

                        function $() {
                            a instanceof HTMLElement && T(a)
                        }
                        i($, "onResize");

                        function G(V) {
                            const {
                                target: W
                            } = V;
                            W instanceof Node && !n.contains(W) && !a.contains(W) && B()
                        }
                        i(G, "onDocumentClick");

                        function ee(V) {
                            switch (V.key) {
                                case "Escape":
                                    B();
                                    break
                            }
                        }
                        return i(ee, "onKeyup"), e.addEventListener("mousemove", l), {
                            unsubscribe() {
                                e.removeEventListener("mousemove", l)
                            }
                        }
                    }
                });
                async function ca(e, t, n, o, s) {
                    const r = e.getAttribute("data-tagsearch-url");
                    if (!r) return "";
                    const a = e.getAttribute("data-tagsearch-ref");
                    if (!a) return "";
                    let c = e.getAttribute("data-tagsearch-code-nav-context");
                    c || (c = "UNKNOWN_VIEW");
                    const l = new URL(r, window.location.origin),
                        d = new URLSearchParams;
                    d.set("q", t), d.set("blob_path", s), d.set("ref", a), d.set("language", n), d.set("row", o[0].toString()), d.set("col", o[1].toString()), d.set("code_nav_context", c), l.search = d.toString();
                    try {
                        const p = await fetch(l.toString(), {
                            headers: {
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        });
                        if (!p.ok) return "";
                        const j = await p.text();
                        return /js-tagsearch-no-definitions/.test(j) ? "" : j
                    } catch {
                        return ""
                    }
                }
                i(ca, "fetchPopoverContents");

                function la(e, t, n) {
                    let o, s;
                    if (document.caretPositionFromPoint) {
                        const l = document.caretPositionFromPoint(t, n);
                        l && (o = l.offsetNode, s = l.offset)
                    } else if (document.caretRangeFromPoint) {
                        const l = document.caretRangeFromPoint(t, n);
                        l && (o = l.startContainer, s = l.startOffset)
                    }
                    if (!o || typeof s != "number" || o.nodeType !== Node.TEXT_NODE) return;
                    const r = o.textContent;
                    if (!r) return null;
                    const a = ua(r, e, s);
                    if (!a) return null;
                    const c = document.createRange();
                    return c.setStart(o, a[1]), c.setEnd(o, a[2]), c
                }
                i(la, "matchFromPoint");

                function ua(e, t, n) {
                    let o;
                    for (; o = t.exec(e);) {
                        const s = o.index + o[0].length;
                        if (o.index <= n && n < s) return [o[0], o.index, s]
                    }
                    return null
                }
                i(ua, "findNearestMatch");

                function da(e) {
                    const t = e.closest(".highlight");
                    if (t)
                        for (const n of t.classList) switch (n) {
                            case "highlight-source-go":
                                return "Go";
                            case "highlight-source-js":
                                return "JavaScript";
                            case "highlight-source-python":
                                return "Python";
                            case "highlight-source-ruby":
                                return "Ruby";
                            case "highlight-source-ts":
                                return "TypeScript"
                        }
                    return null
                }
                i(da, "getCodeBlockLanguage");

                function fa(e) {
                    let t = e.startContainer,
                        n = e.startOffset,
                        o = !1;
                    for (;;) {
                        let s = t.previousSibling;
                        for (; !o && s;)["#comment", "BUTTON"].includes(s.nodeName) || (n += (s.textContent || "").length), s = s.previousSibling;
                        const r = t.parentElement;
                        if (r) {
                            if (r.classList.contains("js-code-nav-pass")) o = !0;
                            else if (r.classList.contains("js-file-line")) {
                                const a = r.previousElementSibling;
                                if (!a.classList.contains("js-code-nav-line-number")) throw new Error("invariant");
                                return [parseInt(a.getAttribute("data-line-number") || "1", 10) - 1, n]
                            }
                            t = r
                        } else return [0, 0]
                    }
                }
                i(fa, "getRowAndColumn");
                var Be = u(74136);

                function ma(e) {
                    const t = e.querySelector(".js-comment-form-error");
                    t instanceof HTMLElement && (t.hidden = !0)
                }
                i(ma, "clearFormError"), (0, f.on)("click", ".errored.js-remove-error-state-on-click", function({
                    currentTarget: e
                }) {
                    e.classList.remove("errored")
                }), (0, K.AC)(".js-new-comment-form", async function(e, t) {
                    let n;
                    ma(e);
                    try {
                        n = await t.json()
                    } catch (r) {
                        ha(e, r)
                    }
                    if (!n) return;
                    e.reset();
                    for (const r of e.querySelectorAll(".js-resettable-field"))(0, Z.Se)(r, r.getAttribute("data-reset-value") || "");
                    const o = e.querySelector(".js-write-tab");
                    o instanceof HTMLElement && o.click();
                    const s = n.json.updateContent;
                    for (const r in s) {
                        const a = s[r],
                            c = document.querySelector(r);
                        c instanceof HTMLElement ? (0, Be.Of)(c, a) : console.warn(`couldn't find ${r} for immediate update`)
                    }(0, f.f)(e, "comment:success")
                });

                function ha(e, t) {
                    let n = "You can't comment at this time";
                    if (t.response && t.response.status === 422) {
                        const s = t.response.json;
                        s.errors && (Array.isArray(s.errors) ? n += ` \u2014 your comment ${s.errors.join(", ")}` : n = s.errors)
                    }
                    n += ". ";
                    const o = e.querySelector(".js-comment-form-error");
                    if (o instanceof HTMLElement) {
                        o.textContent = n, o.hidden = !1;
                        const s = o.closest("div.form-group.js-remove-error-state-on-click");
                        s && s.classList.add("errored")
                    }
                }
                i(ha, "handleFormError");
                const pa = i((e, t) => {
                        const n = e.querySelector(".js-form-action-text"),
                            o = n || e;
                        o.textContent = t ? e.getAttribute("data-comment-text") : o.getAttribute("data-default-action-text")
                    }, "setButtonText"),
                    ga = i(e => {
                        let t;
                        return n => {
                            const s = n.currentTarget.value.trim();
                            s !== t && (t = s, pa(e, Boolean(s)))
                        }
                    }, "createInputHandler");
                (0, v.N7)(".js-comment-and-button", {
                    constructor: HTMLButtonElement,
                    initialize(e) {
                        const t = e.form.querySelector(".js-comment-field"),
                            n = ga(e);
                        return {
                            add() {
                                t.addEventListener("input", n), t.addEventListener("change", n)
                            },
                            remove() {
                                t.removeEventListener("input", n), t.removeEventListener("change", n)
                            }
                        }
                    }
                });
                var sf = u(77546);

                function fs(e, t) {
                    const n = e.closest(".js-write-bucket");
                    n && n.classList.toggle("focused", t)
                }
                i(fs, "toggleFocus");

                function ba(e) {
                    const t = e.currentTarget;
                    t instanceof Element && fs(t, !1)
                }
                i(ba, "blurred"), (0, X.ZG)(".js-comment-field", function(e) {
                    fs(e, !0), e.addEventListener("blur", ba, {
                        once: !0
                    })
                });
                var Ye = u(77434),
                    he = u(52769),
                    In = u(34078);
                const ya = 2303741511,
                    va = 4;
                class _t {
                    static fromFile(t) {
                        return new Promise(function(n, o) {
                            const s = new FileReader;
                            s.onload = function() {
                                n(new _t(s.result))
                            }, s.onerror = function() {
                                o(s.error)
                            }, s.readAsArrayBuffer(t)
                        })
                    }
                    constructor(t) {
                        this.dataview = new DataView(t), this.pos = 0
                    }
                    advance(t) {
                        this.pos += t
                    }
                    readInt(t) {
                        const n = this,
                            o = function() {
                                switch (t) {
                                    case 1:
                                        return n.dataview.getUint8(n.pos);
                                    case 2:
                                        return n.dataview.getUint16(n.pos);
                                    case 4:
                                        return n.dataview.getUint32(n.pos);
                                    default:
                                        throw new Error("bytes parameter must be 1, 2 or 4")
                                }
                            }();
                        return this.advance(t), o
                    }
                    readChar() {
                        return this.readInt(1)
                    }
                    readShort() {
                        return this.readInt(2)
                    }
                    readLong() {
                        return this.readInt(4)
                    }
                    readString(t) {
                        const n = [];
                        for (let o = 0; o < t; o++) n.push(String.fromCharCode(this.readChar()));
                        return n.join("")
                    }
                    scan(t) {
                        if (this.readLong() !== ya) throw new Error("invalid PNG");
                        for (this.advance(4);;) {
                            const n = this.readLong(),
                                o = this.readString(4),
                                s = this.pos + n + va;
                            if (t.call(this, o, n) === !1 || o === "IEND") break;
                            this.pos = s
                        }
                    }
                }
                i(_t, "PNGScanner");
                const wa = .0254;
                async function Ea(e) {
                    if (e.type !== "image/png") return null;
                    const t = e.slice(0, 10240, e.type),
                        n = await _t.fromFile(t),
                        o = {
                            width: 0,
                            height: 0,
                            ppi: 1
                        };
                    return n.scan(function(s) {
                        switch (s) {
                            case "IHDR":
                                return o.width = this.readLong(), o.height = this.readLong(), !0;
                            case "pHYs":
                                {
                                    const r = this.readLong(),
                                        a = this.readLong(),
                                        c = this.readChar();
                                    let l;
                                    return c === 1 && (l = wa),
                                    l && (o.ppi = Math.round((r + a) / 2 * l)),
                                    !1
                                }
                            case "IDAT":
                                return !1
                        }
                        return !0
                    }), o
                }
                i(Ea, "imageDimensions");
                var La = u(89900);
                const $t = new WeakMap;
                class ms {
                    constructor(t, n, o) {
                        this.index = t, this.coords = n, this.textArea = o
                    }
                    get top() {
                        return this.coords.top
                    }
                    get left() {
                        return this.coords.left
                    }
                    get height() {
                        return this.coords.height
                    }
                    currentChar(t = 1) {
                        return this.textArea.value.substring(this.index - t, this.index)
                    }
                    checkLine(t) {
                        return t < this.coords.top ? -1 : t > this.coords.top + this.coords.height ? 1 : 0
                    }
                    xDistance(t) {
                        return Math.abs(this.left - t)
                    }
                }
                i(ms, "CaretPosition");

                function ke(e, t) {
                    let n;
                    if ($t.has(e) ? n = $t.get(e) : (n = new Map, $t.set(e, n)), n.has(t)) return n.get(t); {
                        const o = new ms(t, (0, La.Z)(e, t), e);
                        return n.set(t, o), o
                    }
                }
                i(ke, "fetchCaretCoords");
                const ft = i((e, t, n, o, s, r) => {
                        if (n === t) return n;
                        const a = i(p => {
                            const j = p.filter(T => T.checkLine(s) === 0).sort((T, k) => T.xDistance(o) > k.xDistance(o) ? 1 : -1);
                            return j.length === 0 ? n : j[0].index
                        }, "bestPosition");
                        if (n - t === 1) {
                            const p = ke(e, t),
                                j = ke(e, n);
                            return a([p, j])
                        }
                        if (n - t === 2) {
                            const p = ke(e, t),
                                j = ke(e, n - 1),
                                T = ke(e, n);
                            return a([p, j, T])
                        }
                        const c = Math.floor((n + t) / 2);
                        if (c === t || c === n) return c;
                        const l = ke(e, c);
                        if (s > l.top + l.height) return ft(e, c + 1, n, o, s, r + 1);
                        if (s < l.top) return ft(e, t, c - 1, o, s, r + 1);
                        const d = 3;
                        return l.xDistance(o) < d ? c : l.left < o ? ke(e, c + 1).checkLine(s) !== 0 ? c : ft(e, c + 1, n, o, s, r + 1) : l.left > o ? ke(e, c - 1).checkLine(s) !== 0 ? c : ft(e, t, c - 1, o, s, r + 1) : c
                    }, "binaryCursorSearch"),
                    Sa = i((e, t, n) => {
                        const s = e.value.length - 1;
                        return ft(e, 0, s, t, n, 0)
                    }, "findCursorPosition");

                function ja(e, t, n) {
                    const o = Sa(e, t, n);
                    e.setSelectionRange(o, o)
                }
                i(ja, "setCursorPosition");

                function Ta(e, t) {
                    const n = e.getBoundingClientRect();
                    t.type === "dragenter" && $t.delete(e);
                    const o = t.clientX - n.left,
                        s = t.clientY - n.top + e.scrollTop;
                    ja(e, o, s)
                }
                i(Ta, "caret_placement_updateCaret"), (0, v.N7)(".js-paste-markdown", {
                    constructor: HTMLElement,
                    add(e) {
                        (0, he.F6)(e), (0, he.CR)(e), (0, he.jw)(e), (0, he.AL)(e), (0, he.AI)(e)
                    },
                    remove(e) {
                        (0, he.KB)(e), (0, he.XR)(e), (0, he.Hl)(e), (0, he.mK)(e), (0, he.TR)(e)
                    }
                });
                const Nn = new WeakMap;

                function rf(e, t) {
                    Nn.set(e, t)
                }
                i(rf, "cachePlaceholder");

                function Aa(e) {
                    return Nn.get(e) || ps(e)
                }
                i(Aa, "getPlaceholder");

                function Dn(e) {
                    return ["video/mp4", "video/quicktime"].includes(e.file.type)
                }
                i(Dn, "isVideo");

                function Ca(e) {
                    return e.replace(/[[\]\\"<>&]/g, ".").replace(/\.{2,}/g, ".").replace(/^\.|\.$/gi, "")
                }
                i(Ca, "parameterizeName");

                function hs(e) {
                    return Dn(e) ? `
Uploading ${e.file.name}\u2026
` : `${e.isImage()?"!":""}[Uploading ${e.file.name}\u2026]()`
                }
                i(hs, "placeholderText");

                function ka(e) {
                    return Ca(e).replace(/\.[^.]+$/, "").replace(/\./g, " ")
                }
                i(ka, "altText");
                const xa = 72 * 2;

                function Ft(e) {
                    const n = e.target.closest("form").querySelector(".btn-primary");
                    n.disabled = !0
                }
                i(Ft, "disableSubmit");

                function Ut(e) {
                    const n = e.target.closest("form").querySelector(".btn-primary");
                    n.disabled = !1
                }
                i(Ut, "enableSubmit");
                async function Ma(e) {
                    const {
                        attachment: t
                    } = e.detail, n = e.currentTarget;
                    let o;
                    t.isImage() ? o = await Ra(t) : Dn(t) ? o = Pa(t) : o = qa(t), bs("", o, e, n)
                }
                i(Ma, "onUploadCompleted");

                function qa(e) {
                    return `[${e.file.name}](${e.href})`
                }
                i(qa, "mdLink");

                function Pa(e) {
                    return `
${e.href}
`
                }
                i(Pa, "videoMarkdown");
                async function Ra(e) {
                    const t = await Ia(e.file),
                        n = ka(e.file.name),
                        o = e.href;
                    return t.ppi === xa ? `<img width="${Math.round(t.width/2)}" alt="${n}" src="${o}">` : `![${n}](${o})`
                }
                i(Ra, "imageTag");
                async function Ia(e) {
                    var t;
                    const n = {
                        width: 0,
                        height: 0,
                        ppi: 0
                    };
                    try {
                        return (t = await Ea(e)) != null ? t : n
                    } catch {
                        return n
                    }
                }
                i(Ia, "imageSize");

                function ps(e) {
                    const t = hs(e);
                    return Dn(e) ? `
${t}
` : `${t}
`
                }
                i(ps, "replacementText");

                function gs(e) {
                    const t = e.currentTarget.querySelector(".js-comment-field"),
                        n = Aa(e.detail.attachment);
                    if (t) t.setCustomValidity(""), (0, Ye.lp)(t, n, "");
                    else {
                        const s = (0, In.P)(e.currentTarget.querySelector(".js-code-editor")).editor.getSearchCursor(n);
                        s.findNext(), s.replace("")
                    }
                }
                i(gs, "removeFailedUpload");

                function bs(e, t, n, o) {
                    const s = (o || n.currentTarget).querySelector(".js-comment-field"),
                        r = (o || n.currentTarget).querySelector(".js-file-upload-loading-text"),
                        a = hs(n.detail.attachment),
                        {
                            batch: c
                        } = n.detail;
                    if (s) {
                        const l = s.value.substring(s.selectionStart, s.selectionEnd);
                        if (e === "uploading") {
                            let d;
                            l.length ? d = (0, Ye.t4)(s, l, a) : d = (0, Ye.Om)(s, a, {
                                appendNewline: !0
                            }), Nn.set(n.detail.attachment, d)
                        } else(0, Ye.lp)(s, a, t);
                        c.isFinished() ? Ut(n) : Ft(n)
                    } else {
                        const l = (0, In.P)((o || n.currentTarget).querySelector(".js-code-editor")).editor;
                        if (e === "uploading")
                            if (l.getSelection().length) l.replaceSelection(a);
                            else {
                                const d = l.getCursor(),
                                    p = ps(n.detail.attachment);
                                l.replaceRange(p, d)
                            }
                        else {
                            const d = l.getSearchCursor(a);
                            d.findNext(), d.replace(t)
                        }
                        c.isFinished() ? Ut(n) : Ft(n)
                    }
                    if (r) {
                        const l = r.getAttribute("data-file-upload-message");
                        r.textContent = `${l} (${c.uploaded()+1}/${c.size})`
                    }
                }
                i(bs, "setValidityAndLinkText"), (0, f.on)("upload:setup", ".js-upload-markdown-image", function(e) {
                    bs("uploading", "", e)
                }), (0, f.on)("upload:complete", ".js-upload-markdown-image", Ma), (0, f.on)("upload:error", ".js-upload-markdown-image", function(e) {
                    gs(e);
                    const {
                        batch: t
                    } = e.detail;
                    t.isFinished() ? Ut(e) : Ft(e)
                });

                function ys(e) {
                    var t;
                    e.stopPropagation();
                    const n = e.currentTarget;
                    if (!n) return;
                    const o = n.querySelector(".js-comment-field");
                    if (o) Ta(o, e);
                    else {
                        const s = (t = (0, In.P)(n.querySelector(".js-code-editor"))) == null ? void 0 : t.editor;
                        if (s) {
                            const r = s.coordsChar({
                                left: e.pageX,
                                top: e.pageY
                            });
                            s.setCursor(r)
                        }
                    }
                }
                i(ys, "updateCursor");
                const af = i(e => {
                    const t = e.currentTarget,
                        n = t.getBoundingClientRect(),
                        o = e.clientX - n.left,
                        s = e.clientY - n.top + t.scrollTop;
                    console.log({
                        x: o,
                        y: s,
                        cursor: t.selectionStart,
                        t: t.value.substring(t.selectionStart - 10, t.selectionStart)
                    });
                    const r = new DragEvent("dragenter", {
                        clientX: e.clientX,
                        clientY: e.clientY
                    });
                    updateCaret(t, r)
                }, "debugUpdateCaret");
                (0, f.on)("dragenter", "file-attachment", ys), (0, f.on)("dragover", "file-attachment", ys), (0, f.on)("upload:invalid", ".js-upload-markdown-image", function(e) {
                    gs(e);
                    const {
                        batch: t
                    } = e.detail;
                    t.isFinished() ? Ut(e) : Ft(e)
                });
                var Hn = u(29501),
                    Se = u(4687);

                function Na(e) {
                    const t = e.querySelector(".js-data-preview-url-csrf"),
                        n = e.closest("form").elements.namedItem("authenticity_token");
                    if (t instanceof HTMLInputElement) return t.value;
                    if (n instanceof HTMLInputElement) return n.value;
                    throw new Error("Comment preview authenticity token not found")
                }
                i(Na, "token");

                function On(e) {
                    const t = e.closest(".js-previewable-comment-form"),
                        n = e.classList.contains("js-preview-tab");
                    if (n) {
                        const r = t.querySelector(".js-write-bucket"),
                            a = t.querySelector(".js-preview-body");
                        r.clientHeight > 0 && (a.style.minHeight = `${r.clientHeight}px`)
                    }
                    t.classList.toggle("preview-selected", n), t.classList.toggle("write-selected", !n);
                    const o = t.querySelector('.tabnav-tab.selected, .tabnav-tab[aria-selected="true"]');
                    o.setAttribute("aria-selected", "false"), o.classList.remove("selected"), e.classList.add("selected"), e.setAttribute("aria-selected", "true");
                    const s = t.querySelector(".js-write-tab");
                    return n ? s.setAttribute("data-hotkey", "Control+P,Meta+Shift+p") : s.removeAttribute("data-hotkey"), t
                }
                i(On, "activateTab"), (0, f.on)("click", ".js-write-tab", function(e) {
                    const t = e.currentTarget,
                        n = t.closest(".js-previewable-comment-form");
                    if (n instanceof Hn.Z) {
                        setTimeout(() => {
                            n.querySelector(".js-comment-field").focus()
                        });
                        return
                    }
                    const o = On(t);
                    (0, f.f)(n, "preview:toggle:off");
                    const s = n.querySelector(".js-discussion-poll-form-component");
                    s && (0, f.f)(s, "poll-preview:toggle:off"), setTimeout(() => {
                        o.querySelector(".js-comment-field").focus()
                    });
                    const r = n.querySelector("markdown-toolbar");
                    r instanceof HTMLElement && (r.hidden = !1)
                }), (0, f.on)("click", ".js-preview-tab", function(e) {
                    const t = e.currentTarget,
                        n = t.closest(".js-previewable-comment-form");
                    if (n instanceof Hn.Z) return;
                    const o = On(t);
                    (0, f.f)(n, "preview:toggle:on"), setTimeout(() => {
                        _n(o)
                    });
                    const s = n.querySelector("markdown-toolbar");
                    s instanceof HTMLElement && (s.hidden = !0), e.stopPropagation(), e.preventDefault()
                }), (0, f.on)("tab-container-change", ".js-previewable-comment-form", function(e) {
                    const t = e.detail.relatedTarget,
                        n = t && t.classList.contains("js-preview-panel"),
                        o = e.currentTarget,
                        s = o.querySelector(".js-write-tab");
                    if (n) {
                        const r = o.querySelector(".js-write-bucket"),
                            a = o.querySelector(".js-preview-body");
                        !a.hasAttribute("data-skip-sizing") && r.clientHeight > 0 && (a.style.minHeight = `${r.clientHeight}px`), s.setAttribute("data-hotkey", "Control+P,Meta+Shift+p"), _n(o);
                        const l = o.querySelector("markdown-toolbar");
                        l instanceof HTMLElement && (l.hidden = !0)
                    } else {
                        s.removeAttribute("data-hotkey");
                        const r = o.querySelector("markdown-toolbar");
                        r instanceof HTMLElement && (r.hidden = !1);
                        const a = document.querySelector(".js-discussion-poll-form-component");
                        a && (0, f.f)(a, "poll-preview:toggle:off")
                    }
                    o.classList.toggle("preview-selected", n), o.classList.toggle("write-selected", !n)
                }), (0, f.on)("preview:render", ".js-previewable-comment-form", function(e) {
                    const t = e.target.querySelector(".js-preview-tab"),
                        n = On(t);
                    setTimeout(() => {
                        _n(n);
                        const o = n.querySelector("markdown-toolbar");
                        o instanceof HTMLElement && (o.hidden = !0)
                    })
                });

                function Da(e) {
                    var t, n, o, s, r, a, c, l, d;
                    const p = e.querySelector(".js-comment-field").value,
                        j = (t = e.querySelector(".js-path")) == null ? void 0 : t.value,
                        T = (n = e.querySelector(".js-line-number")) == null ? void 0 : n.value,
                        k = (o = e.querySelector(".js-start-line-number")) == null ? void 0 : o.value,
                        B = (s = e.querySelector(".js-side")) == null ? void 0 : s.value,
                        $ = (r = e.querySelector(".js-start-side")) == null ? void 0 : r.value,
                        G = (a = e.querySelector(".js-start-commit-oid")) == null ? void 0 : a.value,
                        ee = (c = e.querySelector(".js-end-commit-oid")) == null ? void 0 : c.value,
                        V = (l = e.querySelector(".js-base-commit-oid")) == null ? void 0 : l.value,
                        W = (d = e.querySelector(".js-comment-id")) == null ? void 0 : d.value,
                        F = new FormData;
                    return F.append("text", p), F.append("authenticity_token", Na(e)), j && F.append("path", j), T && F.append("line_number", T), k && F.append("start_line_number", k), B && F.append("side", B), $ && F.append("start_side", $), G && F.append("start_commit_oid", G), ee && F.append("end_commit_oid", ee), V && F.append("base_commit_oid", V), W && F.append("comment_id", W), F
                }
                i(Da, "previewForm");

                function vs(e) {
                    const t = e.getAttribute("data-preview-url"),
                        n = Da(e);
                    return (0, f.f)(e, "preview:setup", {
                        data: n
                    }), Ha(t, n)
                }
                i(vs, "fetchPreview");
                const Ha = (0, Se.Z)(Oa, {
                    hash: Ba
                });
                let Bn = null;
                async function Oa(e, t) {
                    Bn == null || Bn.abort();
                    const {
                        signal: n
                    } = Bn = new AbortController, o = await fetch(e, {
                        method: "post",
                        body: t,
                        signal: n
                    });
                    if (!o.ok) throw new Error("something went wrong");
                    return o.text()
                }
                i(Oa, "uncachedFetch");

                function Ba(e, t) {
                    const n = [...t.entries()].toString();
                    return `${e}:${n}`
                }
                i(Ba, "hash");
                async function _n(e) {
                    const t = e.querySelector(".comment-body");
                    t.innerHTML = "<p>Loading preview&hellip;</p>";
                    try {
                        const n = await vs(e);
                        t.innerHTML = n || "<p>Nothing to preview</p>", (0, f.f)(e, "preview:rendered")
                    } catch (n) {
                        n.name !== "AbortError" && (t.innerHTML = "<p>Error rendering preview</p>")
                    }
                }
                i(_n, "renderPreview"), (0, v.N7)(".js-preview-tab", function(e) {
                    e.addEventListener("mouseenter", async () => {
                        const t = e.closest(".js-previewable-comment-form");
                        try {
                            await vs(t)
                        } catch {}
                    })
                }), (0, X.w4)("keydown", ".js-comment-field", function(e) {
                    const t = e.target;
                    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toUpperCase() === "P") {
                        const n = t.closest(".js-previewable-comment-form");
                        n.classList.contains("write-selected") && (n instanceof Hn.Z ? n.querySelector(".js-preview-tab").click() : (t.blur(), n.dispatchEvent(new CustomEvent("preview:render", {
                            bubbles: !0,
                            cancelable: !1
                        }))), e.preventDefault(), e.stopImmediatePropagation())
                    }
                });
                const ws = /^(\+1|-1|:\+1?|:-1?)$/,
                    _a = i(e => {
                        let t = !1;
                        for (const n of e.split(`
`)) {
                            const o = n.trim();
                            if (!(!o || o.startsWith(">"))) {
                                if (t && ws.test(o) === !1) return !1;
                                !t && ws.test(o) && (t = !0)
                            }
                        }
                        return t
                    }, "isReactionLikeComment");
                (0, f.on)("focusout", "#new_comment_field", function(e) {
                    const n = e.currentTarget.closest(".js-reaction-suggestion");
                    n && Ls(n)
                }), (0, f.on)("focusin", "#new_comment_field", function(e) {
                    Es(e)
                }), (0, X.w4)("keyup", "#new_comment_field", function(e) {
                    Es(e)
                });

                function Es(e) {
                    const t = e.target,
                        n = t.value,
                        o = t.closest(".js-reaction-suggestion");
                    if (!!o)
                        if (_a(n)) {
                            o.classList.remove("hide-reaction-suggestion"), o.classList.add("reaction-suggestion");
                            const s = o.getAttribute("data-reaction-markup");
                            o.setAttribute("data-reaction-suggestion-message", s)
                        } else Ls(o)
                }
                i(Es, "toggleReactionSuggestion");

                function Ls(e) {
                    e.classList.remove("reaction-suggestion"), e.classList.add("hide-reaction-suggestion"), e.removeAttribute("data-reaction-suggestion-message")
                }
                i(Ls, "clearReactionSuggestion");
                var Ss = u(82453);
                (0, f.on)("navigation:keydown", ".js-commits-list-item", function(e) {
                    !(0, Ss.Zf)(e.detail.originalEvent) || e.target instanceof Element && e.detail.hotkey === "c" && e.target.querySelector(".js-navigation-open").click()
                });
                var cf = u(24473);
                (0, X.q6)(".js-company-name-input", function(e) {
                    const t = e.target,
                        n = t.form,
                        o = n.querySelector(".js-corp-tos-link"),
                        s = n.querySelector(".js-tos-link");
                    s && (s.classList.add("d-none"), s.setAttribute("aria-hidden", "true"), o && (o.classList.remove("d-none"), o.setAttribute("aria-hidden", "false")));
                    const r = n.querySelectorAll(".js-company-name-text");
                    if (r.length !== 0)
                        for (const a of r)
                            if (t.value)
                                if (a.hasAttribute("data-wording")) {
                                    const l = a.getAttribute("data-wording");
                                    a.textContent = ` ${l} ${t.value}`
                                } else a.textContent = t.value;
                    else a.textContent = ""
                }), (0, v.N7)(".js-company-owned:not(:checked)", {
                    constructor: HTMLInputElement,
                    add(e) {
                        const n = e.form.querySelector(".js-company-name-input"),
                            o = document.querySelector(".js-company-name-text"),
                            s = document.querySelector(".js-corp-tos-link"),
                            r = document.querySelector(".js-tos-link");
                        n && (e.getAttribute("data-optional") && n.removeAttribute("required"), (0, Z.Se)(n, "")), r.classList.remove("d-none"), r.setAttribute("aria-hidden", "false"), s.classList.add("d-none"), s.setAttribute("aria-hidden", "true"), o && (o.textContent = "")
                    }
                }), (0, v.N7)(".js-company-owned:checked", {
                    constructor: HTMLInputElement,
                    add(e) {
                        const n = e.form.querySelector(".js-company-name-input");
                        n && (n.setAttribute("required", ""), (0, f.f)(n, "focus"), (0, f.f)(n, "input"))
                    }
                }), (0, v.N7)(".js-company-owned-autoselect", {
                    constructor: HTMLInputElement,
                    add(e) {
                        const t = e;

                        function n() {
                            if (t.checked && t.form) {
                                const o = t.form.querySelector(".js-company-owned");
                                (0, Z.Se)(o, !0)
                            }
                        }
                        i(n, "autoselect"), t.addEventListener("change", n), n()
                    }
                });
                var $n = u(79046),
                    Fn = u(17364);
                let xe = null;
                document.addEventListener("keydown", function(e) {
                    !e.defaultPrevented && e.key === "Escape" && xe && xe.removeAttribute("open")
                }), (0, v.N7)(".js-dropdown-details", {
                    subscribe: e => (0, H.qC)((0, H.RB)(e, "toggle", Fa), (0, H.RB)(e, "toggle", $a))
                });

                function $a({
                    currentTarget: e
                }) {
                    const t = e;
                    if (t.hasAttribute("open")) {
                        const n = t.querySelector("[autofocus]");
                        n && n.focus()
                    } else {
                        const n = t.querySelector("summary");
                        n && n.focus()
                    }
                }
                i($a, "autofocus");

                function Fa({
                    currentTarget: e
                }) {
                    const t = e;
                    t.hasAttribute("open") ? (xe && xe !== t && xe.removeAttribute("open"), xe = t) : t === xe && (xe = null)
                }
                i(Fa, "closeCurrentDetailsDropdown"), (0, v.N7)("[data-deferred-details-content-url]:not([data-details-no-preload-on-hover])", {
                    subscribe: e => {
                        const t = e.querySelector("summary");
                        return (0, H.RB)(t, "mouseenter", Fn.G)
                    }
                }), (0, v.N7)("[data-deferred-details-content-url]", {
                    subscribe: e => (0, H.RB)(e, "toggle", Fn.G)
                }), (0, f.on)("click", "[data-toggle-for]", function(e) {
                    const t = e.currentTarget.getAttribute("data-toggle-for") || "",
                        n = document.getElementById(t);
                    !n || (n.hasAttribute("open") ? n.removeAttribute("open") : n.setAttribute("open", "open"))
                }), (0, Bt.Z)(function({
                    target: e
                }) {
                    if (!e || e.closest("summary")) return;
                    let t = e.parentElement;
                    for (; t;) t = t.closest("details"), t && (t.hasAttribute("open") || t.setAttribute("open", ""), t = t.parentElement)
                }), (0, f.on)("details-dialog-close", "[data-disable-dialog-dismiss]", function(e) {
                    e.preventDefault()
                });
                var Ua = u(88309);
                (0, v.N7)("details.select-menu details-menu include-fragment", function(e) {
                    const t = e.closest("details");
                    !t || (e.addEventListener("loadstart", function() {
                        t.classList.add("is-loading"), t.classList.remove("has-error")
                    }), e.addEventListener("error", function() {
                        t.classList.add("has-error")
                    }), e.addEventListener("loadend", function() {
                        t.classList.remove("is-loading");
                        const n = t.querySelector(".js-filterable-field");
                        n && (0, f.f)(n, "filterable:change")
                    }))
                }), (0, v.N7)("details details-menu .js-filterable-field", {
                    constructor: HTMLInputElement,
                    add(e) {
                        const t = e.closest("details");
                        t.addEventListener("toggle", function() {
                            t.hasAttribute("open") || (e.value = "", (0, f.f)(e, "filterable:change"))
                        })
                    }
                }), (0, v.N7)("details-menu[role=menu] [role=menu]", e => {
                    const t = e.closest("details-menu[role]");
                    t && t !== e && t.removeAttribute("role")
                }), (0, v.N7)("details details-menu remote-input input", {
                    constructor: HTMLInputElement,
                    add(e) {
                        const t = e.closest("details");
                        t.addEventListener("toggle", function() {
                            t.hasAttribute("open") || (e.value = "")
                        })
                    }
                }), (0, v.N7)("form details-menu", e => {
                    const t = e.closest("form");
                    t.addEventListener("reset", () => {
                        setTimeout(() => Wa(t), 0)
                    })
                });

                function Wa(e) {
                    const t = e.querySelectorAll("details-menu [role=menuitemradio] input[type=radio]:checked");
                    for (const n of t)(0, f.f)(n, "change")
                }
                i(Wa, "resetMenus"), (0, X.w4)("keypress", "details-menu .js-filterable-field, details-menu filter-input input", e => {
                    if (e.key === "Enter") {
                        const o = e.currentTarget.closest("details-menu").querySelector('[role^="menuitem"]:not([hidden])');
                        o instanceof HTMLElement && o.click(), e.preventDefault()
                    }
                }), (0, f.on)("details-menu-selected", "details-menu", e => {
                    const n = e.currentTarget.querySelector(".js-filterable-field");
                    n instanceof HTMLInputElement && n.value && n.focus()
                }, {
                    capture: !0
                }), (0, f.on)("details-menu-selected", "[data-menu-input]", e => {
                    if (!(e.target instanceof Element)) return;
                    const t = e.target.getAttribute("data-menu-input"),
                        n = document.getElementById(t);
                    (n instanceof HTMLInputElement || n instanceof HTMLTextAreaElement) && (n.value = e.detail.relatedTarget.value)
                }, {
                    capture: !0
                }), (0, v.N7)("details-menu remote-input", {
                    constructor: Ua.Z,
                    initialize(e) {
                        const t = document.getElementById(e.getAttribute("aria-owns") || "");
                        if (!t) return;
                        let n = null;
                        e.addEventListener("load", () => {
                            document.activeElement && t.contains(document.activeElement) && document.activeElement.id ? n = document.activeElement.id : n = null
                        }), e.addEventListener("loadend", () => {
                            if (n) {
                                const o = t.querySelector(`#${n}`) || t.querySelector('[role^="menu"]');
                                o instanceof HTMLElement ? o.focus() : e.input && e.input.focus()
                            }
                        })
                    }
                }), (0, f.on)("details-menu-selected", "details-menu[data-menu-max-options]", e => {
                    const t = +e.currentTarget.getAttribute("data-menu-max-options"),
                        n = e.currentTarget.querySelectorAll('[role="menuitemcheckbox"][aria-checked="true"]'),
                        o = t === n.length;
                    e.currentTarget.querySelector("[data-menu-max-options-warning]").hidden = !o;
                    for (const s of e.currentTarget.querySelectorAll('[role="menuitemcheckbox"] input')) s.disabled = o && !s.checked
                }, {
                    capture: !0
                }), (0, v.N7)("details > details-menu", {
                    subscribe(e) {
                        const t = e.closest("details");
                        return (0, H.RB)(t, "toggle", za)
                    }
                });
                async function za({
                    currentTarget: e
                }) {
                    const t = e,
                        n = t.hasAttribute("open");
                    (0, f.f)(t, n ? "menu:activate" : "menu:deactivate"), await (0, Ce.gJ)(), (0, f.f)(t, n ? "menu:activated" : "menu:deactivated")
                }
                i(za, "fireMenuToggleEvent"), (0, v.N7)("details > details-menu[preload]:not([src])", {
                    subscribe(e) {
                        return (0, H.RB)(e.parentElement, "mouseover", function(t) {
                            const o = t.currentTarget.querySelector("include-fragment[src]");
                            o == null || o.load()
                        })
                    }
                });
                const Un = new WeakMap,
                    js = ["input[type=submit][data-disable-with]", "button[data-disable-with]"].join(", ");

                function Va(e) {
                    return e instanceof HTMLInputElement ? e.value || "Submit" : e.innerHTML || ""
                }
                i(Va, "getButtonText");

                function Ts(e, t) {
                    e instanceof HTMLInputElement ? e.value = t : e.innerHTML = t
                }
                i(Ts, "disable_with_setButtonText"), (0, f.on)("submit", "form", function(e) {
                    for (const t of e.currentTarget.querySelectorAll(js)) {
                        Un.set(t, Va(t));
                        const n = t.getAttribute("data-disable-with");
                        n && Ts(t, n), t.disabled = !0
                    }
                }, {
                    capture: !0
                });

                function As(e) {
                    for (const t of e.querySelectorAll(js)) {
                        const n = Un.get(t);
                        n != null && (Ts(t, n), (!t.hasAttribute("data-disable-invalid") || e.checkValidity()) && (t.disabled = !1), Un.delete(t))
                    }
                }
                i(As, "revert"), (0, f.on)("deprecatedAjaxComplete", "form", function({
                    currentTarget: e,
                    target: t
                }) {
                    e === t && As(e)
                }), (0, K.uT)(As), (0, v.N7)(".js-document-dropzone", {
                    constructor: HTMLElement,
                    add(e) {
                        document.body.addEventListener("dragstart", Ms), document.body.addEventListener("dragend", qs), document.body.addEventListener("dragenter", Wt), document.body.addEventListener("dragover", Wt), document.body.addEventListener("dragleave", ks), e.addEventListener("drop", xs)
                    },
                    remove(e) {
                        document.body.removeEventListener("dragstart", Ms), document.body.removeEventListener("dragend", qs), document.body.removeEventListener("dragenter", Wt), document.body.removeEventListener("dragover", Wt), document.body.removeEventListener("dragleave", ks), e.removeEventListener("drop", xs)
                    }
                });

                function Cs(e) {
                    return Array.from(e.types).indexOf("Files") >= 0
                }
                i(Cs, "hasFile");
                let Wn = null;

                function Wt(e) {
                    if (zn) return;
                    const t = e.currentTarget;
                    Wn && window.clearTimeout(Wn), Wn = window.setTimeout(() => t.classList.remove("dragover"), 200);
                    const n = e.dataTransfer;
                    !n || !Cs(n) || (n.dropEffect = "copy", t.classList.add("dragover"), e.stopPropagation(), e.preventDefault())
                }
                i(Wt, "onDragenter");

                function ks(e) {
                    e.target instanceof Element && e.target.classList.contains("js-document-dropzone") && e.currentTarget.classList.remove("dragover")
                }
                i(ks, "onBodyDragleave");

                function xs(e) {
                    const t = e.currentTarget;
                    t.classList.remove("dragover"), document.body.classList.remove("dragover");
                    const n = e.dataTransfer;
                    !n || !Cs(n) || ((0, f.f)(t, "document:drop", {
                        transfer: n
                    }), e.stopPropagation(), e.preventDefault())
                }
                i(xs, "onDrop");
                let zn = !1;

                function Ms() {
                    zn = !0
                }
                i(Ms, "onDragstart");

                function qs() {
                    zn = !1
                }
                i(qs, "onDragend");
                async function Ps(e, t) {
                    const o = new TextEncoder().encode(t),
                        {
                            seal: s
                        } = await Promise.all([u.e(9833), u.e(7178)]).then(u.bind(u, 86556));
                    return s(o, e)
                }
                i(Ps, "encrypt");

                function Rs(e) {
                    const t = atob(e).split("").map(n => n.charCodeAt(0));
                    return Uint8Array.from(t)
                }
                i(Rs, "decode");

                function Is(e) {
                    let t = "";
                    for (const n of e) t += String.fromCharCode(n);
                    return btoa(t)
                }
                i(Is, "encode"), (0, f.on)("submit", "form.js-encrypt-submit", async function(e) {
                    const t = e.currentTarget;
                    if (e.defaultPrevented || !t.checkValidity()) return;
                    const n = t.elements.namedItem("secret_value");
                    if (n.disabled = !0, !n.value) return;
                    e.preventDefault();
                    const o = Rs(t.getAttribute("data-public-key"));
                    t.elements.namedItem("encrypted_value").value = Is(await Ps(o, n.value)), t.submit()
                }), (0, f.on)("submit", "form.js-encrypt-bulk-submit", Ns(!0)), (0, f.on)("submit", "form.js-encrypt-bulk-submit-enable-empty", Ns(!1));

                function Ns(e) {
                    return async function(t) {
                        const n = t.currentTarget;
                        if (t.defaultPrevented || !n.checkValidity()) return;
                        const o = Rs(n.getAttribute("data-public-key"));
                        t.preventDefault();
                        for (const s of n.elements) {
                            const r = s;
                            if (r.id.endsWith("secret")) {
                                if (r.disabled = !0, r.required && !r.value) {
                                    const c = `${r.name} is invalid!`,
                                        l = document.querySelector("template.js-flash-template");
                                    l.after(new we.R(l, {
                                        className: "flash-error",
                                        message: c
                                    }));
                                    return
                                }
                                const a = `${r.name}_encrypted_value`;
                                if (!r.value) {
                                    n.elements.namedItem(a).disabled = e;
                                    continue
                                }
                                n.elements.namedItem(a).value = Is(await Ps(o, r.value))
                            }
                        }
                        n.submit()
                    }
                }
                i(Ns, "submitBulk");
                let zt;

                function Vt(e, t) {
                    const n = document.querySelector('.js-site-favicon[type="image/svg+xml"]'),
                        o = document.querySelector('.js-site-favicon[type="image/png"]');
                    t || (t = "light");
                    const s = t === "light" ? "" : "-dark";
                    if (n && o)
                        if (zt == null && (zt = n.href), e) {
                            e = e.substr(0, e.lastIndexOf(".")), e = `${e}${s}.svg`, n.href = e;
                            const r = n.href.substr(0, n.href.lastIndexOf("."));
                            o.href = `${r}.png`
                        } else {
                            const r = n.href.indexOf("-dark.svg"),
                                a = n.href.substr(0, r !== -1 ? r : n.href.lastIndexOf("."));
                            n.href = `${a}${s}.svg`, o.href = `${a}${s}.png`
                        }
                }
                i(Vt, "updateFavicon");

                function Kt() {
                    return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches
                }
                i(Kt, "prefersDarkColorScheme");

                function Ka() {
                    zt != null && Vt(zt, Kt() ? "dark" : "light")
                }
                i(Ka, "resetIcon"), (0, v.N7)("[data-favicon-override]", {
                    add(e) {
                        const t = e.getAttribute("data-favicon-override");
                        setTimeout(() => Vt(t, Kt() ? "dark" : "light"))
                    },
                    remove() {
                        Ka()
                    }
                }), Kt() && Vt(void 0, "dark"), window.matchMedia("(prefers-color-scheme: dark)").addListener(() => {
                    Vt(void 0, Kt() ? "dark" : "light")
                }), (0, v.N7)(".js-feature-preview-indicator-container", e => {
                    Xa(e)
                });
                async function Xa(e) {
                    const t = e.getAttribute("data-feature-preview-indicator-src"),
                        n = await Ga(t),
                        o = e.querySelectorAll(".js-feature-preview-indicator");
                    for (const s of o) s.hidden = !n
                }
                i(Xa, "fetchFeaturePreviewIndicator");
                async function Ga(e) {
                    try {
                        const t = await fetch(e, {
                            headers: {
                                Accept: "application/json"
                            }
                        });
                        return t.ok ? (await t.json()).show_indicator : !1
                    } catch {
                        return !1
                    }
                }
                i(Ga, "fetchIndicator");
                var Me = u(51374),
                    ie = u(52660);
                (0, f.on)("click", "[data-feature-preview-trigger-url]", async e => {
                    const t = e.currentTarget,
                        n = t.getAttribute("data-feature-preview-trigger-url"),
                        o = await (0, Me.W)({
                            content: (0, ie.a)(document, n),
                            dialogClass: "feature-preview-dialog"
                        }),
                        s = t.getAttribute("data-feature-preview-close-details"),
                        r = t.getAttribute("data-feature-preview-close-hmac");
                    o.addEventListener("dialog:remove", () => {
                        (0, Le.b)({
                            hydroEventPayload: s,
                            hydroEventHmac: r
                        }, !0)
                    });
                    const a = document.querySelectorAll(".js-feature-preview-indicator");
                    for (const c of a) c.hidden = !0
                }), (0, K.AC)(".js-feature-preview-unenroll", async (e, t) => {
                    await t.text();
                    const n = e.querySelector(".js-feature-preview-slug").value;
                    (0, f.f)(e, `feature-preview-unenroll:${n}`)
                }), (0, K.AC)(".js-feature-preview-enroll", async (e, t) => {
                    await t.text();
                    const n = e.querySelector(".js-feature-preview-slug").value;
                    (0, f.f)(e, `feature-preview-enroll:${n}`)
                });
                class Ds {
                    constructor(t, n) {
                        this.attachment = t, this.policy = n
                    }
                    async process(t) {
                        var n, o, s, r;
                        const a = window.performance.now(),
                            c = new Headers(this.policy.header || {}),
                            l = new XMLHttpRequest;
                        l.open("POST", this.policy.upload_url, !0);
                        for (const [T, k] of c) l.setRequestHeader(T, k);
                        l.onloadstart = () => {
                            t.attachmentUploadDidStart(this.attachment, this.policy)
                        }, l.upload.onprogress = T => {
                            if (T.lengthComputable) {
                                const k = Math.round(T.loaded / T.total * 100);
                                t.attachmentUploadDidProgress(this.attachment, k)
                            }
                        }, await Za(l, Ja(this.attachment, this.policy)), l.status === 204 ? (Hs(this.policy), t.attachmentUploadDidComplete(this.attachment, this.policy, {})) : l.status === 201 ? (Hs(this.policy), t.attachmentUploadDidComplete(this.attachment, this.policy, JSON.parse(l.responseText))) : t.attachmentUploadDidError(this.attachment, {
                            status: l.status,
                            body: l.responseText
                        });
                        const j = {
                            duration: window.performance.now() - a,
                            size: (o = (n = this.attachment) == null ? void 0 : n.file) == null ? void 0 : o.size,
                            fileType: (r = (s = this.attachment) == null ? void 0 : s.file) == null ? void 0 : r.type,
                            success: l.status === 204 || l.status === 201
                        };
                        (0, Le.b)({
                            uploadTiming: j
                        }, !0)
                    }
                }
                i(Ds, "AttachmentUpload");

                function Za(e, t) {
                    return new Promise((n, o) => {
                        e.onload = () => n(e), e.onerror = o, e.send(t)
                    })
                }
                i(Za, "send");

                function Ja(e, t) {
                    const n = new FormData;
                    t.same_origin && n.append("authenticity_token", t.upload_authenticity_token);
                    for (const o in t.form) n.append(o, t.form[o]);
                    return n.append("file", e.file), n
                }
                i(Ja, "uploadForm");

                function Hs(e) {
                    const t = typeof e.asset_upload_url == "string" ? e.asset_upload_url : null,
                        n = typeof e.asset_upload_authenticity_token == "string" ? e.asset_upload_authenticity_token : null;
                    if (!(t && n)) return;
                    const o = new FormData;
                    o.append("authenticity_token", n), fetch(t, {
                        method: "PUT",
                        body: o,
                        credentials: "same-origin",
                        headers: {
                            Accept: "application/json",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    })
                }
                i(Hs, "markComplete");
                async function Ya(e, t) {
                    const n = nc(e, t);
                    for (const o of e.attachments) {
                        const s = await Qa(e, o, t);
                        if (!s) return;
                        try {
                            await new Ds(o, s).process(n)
                        } catch {
                            (0, f.f)(t, "upload:error", {
                                batch: e,
                                attachment: o
                            }), qe(t, "is-failed");
                            return
                        }
                    }
                }
                i(Ya, "upload");
                async function Qa(e, t, n) {
                    const o = ec(t, n),
                        s = [];
                    (0, f.f)(n, "upload:setup", {
                        batch: e,
                        attachment: t,
                        form: o,
                        preprocess: s
                    });
                    try {
                        await Promise.all(s);
                        const r = await fetch(tc(o, n));
                        if (r.ok) return await r.json();
                        (0, f.f)(n, "upload:invalid", {
                            batch: e,
                            attachment: t
                        });
                        const a = await r.text(),
                            c = r.status,
                            {
                                state: l,
                                messaging: d
                            } = Os({
                                status: c,
                                body: a
                            }, t.file);
                        qe(n, l, d)
                    } catch {
                        (0, f.f)(n, "upload:invalid", {
                            batch: e,
                            attachment: t
                        }), qe(n, "is-failed")
                    }
                    return null
                }
                i(Qa, "validate");

                function ec(e, t) {
                    const n = t.querySelector(".js-data-upload-policy-url-csrf").value,
                        o = t.getAttribute("data-upload-repository-id"),
                        s = t.getAttribute("data-subject-type"),
                        r = t.getAttribute("data-subject-param"),
                        a = e.file,
                        c = new FormData;
                    return c.append("name", a.name), c.append("size", String(a.size)), c.append("content_type", a.type), c.append("authenticity_token", n), s && c.append("subject_type", s), r && c.append("subject", r), o && c.append("repository_id", o), e.directory && c.append("directory", e.directory), c
                }
                i(ec, "policyForm");

                function tc(e, t) {
                    return new Request(t.getAttribute("data-upload-policy-url"), {
                        method: "POST",
                        body: e,
                        credentials: "same-origin",
                        headers: {
                            Accept: "application/json",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    })
                }
                i(tc, "policyRequest");

                function nc(e, t) {
                    return {
                        attachmentUploadDidStart(n, o) {
                            n.saving(0), qe(t, "is-uploading"), (0, f.f)(t, "upload:start", {
                                batch: e,
                                attachment: n,
                                policy: o
                            })
                        },
                        attachmentUploadDidProgress(n, o) {
                            n.saving(o), (0, f.f)(t, "upload:progress", {
                                batch: e,
                                attachment: n
                            })
                        },
                        attachmentUploadDidComplete(n, o, s) {
                            n.saved(oc(s, o)), (0, f.f)(t, "upload:complete", {
                                batch: e,
                                attachment: n
                            }), e.isFinished() && qe(t, "is-default")
                        },
                        attachmentUploadDidError(n, o) {
                            (0, f.f)(t, "upload:error", {
                                batch: e,
                                attachment: n
                            });
                            const {
                                state: s
                            } = Os(o);
                            qe(t, s)
                        }
                    }
                }
                i(nc, "createDelegate");

                function oc(e, t) {
                    const n = (e.id == null ? null : String(e.id)) || (t.asset.id == null ? null : String(t.asset.id)),
                        o = (typeof e.href == "string" ? e.href : null) || (typeof t.asset.href == "string" ? t.asset.href : null);
                    return {
                        id: n,
                        href: o,
                        name: t.asset.name
                    }
                }
                i(oc, "savedAttributes");

                function Os(e, t) {
                    if (e.status === 400) return {
                        state: "is-bad-file"
                    };
                    if (e.status !== 422) return {
                        state: "is-failed"
                    };
                    const n = JSON.parse(e.body);
                    if (!n || !n.errors) return {
                        state: "is-failed"
                    };
                    for (const o of n.errors) switch (o.field) {
                        case "size":
                            {
                                const s = t ? t.size : null;
                                return s != null && s === 0 ? {
                                    state: "is-empty"
                                } : {
                                    state: "is-too-big",
                                    messaging: {
                                        message: sc(o.message),
                                        target: ".js-upload-too-big"
                                    }
                                }
                            }
                        case "file_count":
                            return {
                                state: "is-too-many"
                            };
                        case "width":
                        case "height":
                            return {
                                state: "is-bad-dimensions"
                            };
                        case "name":
                            return o.code === "already_exists" ? {
                                state: "is-duplicate-filename"
                            } : {
                                state: "is-bad-file"
                            };
                        case "content_type":
                            return {
                                state: "is-bad-file"
                            };
                        case "uploader_id":
                            return {
                                state: "is-bad-permissions"
                            };
                        case "repository_id":
                            return {
                                state: "is-repository-required"
                            };
                        case "format":
                            return {
                                state: "is-bad-format"
                            }
                    }
                    return {
                        state: "is-failed"
                    }
                }
                i(Os, "policyErrorState");
                const sc = i(e => e.startsWith("size") ? e.substring(5) : e, "trimSizeErrorMessage"),
                    rc = ["is-default", "is-uploading", "is-bad-file", "is-duplicate-filename", "is-too-big", "is-too-many", "is-hidden-file", "is-failed", "is-bad-dimensions", "is-empty", "is-bad-permissions", "is-repository-required", "is-bad-format"];

                function qe(e, t, n) {
                    if (n) {
                        const {
                            message: o,
                            target: s
                        } = n, r = e.querySelector(s);
                        r && (r.innerHTML = o)
                    }
                    e.classList.remove(...rc), e.classList.add(t)
                }
                i(qe, "resetState");
                class Bs {
                    constructor(t) {
                        this.attachments = t, this.size = this.attachments.length, this.total = Vn(this.attachments, n => n.file.size)
                    }
                    percent() {
                        const t = i(o => o.file.size * o.percent / 100, "bytes"),
                            n = Vn(this.attachments, t);
                        return Math.round(n / this.total * 100)
                    }
                    uploaded() {
                        const t = i(n => n.isSaved() ? 1 : 0, "value");
                        return Vn(this.attachments, t)
                    }
                    isFinished() {
                        return this.attachments.every(t => t.isSaved())
                    }
                }
                i(Bs, "Batch");

                function Vn(e, t) {
                    return e.reduce((n, o) => n + t(o), 0)
                }
                i(Vn, "sum"), (0, v.N7)("file-attachment[hover]", {
                    add(e) {
                        e.classList.add("dragover")
                    },
                    remove(e) {
                        e.classList.remove("dragover")
                    }
                }), (0, f.on)("file-attachment-accept", "file-attachment", function(e) {
                    const {
                        attachments: t
                    } = e.detail;
                    t.length === 0 && (qe(e.currentTarget, "is-hidden-file"), e.preventDefault())
                }), (0, f.on)("file-attachment-accepted", "file-attachment", function(e) {
                    const t = e.currentTarget.querySelector(".drag-and-drop");
                    if (t && t.hidden) return;
                    const {
                        attachments: n
                    } = e.detail;
                    Ya(new Bs(n), e.currentTarget)
                });
                let _s = 0;
                (0, v.N7)("file-attachment", {
                    add(e) {
                        _s++ === 0 && (document.addEventListener("drop", Fs), document.addEventListener("dragover", Us));
                        const t = e.closest("form");
                        t && t.addEventListener("reset", Ws)
                    },
                    remove(e) {
                        --_s === 0 && (document.removeEventListener("drop", Fs), document.removeEventListener("dragover", Us));
                        const t = e.closest("form");
                        t && t.removeEventListener("reset", Ws)
                    }
                });

                function $s(e) {
                    return Array.from(e.types).indexOf("Files") >= 0
                }
                i($s, "file_attachment_hasFile");

                function Fs(e) {
                    const t = e.dataTransfer;
                    t && $s(t) && e.preventDefault()
                }
                i(Fs, "onDocumentDrop");

                function Us(e) {
                    const t = e.dataTransfer;
                    t && $s(t) && e.preventDefault()
                }
                i(Us, "onDocumentDragover");

                function Ws({
                    currentTarget: e
                }) {
                    const t = e.querySelector("file-attachment");
                    qe(t, "is-default")
                }
                i(Ws, "onFormReset");
                var ic = u(13002);
                (0, f.on)("filter-input-updated", "filter-input", e => {
                    const t = e.currentTarget.input;
                    if (!(document.activeElement && document.activeElement === t)) return;
                    const {
                        count: n,
                        total: o
                    } = e.detail;
                    (0, ue.x)(`Found ${n} out of ${o} ${o===1?"item":"items"}`)
                }), (0, f.on)("toggle", "details", e => {
                    setTimeout(() => ac(e.target), 0)
                }, {
                    capture: !0
                }), (0, f.on)("tab-container-changed", "tab-container", e => {
                    if (!(e.target instanceof HTMLElement)) return;
                    const {
                        relatedTarget: t
                    } = e.detail, n = e.target.querySelector("filter-input");
                    n instanceof ic.Z && n.setAttribute("aria-owns", t.id)
                }, {
                    capture: !0
                });

                function ac(e) {
                    const t = e.querySelector("filter-input");
                    t && !e.hasAttribute("open") && t.reset()
                }
                i(ac, "resetFilter");
                var lf = u(64909);
                const zs = navigator.userAgent.match(/Firefox\/(\d+)/);
                zs && Number(zs[1]) < 76 && ((0, v.N7)('details-menu label[tabindex][role^="menuitem"]', e => {
                    const t = e.querySelector("input");
                    if (!t) return;
                    const n = e.classList.contains("select-menu-item"),
                        o = t.classList.contains("d-none"),
                        s = n || o || t.hidden;
                    n && t.classList.add("d-block"), o && t.classList.remove("d-none"), s && (t.classList.add("sr-only"), t.hidden = !1), e.removeAttribute("tabindex")
                }), (0, f.on)("focus", 'details-menu label[role="menuitemradio"] input, details-menu label[role="menuitemcheckbox"] input', e => {
                    const t = e.currentTarget.closest("label");
                    t.classList.contains("select-menu-item") && t.classList.add("navigation-focus"), t.classList.contains("SelectMenu-item") && t.classList.add("hx_menuitem--focus"), t.classList.contains("dropdown-item") && t.classList.add("hx_menuitem--focus"), e.currentTarget.addEventListener("blur", () => {
                        t.classList.contains("select-menu-item") && t.classList.remove("navigation-focus"), t.classList.contains("SelectMenu-item") && t.classList.remove("hx_menuitem--focus"), t.classList.contains("dropdown-item") && t.classList.remove("hx_menuitem--focus")
                    }, {
                        once: !0
                    })
                }, {
                    capture: !0
                }), (0, X.w4)("keydown", 'details-menu label[role="menuitemradio"] input, details-menu label[role="menuitemcheckbox"] input', async function(e) {
                    if (Vs(e)) e.currentTarget instanceof Element && cc(e.currentTarget);
                    else if (e.key === "Enter") {
                        const t = e.currentTarget;
                        e.preventDefault(), await (0, Ce.gJ)(), t instanceof HTMLInputElement && t.click()
                    }
                }), (0, f.on)("blur", 'details-menu label input[role="menuitemradio"], details-menu label input[role="menuitemcheckbox"]', e => {
                    Ks(e.currentTarget)
                }, {
                    capture: !0
                }), (0, X.w4)("keyup", 'details-menu label[role="menuitemradio"] input, details-menu label[role="menuitemcheckbox"] input', e => {
                    !Vs(e) || e.currentTarget instanceof Element && Ks(e.currentTarget)
                }));

                function Vs(e) {
                    return e.key === "ArrowDown" || e.key === "ArrowUp"
                }
                i(Vs, "isArrowKeys");

                function cc(e) {
                    const t = e.closest("label");
                    t.hasAttribute("data-role") || t.setAttribute("data-role", t.getAttribute("role")), e.setAttribute("role", t.getAttribute("data-role")), t.removeAttribute("role")
                }
                i(cc, "switchRoleToInputForNavigation");

                function Ks(e) {
                    const t = e.closest("label");
                    t.hasAttribute("data-role") || t.setAttribute("data-role", t.getAttribute("role")), t.setAttribute("role", t.getAttribute("data-role")), e.removeAttribute("role")
                }
                i(Ks, "switchRoleBackToOriginalState");
                var Kn = u(37713);

                function Xs() {
                    document.head.querySelector("meta[name=skip-scroll-target-into-view]") || (0, Kn.lA)(document) && (0, Kn.kc)(document)
                }
                i(Xs, "scrollTargetIntoViewIfNeeded"), (0, Bt.Z)(Xs), (0, f.on)("click", 'a[href^="#"]', function(e) {
                    const {
                        currentTarget: t
                    } = e;
                    t instanceof HTMLAnchorElement && setTimeout(Xs, 0)
                });
                var uf = u(11997);
                const lc = ["flash-notice", "flash-error", "flash-message", "flash-warn"];

                function uc(e) {
                    for (const {
                            key: t,
                            value: n
                        } of lc.flatMap(dt.$1)) {
                        (0, dt.kT)(t);
                        let o;
                        try {
                            o = atob(decodeURIComponent(n))
                        } catch {
                            continue
                        }
                        e.after(new we.R(e, {
                            className: t,
                            message: o
                        }))
                    }
                }
                i(uc, "displayFlash"), (0, v.N7)("template.js-flash-template", {
                    constructor: HTMLTemplateElement,
                    add(e) {
                        uc(e)
                    }
                });
                const Xn = new WeakMap;
                document.addEventListener("focus", function(e) {
                    const t = e.target;
                    t instanceof Element && !Xn.get(t) && ((0, f.f)(t, "focusin:delay"), Xn.set(t, !0))
                }, {
                    capture: !0
                }), document.addEventListener("blur", function(e) {
                    setTimeout(function() {
                        const t = e.target;
                        t instanceof Element && t !== document.activeElement && ((0, f.f)(t, "focusout:delay"), Xn.delete(t))
                    }, 200)
                }, {
                    capture: !0
                }), (0, K.AC)(".js-form-toggle-target", async function(e, t) {
                    try {
                        await t.text()
                    } catch {
                        return
                    }
                    const n = e.closest(".js-form-toggle-container");
                    n.querySelector(".js-form-toggle-target[hidden]").hidden = !1, e.hidden = !0
                });

                function dc(e) {
                    e instanceof CustomEvent && (0, ue.x)(`${e.detail} results found.`)
                }
                i(dc, "noticeHandler"), (0, v.N7)("fuzzy-list", {
                    constructor: E,
                    subscribe: e => (0, H.RB)(e, "fuzzy-list-sorted", dc)
                }), (0, f.on)("click", ".email-hidden-toggle", function(e) {
                    const t = e.currentTarget.nextElementSibling;
                    t instanceof HTMLElement && (t.style.display = "", t.classList.toggle("expanded"), e.preventDefault())
                });
                var df = u(42474);
                (0, v.N7)(".js-hook-url-field", {
                    constructor: HTMLInputElement,
                    add(e) {
                        function t() {
                            const n = e.form;
                            if (!n) return;
                            let o;
                            try {
                                o = new URL(e.value)
                            } catch {}
                            const s = n.querySelector(".js-invalid-url-notice");
                            s instanceof HTMLElement && (s.hidden = !!(e.value === "" || o && /^https?:/.test(o.protocol)));
                            const r = n.querySelector(".js-insecure-url-notice");
                            r instanceof HTMLElement && o && e.value && (r.hidden = /^https:$/.test(o.protocol));
                            const a = n.querySelector(".js-ssl-hook-fields");
                            a instanceof HTMLElement && (a.hidden = !(o && o.protocol === "https:"))
                        }
                        i(t, "checkUrl"), (0, zo.oq)(e, t), t()
                    }
                });

                function Gs(e) {
                    const t = document.querySelectorAll(".js-hook-event-checkbox");
                    for (const n of t) n.checked = n.matches(e)
                }
                i(Gs, "chooseEvents"), (0, f.on)("change", ".js-hook-event-choice", function(e) {
                    const t = e.currentTarget,
                        n = t.checked && t.value === "custom",
                        o = t.closest(".js-hook-events-field");
                    if (o && o.classList.toggle("is-custom", n), t.checked)
                        if (n) {
                            const s = document.querySelector(".js-hook-wildcard-event");
                            s.checked = !1
                        } else t.value === "push" ? Gs('[value="push"]') : t.value === "all" && Gs(".js-hook-wildcard-event")
                }), (0, f.on)("click", ".js-hook-deliveries-pagination-button", async function(e) {
                    const t = e.currentTarget;
                    t.disabled = !0;
                    const n = t.parentElement,
                        o = t.getAttribute("data-url");
                    n.before(await (0, ie.a)(document, o)), n.remove()
                }), (0, K.AC)(".js-redeliver-hook-form", async function(e, t) {
                    let n;
                    try {
                        n = await t.html()
                    } catch {
                        e.classList.add("failed");
                        return
                    }
                    document.querySelector(".js-hook-deliveries-container").replaceWith(n.html)
                });
                var ff = u(25522),
                    Gn = u(81654);
                let ne = document.querySelector(".js-hovercard-content");
                (0, v.N7)(".js-hovercard-content", e => {
                    ne = e
                });
                const fc = (0, Se.Z)(ie.a);
                let Pe, Xt = null,
                    Zn, Jn = 0;
                const Yn = 12,
                    Qn = 24,
                    Zs = Qn - 7,
                    Js = 16,
                    mc = 100,
                    hc = 250;

                function _e(e) {
                    return "Popover-message--" + e
                }
                i(_e, "contentClass");

                function pc(e) {
                    setTimeout(() => {
                        if (document.body && document.body.contains(e)) {
                            const t = e.querySelector("[data-hovercard-tracking]");
                            if (t) {
                                const o = t.getAttribute("data-hovercard-tracking");
                                o && (0, Ge.q)("user-hovercard-load", JSON.parse(o))
                            }
                            const n = e.querySelector("[data-hydro-view]");
                            n instanceof HTMLElement && (0, Gn.Fk)(n)
                        }
                    }, 500)
                }
                i(pc, "trackLoad");

                function mt() {
                    ne instanceof HTMLElement && (ne.style.display = "none", ne.children[0].innerHTML = "", Xt = null, Pe = null)
                }
                i(mt, "hideCard");

                function gc(e) {
                    const t = e.getClientRects();
                    let n = t[0] || e.getBoundingClientRect() || {
                        top: 0,
                        left: 0,
                        height: 0,
                        width: 0
                    };
                    if (t.length > 0) {
                        for (const o of t)
                            if (o.left < Jn && o.right > Jn) {
                                n = o;
                                break
                            }
                    }
                    return n
                }
                i(gc, "selectRectNearestMouse");

                function bc(e) {
                    const {
                        width: t,
                        height: n
                    } = ne.getBoundingClientRect(), {
                        left: o,
                        top: s,
                        height: r,
                        width: a
                    } = gc(e), c = s > n;
                    if (e.classList.contains("js-hovercard-left")) {
                        const d = o - t - Yn,
                            p = s + r / 2;
                        return {
                            containerTop: c ? p - n + Zs + Js / 2 : p - Zs - Js / 2,
                            containerLeft: d,
                            contentClassSuffix: c ? "right-bottom" : "right-top"
                        }
                    } else {
                        const d = window.innerWidth - o > t,
                            p = o + a / 2,
                            j = d ? p - Qn : p - t + Qn;
                        return {
                            containerTop: c ? s - n - Yn : s + r + Yn,
                            containerLeft: j,
                            contentClassSuffix: c ? d ? "bottom-left" : "bottom-right" : d ? "top-left" : "top-right"
                        }
                    }
                }
                i(bc, "calculatePositions");

                function yc(e, t) {
                    if (!(ne instanceof HTMLElement)) return;
                    ne.style.visibility = "hidden", ne.style.display = "block", t.classList.remove(_e("bottom-left"), _e("bottom-right"), _e("right-top"), _e("right-bottom"), _e("top-left"), _e("top-right"));
                    const {
                        containerTop: n,
                        containerLeft: o,
                        contentClassSuffix: s
                    } = bc(e);
                    t.classList.add(_e(s)), ne.style.top = `${n+window.pageYOffset}px`, ne.style.left = `${o+window.pageXOffset}px`, Cc(e, ne), ne.style.visibility = ""
                }
                i(yc, "positionCard");

                function vc(e, t) {
                    if (!(ne instanceof HTMLElement)) return;
                    const n = ne.children[0];
                    n.innerHTML = "";
                    const o = document.createElement("div");
                    for (const s of e.children) o.appendChild(s.cloneNode(!0));
                    n.appendChild(o), yc(t, n), pc(o), ne.style.display = "block"
                }
                i(vc, "showCard");

                function wc(e) {
                    const t = e.closest("[data-hovercard-subject-tag]");
                    if (t) return t.getAttribute("data-hovercard-subject-tag");
                    const n = document.head && document.head.querySelector('meta[name="hovercard-subject-tag"]');
                    return n ? n.getAttribute("content") : null
                }
                i(wc, "determineEnclosingSubject");

                function Ec(e) {
                    const t = e.getAttribute("data-hovercard-url");
                    if (t) {
                        const n = wc(e);
                        if (n) {
                            const o = new URL(t, window.location.origin),
                                s = new URLSearchParams(o.search.slice(1));
                            return s.append("subject", n), s.append("current_path", window.location.pathname + window.location.search), o.search = s.toString(), o.toString()
                        }
                        return t
                    }
                    return ""
                }
                i(Ec, "hovercardUrlFromTarget");

                function Lc(e) {
                    const t = e.getAttribute("data-hovercard-type");
                    return t === "pull_request" || t === "issue" ? !!e.closest("[data-issue-and-pr-hovercards-enabled]") : t === "team" ? !!e.closest("[data-team-hovercards-enabled]") : t === "repository" ? !!e.closest("[data-repository-hovercards-enabled]") : t === "commit" ? !!e.closest("[data-commit-hovercards-enabled]") : t === "project" ? !!e.closest("[data-project-hovercards-enabled]") : t === "discussion" ? !!e.closest("[data-discussion-hovercards-enabled]") : t === "acv_badge" ? !!e.closest("[data-acv-badge-hovercards-enabled]") : t === "sponsors_listing" ? !!e.closest("[data-sponsors-listing-hovercards-enabled]") : !0
                }
                i(Lc, "hovercardsAreEnabledForType");
                async function Sc(e, t) {
                    if ("ontouchstart" in document) return;
                    const o = e.currentTarget;
                    if (e instanceof MouseEvent && (Jn = e.clientX), !(o instanceof Element) || Pe === o || o.closest(".js-hovercard-content") || !Lc(o)) return;
                    mt(), Pe = o, Xt = document.activeElement;
                    const s = Ec(o);
                    let r;
                    try {
                        const a = new Promise(c => window.setTimeout(c, t, 0));
                        r = await fc(document, s), await a
                    } catch (a) {
                        const c = a.response;
                        if (c && c.status === 404) {
                            const l = "Hovercard is unavailable";
                            o.setAttribute("aria-label", l), o.classList.add("tooltipped", "tooltipped-ne")
                        } else if (c && c.status === 410) {
                            const l = await c.clone().json();
                            o.setAttribute("aria-label", l.message), o.classList.add("tooltipped", "tooltipped-ne")
                        }
                        return
                    }
                    o === Pe && (vc(r, o), e instanceof KeyboardEvent && ne instanceof HTMLElement && ne.focus())
                }
                i(Sc, "activateFn");

                function jc(e) {
                    Sc(e, hc)
                }
                i(jc, "activateWithTimeoutFn");

                function eo(e) {
                    if (!!Pe) {
                        if (e instanceof MouseEvent && e.relatedTarget instanceof HTMLElement) {
                            const t = e.relatedTarget;
                            if (t.closest(".js-hovercard-content") || t.closest("[data-hovercard-url]")) return
                        } else e instanceof KeyboardEvent && Xt instanceof HTMLElement && Xt.focus();
                        mt()
                    }
                }
                i(eo, "deactivateFn");

                function Tc(e) {
                    const t = Pe;
                    Zn = window.setTimeout(() => {
                        Pe === t && eo(e)
                    }, mc)
                }
                i(Tc, "deactivateWithTimeoutFn");

                function Ys(e) {
                    if (e instanceof KeyboardEvent) switch (e.key) {
                        case "Escape":
                            eo(e)
                    }
                }
                i(Ys, "keyupFn");

                function Ac() {
                    Zn && clearTimeout(Zn)
                }
                i(Ac, "cancelDeactivation"), ne && ((0, v.N7)("[data-hovercard-url]", {
                    subscribe: e => (0, H.qC)((0, H.RB)(e, "mouseover", jc), (0, H.RB)(e, "mouseleave", Tc), (0, H.RB)(e, "keyup", Ys))
                }), (0, v.N7)("[data-hovercard-url]", {
                    remove(e) {
                        Pe === e && mt()
                    }
                }), (0, v.N7)(".js-hovercard-content", {
                    subscribe: e => (0, H.qC)((0, H.RB)(e, "mouseover", Ac), (0, H.RB)(e, "mouseleave", eo), (0, H.RB)(e, "keyup", Ys))
                }), (0, f.on)("menu:activated", "details", mt), window.addEventListener("statechange", mt));

                function Cc(e, t) {
                    const n = e.getAttribute("data-hovercard-z-index-override");
                    n ? t.style.zIndex = n : t.style.zIndex = "100"
                }
                i(Cc, "setZIndexOverride"), async function() {
                    document.addEventListener("pjax:complete", () => (0, Ge.Y)({
                        pjax: "true"
                    })), await Ee.C, (0, Ge.Y)()
                }(), (0, f.on)("click", "[data-octo-click]", function(e) {
                    const t = e.currentTarget;
                    if (!(t instanceof HTMLElement)) return;
                    const n = t.getAttribute("data-octo-click") || "",
                        o = {};
                    if (t.hasAttribute("data-ga-click")) {
                        const r = t.getAttribute("data-ga-click").split(",");
                        o.category = r[0].trim(), o.action = r[1].trim()
                    }
                    if (t.hasAttribute("data-octo-dimensions")) {
                        const s = t.getAttribute("data-octo-dimensions").split(",");
                        for (const r of s) {
                            const [a, c] = r.split(/:(.+)/);
                            a && (o[a] = c || "")
                        }
                    }(0, Ge.q)(n, o)
                }), (0, f.on)("click", "[data-hydro-click]", function(e) {
                    const t = e.currentTarget,
                        n = t.getAttribute("data-hydro-click") || "",
                        o = t.getAttribute("data-hydro-click-hmac") || "",
                        s = t.getAttribute("data-hydro-client-context") || "";
                    (0, Gn.$S)(n, o, s)
                }), (0, f.on)("click", "[data-optimizely-hydro-click]", function(e) {
                    const t = e.currentTarget,
                        n = t.getAttribute("data-optimizely-hydro-click") || "",
                        o = t.getAttribute("data-optimizely-hydro-click-hmac") || "";
                    (0, Gn.$S)(n, o, "")
                }), (0, K.AC)(".js-immediate-updates", async function(e, t) {
                    let n;
                    try {
                        n = (await t.json()).json.updateContent
                    } catch (o) {
                        o.response.json && (n = o.response.json.updateContent)
                    }
                    if (n)
                        for (const o in n) {
                            const s = n[o],
                                r = document.querySelector(o);
                            r instanceof HTMLElement && (0, Be.Of)(r, s)
                        }
                }), (0, v.N7)("[data-indeterminate]", {
                    constructor: HTMLInputElement,
                    initialize(e) {
                        e.indeterminate = !0
                    }
                });
                var kc = u(75552);

                function xc() {
                    u.e(3754).then(u.bind(u, 23754))
                }
                i(xc, "load"), (0, v.N7)(".js-jump-to-field", {
                    constructor: HTMLInputElement,
                    add(e) {
                        e.addEventListener("focusin", xc, {
                            once: !0
                        }), (0, kc.Nc)(window.location.pathname)
                    }
                });
                var to = u(11793);
                let no = !1;
                async function Qs() {
                    if (no) return;
                    no = !0;
                    const t = {
                            contexts: document.querySelector("meta[name=github-keyboard-shortcuts]").content
                        },
                        n = `/site/keyboard_shortcuts?${new URLSearchParams(t).toString()}`,
                        o = await (0, Me.W)({
                            content: (0, ie.a)(document, n),
                            labelledBy: "keyboard-shortcuts-heading"
                        });
                    o.style.width = "800px", o.addEventListener("dialog:remove", function() {
                        no = !1
                    }, {
                        once: !0
                    })
                }
                i(Qs, "showKeyboardShortcuts"), (0, f.on)("click", ".js-keyboard-shortcuts", Qs), document.addEventListener("keydown", e => {
                    e instanceof KeyboardEvent && (!(0, Ss.Zf)(e) || e.target instanceof Node && (0, Z.sw)(e.target) || (0, to.EL)(e) === "Shift+?" && Qs())
                }), (0, v.N7)(".js-modifier-key", {
                    constructor: HTMLElement,
                    add(e) {
                        if (/Macintosh/.test(navigator.userAgent)) {
                            let t = e.textContent;
                            t && (t = t.replace(/ctrl/, "\u2318"), t = t.replace(/alt/, "\u2325"), e.textContent = t)
                        }
                    }
                }), (0, v.N7)(".js-modifier-label-key", {
                    add(e) {
                        var t;
                        let n = (t = e.textContent) == null ? void 0 : t.replace(/ctrl/i, "Ctrl");
                        !n || (/Macintosh/.test(navigator.userAgent) && (n = n.replace(/ctrl/i, "Cmd"), n = n.replace(/alt/i, "Option")), e.textContent = n)
                    }
                });

                function Gt(e) {
                    const t = e.currentTarget;
                    if (!(t instanceof HTMLInputElement || t instanceof HTMLTextAreaElement)) return;
                    const n = parseInt(t.getAttribute("data-input-max-length") || "", 10),
                        o = parseInt(t.getAttribute("data-warning-length") || "", 10) || 5,
                        r = t.value.replace(/(\r\n|\n|\r)/g, `\r
`);
                    let a = n - r.length;
                    if (a <= 0) {
                        let p = r.substr(0, n);
                        p.endsWith("\r") ? (p = p.substr(0, n - 1), a = 1) : a = 0, t.value = p
                    }
                    const c = t.getAttribute("data-warning-text"),
                        d = t.closest(".js-length-limited-input-container").querySelector(".js-length-limited-input-warning");
                    a <= o ? (d.textContent = c.replace(new RegExp("{{remaining}}", "g"), `${a}`), d.classList.remove("d-none")) : (d.textContent = "", d.classList.add("d-none"))
                }
                i(Gt, "displayLengthWarning"), (0, v.N7)(".js-length-limited-input", {
                    add(e) {
                        e.addEventListener("input", Gt), e.addEventListener("change", Gt)
                    },
                    remove(e) {
                        e.removeEventListener("input", Gt), e.removeEventListener("change", Gt)
                    }
                }), (0, v.N7)("link[rel=prefetch-viewed]", {
                    initialize() {
                        window.requestIdleCallback(() => {
                            fetch(location.href, {
                                method: "HEAD",
                                credentials: "same-origin",
                                headers: {
                                    Purpose: "prefetch-viewed"
                                }
                            })
                        })
                    }
                }), (0, f.on)("click", ".js-member-search-filter", function(e) {
                    e.preventDefault();
                    const t = e.currentTarget.getAttribute("data-filter"),
                        o = e.currentTarget.closest("[data-filter-on]").getAttribute("data-filter-on"),
                        s = document.querySelector(".js-member-filter-field"),
                        r = s.value,
                        a = new RegExp(`${o}:(?:[a-z]|_|((').*(')))+`),
                        c = r.toString().trim().replace(a, "");
                    s.value = `${c} ${t}`.replace(/\s\s/, " ").trim(), s.focus(), (0, f.f)(s, "input")
                }), (0, f.on)("auto-check-success", ".js-new-organization-name", function(e) {
                    const t = e.target,
                        o = t.closest("dd").querySelector(".js-field-hint-name");
                    !o || (o.textContent = t.value)
                }), (0, K.AC)(".js-notice-dismiss", async function(e, t) {
                    await t.text(), e.closest(".js-notice").remove()
                }), (0, f.on)("submit", ".js-notice-dismiss-remote", async function(e) {
                    const t = e.currentTarget;
                    e.preventDefault();
                    let n;
                    try {
                        n = await fetch(t.action, {
                            method: t.method,
                            body: new FormData(t),
                            headers: {
                                Accept: "application/json",
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        })
                    } catch {
                        (0, ct.v)();
                        return
                    }
                    n && !n.ok ? (0, ct.v)() : t.closest(".js-notice").remove()
                });

                function Mc(e) {
                    try {
                        const t = e.getBoundingClientRect();
                        if (t.height === 0 && t.width === 0 || e.style.opacity === "0" || e.style.visibility === "hidden") return !1
                    } catch {}
                    return !0
                }
                i(Mc, "isVisible"), (0, f.on)("click", ".js-github-dev-shortcut", function(e) {
                    e.preventDefault();
                    for (const n of document.querySelectorAll("textarea.js-comment-field"))
                        if (n.value && Mc(n) && !confirm("Are you sure you want to open github.dev?")) return;
                    const t = e.currentTarget;
                    t.pathname = window.location.pathname, t.hash = window.location.hash, window.location.href = t.href
                }), (0, f.on)("click", ".js-github-dev-new-tab-shortcut", function(e) {
                    const t = e.currentTarget;
                    t.pathname = window.location.pathname, t.hash = window.location.hash
                });

                function qc(e, t, n) {
                    const o = new URL("", window.location.origin),
                        s = t.pathname.split("/");
                    o.pathname = s.slice(1, 3).join("/"), o.hash = t.hash, n && (o.search = `?q=${encodeURIComponent(n)}`);
                    const a = new URLSearchParams(t.search).get("q");
                    return a ? o.search = `?q=${encodeURIComponent(a)}` : s.length >= 6 && (s[3] === "blob" || s[3] === "tree") && (o.pathname = t.pathname), o.host = e.host, o.protocol = e.protocol, o.port = e.port, o
                }
                i(qc, "getBlackbirdURL"), (0, f.on)("click", ".js-blackbird-shortcut", function(e) {
                    var t;
                    const n = e.currentTarget,
                        o = qc(n, new URL(window.location.href, window.location.origin), (t = window.getSelection()) == null ? void 0 : t.toString());
                    n.href = o.href
                }), (0, f.on)("click", ".js-permalink-shortcut", function(e) {
                    const t = e.currentTarget;
                    try {
                        (0, lt.lO)(null, "", t.href + window.location.hash)
                    } catch {
                        window.location.href = t.href + window.location.hash
                    }
                    for (const n of document.querySelectorAll(".js-permalink-replaceable-link")) n instanceof HTMLAnchorElement && (n.href = n.getAttribute("data-permalink-href"));
                    e.preventDefault()
                }), (0, K.AC)(".js-permission-menu-form", async function(e, t) {
                    const n = e.querySelector(".js-permission-success"),
                        o = e.querySelector(".js-permission-error");
                    n.hidden = !0, o.hidden = !0, e.classList.add("is-loading");
                    let s;
                    try {
                        s = await t.json()
                    } catch {
                        e.classList.remove("is-loading"), o.hidden = !1;
                        return
                    }
                    e.classList.remove("is-loading"), n.hidden = !1;
                    const r = e.closest(".js-org-repo");
                    if (r) {
                        const a = s.json;
                        r.classList.toggle("with-higher-access", a.members_with_higher_access)
                    }
                }), async function() {
                    await Ee.x;
                    const e = document.querySelector(".js-pjax-loader-bar");
                    if (!e) return;
                    const t = e.firstElementChild;
                    if (!(t instanceof HTMLElement)) return;
                    let n = 0,
                        o = null,
                        s = null;

                    function r() {
                        a(0), e && e.classList.add("is-loading"), o = window.setTimeout(c, 0)
                    }
                    i(r, "initiateLoader");

                    function a(d) {
                        t instanceof HTMLElement && (d === 0 && (s == null && (s = getComputedStyle(t).transition), t.style.transition = "none"), n = d, t.style.width = `${n}%`, d === 0 && (t.clientWidth, t.style.transition = s || ""))
                    }
                    i(a, "setWidth");

                    function c() {
                        n === 0 && (n = 12), a(Math.min(n + 3, 95)), o = window.setTimeout(c, 500)
                    }
                    i(c, "increment");

                    function l() {
                        o && clearTimeout(o), a(100), e && e.classList.remove("is-loading")
                    }
                    i(l, "finishLoader"), document.addEventListener("pjax:start", r), document.addEventListener("pjax:end", l)
                }();
                let oo = null;
                const so = "last_pjax_request",
                    Zt = "pjax_start",
                    ro = "pjax_end";

                function Pc(e) {
                    e instanceof CustomEvent && e.detail && e.detail.url && (window.performance.mark(Zt), oo = e.detail.url)
                }
                i(Pc, "markPjaxStart");
                async function Rc() {
                    if (await (0, Ce.gJ)(), !window.performance.getEntriesByName(Zt).length) return;
                    window.performance.mark(ro), window.performance.measure(so, Zt, ro);
                    const t = window.performance.getEntriesByName(so).pop(),
                        n = t ? t.duration : null;
                    !n || (oo && (0, Le.b)({
                        requestUrl: oo,
                        pjaxDuration: Math.round(n)
                    }), Ic())
                }
                i(Rc, "trackPjaxTiming");

                function Ic() {
                    window.performance.clearMarks(Zt), window.performance.clearMarks(ro), window.performance.clearMeasures(so)
                }
                i(Ic, "clearPjaxMarks"), "getEntriesByName" in window.performance && (document.addEventListener("pjax:start", Pc), document.addEventListener("pjax:end", Rc));
                let io = null;
                const ao = "last_turbo_request",
                    Jt = "turbo_start",
                    co = "turbo_end";

                function Nc(e) {
                    var t;
                    e instanceof CustomEvent && (!((t = e.detail) == null ? void 0 : t.url) || (window.performance.mark(Jt), io = e.detail.url))
                }
                i(Nc, "markTurboStart");
                async function Dc() {
                    if (await (0, Ce.gJ)(), !window.performance.getEntriesByName(Jt).length) return;
                    window.performance.mark(co), window.performance.measure(ao, Jt, co);
                    const t = window.performance.getEntriesByName(ao).pop(),
                        n = t ? t.duration : null;
                    !n || (io && (0, Le.b)({
                        requestUrl: io,
                        turboDuration: Math.round(n)
                    }), Hc())
                }
                i(Dc, "trackTurboTiming");

                function Hc() {
                    window.performance.clearMarks(Jt), window.performance.clearMarks(co), window.performance.clearMeasures(ao)
                }
                i(Hc, "clearTurboMarks"), "getEntriesByName" in window.performance && (document.addEventListener("turbo:before-fetch-request", Nc), document.addEventListener("turbo:render", Dc));
                var hf = u(13728),
                    pf = u(76006);

                function Oc(e, t) {
                    const n = e.split("/", 3).join("/"),
                        o = t.split("/", 3).join("/");
                    return n === o
                }
                i(Oc, "isSameRepo"), (0, f.on)("pjax:click", "#js-repo-pjax-container a[href]", function(e) {
                    const t = e.currentTarget.pathname;
                    Oc(t, location.pathname) || e.preventDefault()
                }), (0, f.on)("pjax:click", ".js-comment-body", function(e) {
                    const t = e.target;
                    t instanceof HTMLAnchorElement && t.pathname.split("/")[3] === "files" && e.preventDefault()
                });
                var gf = u(7143),
                    bf = u(7796),
                    yf = u(15528),
                    ht = u(82762),
                    Re = u(31756);
                (0, f.on)("click", "[data-pjax] a, a[data-pjax]", function(e) {
                    const t = e.currentTarget;
                    if (t instanceof HTMLAnchorElement) {
                        if (t.getAttribute("data-skip-pjax") != null || t.getAttribute("data-remote") != null) return;
                        const n = (0, ht.W)(t);
                        n && Bc(e, {
                            container: n,
                            scrollTo: (0, ht.r)(t)
                        })
                    }
                }), (0, f.on)("change", "select[data-pjax]", function(e) {
                    if ((0, Re.c)("PJAX_DISABLED") || (0, Re.c)("TURBO")) return;
                    const t = e.currentTarget,
                        n = (0, ht.W)(t);
                    n && (0, ut.ZP)({
                        url: t.value,
                        container: n
                    })
                });

                function Bc(e, t) {
                    if ((0, Re.c)("PJAX_DISABLED") || (0, Re.c)("TURBO")) return;
                    const n = e.currentTarget;
                    if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || location.protocol !== n.protocol || location.hostname !== n.hostname || n.href.indexOf("#") > -1 && er(n) === er(location) || e.defaultPrevented) return;
                    const o = {
                            url: n.href,
                            target: n,
                            ...t
                        },
                        s = new CustomEvent("pjax:click", {
                            bubbles: !0,
                            cancelable: !0,
                            detail: {
                                options: o,
                                relatedEvent: e
                            }
                        });
                    n.dispatchEvent(s) && ((0, ut.ZP)(o), e.preventDefault(), n.dispatchEvent(new CustomEvent("pjax:clicked", {
                        bubbles: !0,
                        cancelable: !0,
                        detail: {
                            options: o
                        }
                    })))
                }
                i(Bc, "click");

                function er(e) {
                    return e.href.replace(/#.*/, "")
                }
                i(er, "stripHash"), (0, f.on)("submit", "form[data-pjax]", function(e) {
                    if ((0, Re.c)("PJAX_DISABLED") || (0, Re.c)("TURBO")) return;
                    const t = e.currentTarget,
                        n = (0, ht.W)(t);
                    if (!n) return;
                    const o = (0, ht.r)(t),
                        s = {
                            type: (t.method || "GET").toUpperCase(),
                            url: t.action,
                            target: t,
                            scrollTo: o,
                            container: n
                        };
                    if (s.type === "GET") {
                        if (t.querySelector("input[type=file]")) return;
                        const r = _c(s.url);
                        r.search += (r.search ? "&" : "") + (0, Z.qC)(t), s.url = r.toString()
                    } else s.data = new FormData(t);
                    (0, ut.ZP)(s), e.preventDefault()
                });

                function _c(e) {
                    const t = document.createElement("a");
                    return t.href = e, t
                }
                i(_c, "parseURL"), (0, v.N7)("body.js-print-popup", () => {
                    window.print(), setTimeout(window.close, 1e3)
                }), (0, v.N7)("poll-include-fragment[data-redirect-url]", function(e) {
                    const t = e.getAttribute("data-redirect-url");
                    e.addEventListener("load", function() {
                        window.location.href = t
                    })
                }), (0, v.N7)("poll-include-fragment[data-reload]", function(e) {
                    e.addEventListener("load", function() {
                        window.location.reload()
                    })
                });
                var $c = u(43452),
                    Fc = u(26360);
                const Uc = "$__",
                    tr = document.querySelector("meta[name=js-proxy-site-detection-payload]"),
                    nr = document.querySelector("meta[name=expected-hostname]");
                if (tr instanceof HTMLMetaElement && nr instanceof HTMLMetaElement && (0, $c.Z)(document)) {
                    const e = {
                            url: window.location.href,
                            expectedHostname: nr.content,
                            documentHostname: document.location.hostname,
                            proxyPayload: tr.content
                        },
                        t = new Error,
                        n = {};
                    n[`${Uc}`] = btoa(JSON.stringify(e)), (0, Fc.eK)(t, n)
                }(0, X.w4)("keydown", ".js-quick-submit", function(e) {
                    Wc(e)
                });

                function Wc(e) {
                    const t = e.target;
                    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
                        const n = t.form,
                            o = n.querySelector("input[type=submit], button[type=submit]");
                        if (e.shiftKey) {
                            const s = n.querySelector(".js-quick-submit-alternative");
                            (s instanceof HTMLInputElement || s instanceof HTMLButtonElement) && !s.disabled && (0, Z.Bt)(n, s)
                        } else(o instanceof HTMLInputElement || o instanceof HTMLButtonElement) && o.disabled || (0, Z.Bt)(n);
                        e.preventDefault()
                    }
                }
                i(Wc, "quickSubmit");
                var or = u(55498);
                let Yt;
                (0, v.N7)(".js-comment-quote-reply", function(e) {
                    var t;
                    e.hidden = ((t = e.closest(".js-quote-selection-container")) == null ? void 0 : t.querySelector(".js-inline-comment-form-container textarea, .js-new-comment-form textarea")) == null
                });

                function sr(e) {
                    return e.nodeName === "DIV" && e.classList.contains("highlight")
                }
                i(sr, "isHighlightContainer");

                function zc(e) {
                    return e.nodeName === "IMG" || e.firstChild != null
                }
                i(zc, "hasContent");
                const rr = {
                    PRE(e) {
                        const t = e.parentElement;
                        if (t && sr(t)) {
                            const n = t.className.match(/highlight-source-(\S+)/),
                                o = n ? n[1] : "",
                                s = (e.textContent || "").replace(/\n+$/, "");
                            e.textContent = `\`\`\`${o}
${s}
\`\`\``, e.append(`

`)
                        }
                        return e
                    },
                    A(e) {
                        const t = e.textContent || "";
                        return e.classList.contains("user-mention") || e.classList.contains("team-mention") || e.classList.contains("issue-link") && /^#\d+$/.test(t) ? t : e
                    },
                    IMG(e) {
                        const t = e.getAttribute("alt");
                        return t && e.classList.contains("emoji") ? t : e
                    },
                    DIV(e) {
                        if (e.classList.contains("js-suggested-changes-blob")) e.remove();
                        else if (e.classList.contains("blob-wrapper-embedded")) {
                            const t = e.parentElement,
                                n = t.querySelector("a[href]"),
                                o = document.createElement("p");
                            o.textContent = n.href, t.replaceWith(o)
                        }
                        return e
                    }
                };

                function Vc(e) {
                    const t = document.createNodeIterator(e, NodeFilter.SHOW_ELEMENT, {
                            acceptNode(s) {
                                return s.nodeName in rr && zc(s) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
                            }
                        }),
                        n = [];
                    let o = t.nextNode();
                    for (; o;) o instanceof HTMLElement && n.push(o), o = t.nextNode();
                    n.reverse();
                    for (const s of n) s.replaceWith(rr[s.nodeName](s))
                }
                i(Vc, "insertMarkdownSyntax"), (0, f.on)("click", ".js-comment-quote-reply", function({
                    isTrusted: e,
                    currentTarget: t
                }) {
                    const n = t.closest(".js-comment"),
                        o = n.querySelector(".js-comment-body"),
                        s = n.querySelector(".js-comment-body").cloneNode(!0),
                        r = n.closest(".js-quote-selection-container"),
                        a = o.querySelectorAll("button.js-convert-to-issue-button, span.js-clear");
                    for (const d of a) d.remove();
                    let c = new or.p;
                    if (!e && c.range.collapsed || (r.hasAttribute("data-quote-markdown") && (c = new or.I(r.getAttribute("data-quote-markdown") || "", d => {
                            const p = c.range.startContainer.parentElement,
                                j = p && p.closest("pre");
                            if (j instanceof HTMLElement) {
                                const T = j.parentElement;
                                if (T && sr(T)) {
                                    const k = document.createElement("div");
                                    k.className = T.className, k.appendChild(d), d.appendChild(k)
                                }
                            }
                            Vc(d)
                        })), Yt && o.contains(Yt.anchorNode) ? c.range = Yt.range : c.range.collapsed && c.select(o), c.closest(".js-quote-selection-container") !== r)) return;
                    const l = c.range;
                    r.dispatchEvent(new CustomEvent("quote-selection", {
                        bubbles: !0,
                        detail: c
                    })), c.range = l;
                    for (const d of r.querySelectorAll("textarea"))
                        if ((0, Ot.Z)(d)) {
                            c.insert(d);
                            break
                        }
                    n.querySelector(".js-comment-body").replaceWith(s)
                });
                let lo;
                document.addEventListener("selectionchange", (0, Ze.D)(function() {
                    const e = window.getSelection();
                    let t;
                    try {
                        t = e.getRangeAt(0)
                    } catch {
                        lo = null;
                        return
                    }
                    lo = {
                        anchorNode: e.anchorNode,
                        range: t
                    }
                }, 100)), document.addEventListener("toggle", () => {
                    Yt = lo
                }, {
                    capture: !0
                }), (0, K.AC)(".js-pick-reaction", async function(e, t) {
                    const n = await t.json(),
                        o = e.closest(".js-comment"),
                        s = o.querySelector(".js-reactions-container"),
                        r = o.querySelector(".js-comment-header-reaction-button"),
                        a = (0, ve.r)(document, n.json.reactions_container.trim()),
                        c = (0, ve.r)(document, n.json.comment_header_reaction_button.trim());
                    s.replaceWith(a), r.replaceWith(c)
                });

                function ir(e) {
                    const t = e.target,
                        n = t.getAttribute("data-reaction-label"),
                        s = t.closest(".js-add-reaction-popover").querySelector(".js-reaction-description");
                    s.hasAttribute("data-default-text") || s.setAttribute("data-default-text", s.textContent || ""), s.textContent = n
                }
                i(ir, "showReactionContent");

                function ar(e) {
                    const n = e.target.closest(".js-add-reaction-popover").querySelector(".js-reaction-description"),
                        o = n.getAttribute("data-default-text");
                    o && (n.textContent = o)
                }
                i(ar, "hideReactionContent"), (0, f.on)("toggle", ".js-reaction-popover-container", function(e) {
                    const t = e.currentTarget.hasAttribute("open");
                    for (const n of e.target.querySelectorAll(".js-reaction-option-item")) t ? (n.addEventListener("mouseenter", ir), n.addEventListener("mouseleave", ar)) : (n.removeEventListener("mouseenter", ir), n.removeEventListener("mouseleave", ar))
                }, {
                    capture: !0
                });
                var uo = u(90137),
                    cr = u(85830);

                function Kc(e, t, n) {
                    e.getAttribute("data-type") === "json" && n.headers.set("Accept", "application/json"), (0, f.f)(e, "deprecatedAjaxSend", {
                        request: n
                    }), t.text().catch(s => {
                        if (s.response) return s.response;
                        throw s
                    }).then(s => {
                        s.status < 300 ? (0, f.f)(e, "deprecatedAjaxSuccess") : (0, f.f)(e, "deprecatedAjaxError", {
                            error: s.statusText,
                            status: s.status,
                            text: s.text
                        })
                    }, s => {
                        (0, f.f)(e, "deprecatedAjaxError", {
                            error: s.message,
                            status: 0,
                            text: null
                        })
                    }).then(() => {
                        (0, f.f)(e, "deprecatedAjaxComplete")
                    })
                }
                i(Kc, "submitWithLegacyEvents"), (0, f.on)("click", ["form button:not([type])", "form button[type=submit]", "form input[type=submit]"].join(", "), function(e) {
                    const t = e.currentTarget;
                    t.form && !e.defaultPrevented && (0, uo.j)(t)
                }), (0, K.AC)("form[data-remote]", Kc), (0, f.on)("deprecatedAjaxComplete", "form", function({
                    currentTarget: e
                }) {
                    const t = (0, uo.u)(e);
                    t && t.remove()
                }), (0, K.uT)(e => {
                    const t = (0, uo.u)(e);
                    t && t.remove()
                }), (0, K.rK)(cr.Z);
                var Xc = Object.defineProperty,
                    Gc = Object.getOwnPropertyDescriptor,
                    pt = i((e, t, n, o) => {
                        for (var s = o > 1 ? void 0 : o ? Gc(t, n) : t, r = e.length - 1, a; r >= 0; r--)(a = e[r]) && (s = (o ? a(t, n, s) : a(s)) || s);
                        return o && s && Xc(t, n, s), s
                    }, "remote_pagination_element_decorateClass");
                let Qe = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.loaderWasFocused = !1
                    }
                    connectedCallback() {
                        this.setPaginationUrl(this.list)
                    }
                    get hasNextPage() {
                        return !this.form.hidden
                    }
                    loadNextPage() {
                        !this.hasNextPage || (0, Z.Bt)(this.form)
                    }
                    get disabled() {
                        return this.submitButton.hasAttribute("aria-disabled")
                    }
                    set disabled(e) {
                        e ? this.submitButton.setAttribute("aria-disabled", "true") : this.submitButton.removeAttribute("aria-disabled"), this.submitButton.classList.toggle("disabled", e)
                    }
                    loadstart(e) {
                        e.target.addEventListener("focus", () => {
                            this.loaderWasFocused = !0
                        }, {
                            once: !0
                        }), e.target.addEventListener("include-fragment-replaced", () => {
                            var t;
                            this.setPaginationUrl(this.list), this.loaderWasFocused && ((t = this.focusMarkers.pop()) == null || t.focus()), this.loaderWasFocused = !1
                        }, {
                            once: !0
                        })
                    }
                    async submit(e) {
                        var t;
                        if (e.preventDefault(), this.disabled) return;
                        this.disabled = !0;
                        let n;
                        try {
                            const s = await fetch(this.form.action);
                            if (!s.ok) return;
                            n = await s.text()
                        } catch {
                            return
                        }
                        const o = (0, ve.r)(document, n);
                        this.setPaginationUrl(o), this.list.append(o), (t = this.focusMarkers.pop()) == null || t.focus(), this.disabled = !1, this.dispatchEvent(new CustomEvent("remote-pagination-load"))
                    }
                    setPaginationUrl(e) {
                        const t = e.querySelector("[data-pagination-src]");
                        if (!t) return;
                        const n = t.getAttribute("data-pagination-src");
                        n ? (this.form.action = n, this.form.hidden = !1) : this.form.hidden = !0
                    }
                }, "RemotePaginationElement");
                pt([R.fA], Qe.prototype, "form", 2), pt([R.fA], Qe.prototype, "list", 2), pt([R.GO], Qe.prototype, "focusMarkers", 2), pt([R.fA], Qe.prototype, "submitButton", 2), Qe = pt([R.Ih], Qe), (0, v.N7)(".has-removed-contents", function() {
                    let e;
                    return {
                        add(t) {
                            e = Array.from(t.childNodes);
                            for (const o of e) t.removeChild(o);
                            const n = t.closest("form");
                            n && (0, f.f)(n, "change")
                        },
                        remove(t) {
                            for (const o of e) t.appendChild(o);
                            const n = t.closest("form");
                            n && (0, f.f)(n, "change")
                        }
                    }
                });
                var de = u(36162),
                    Zc = (e => (e.Auto = "auto", e.Light = "light", e.Dark = "dark", e))(Zc || {});

                function Jc() {
                    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
                }
                i(Jc, "getUserSystemColorMode");
                const fo = ".js-render-plaintext";

                function Yc(e) {
                    const t = e.closest(".js-render-needs-enrichment");
                    if (!t) return;
                    t.querySelector(fo) && mo(t, !1)
                }
                i(Yc, "markdownEnrichmentSuccess");

                function Qc(e, t) {
                    mo(e, !1), lr(e, !0), e.classList.add("render-error");
                    const n = e.querySelector(fo);
                    if (!n) return;
                    n.classList.remove("render-plaintext-hidden");
                    const o = n.querySelector("pre");
                    (0, de.sY)(de.dy `${t} ${o}`, n)
                }
                i(Qc, "showMarkdownRenderError");

                function mo(e, t) {
                    const n = e.getElementsByClassName("js-render-enrichment-loader")[0],
                        o = e.getElementsByClassName("render-expand")[0];
                    n && (n.hidden = !t), o && (o.hidden = t)
                }
                i(mo, "setCodeBlockLoaderVisibility");

                function lr(e, t) {
                    const n = e.querySelector(fo);
                    t ? n.classList.remove("render-plaintext-hidden") : n.classList.add("render-plaintext-hidden")
                }
                i(lr, "setRawCodeBlockVisibility");
                class ur {
                    constructor(t) {
                        this.el = t, this.enrichmentTarget = t.getElementsByClassName("js-render-enrichment-target")[0], this.iframeUrl = this.getIframeUrl(), this.identifier = this.el.getAttribute("data-identity"), this.iframeContentType = this.el.getAttribute("data-type"), this.iframeOrigin = new URL(this.iframeUrl, window.location.origin).origin, this.iframeContent = this.el.getAttribute("data-content"), mo(this.el, !0)
                    }
                    enrich() {
                        const t = this.createDialog();
                        (0, de.sY)(t, this.enrichmentTarget), this.setupModal()
                    }
                    getIframeUrl() {
                        const t = this.el.getAttribute("data-src"),
                            n = { ...this.colorMode()
                            },
                            o = Object.entries(n).map(([s, r]) => `${s}=${r}`).join("&");
                        return `${t}?${o}`
                    }
                    colorMode() {
                        var t;
                        let n = (t = document.querySelector("html")) == null ? void 0 : t.getAttribute("data-color-mode");
                        return (n === "auto" || !n) && (n = Jc()), {
                            color_mode: n
                        }
                    }
                    setupModal() {
                        const t = this.generateIframeCode("-fullscreen"),
                            n = this.el.querySelector(".Box-body");
                        this.el.querySelector(".js-full-screen-render").addEventListener("click", () => {
                            (0, de.sY)(t, n)
                        })
                    }
                    createDialog() {
                        const t = this.generateIframeCode();
                        return de.dy ` <div class="d-flex flex-column flex-auto js-render-box">
      <details class="details-reset details-overlay details-overlay-dark">
        <summary class="btn-sm btn position-absolute js-full-screen-render render-expand" aria-haspopup="dialog" hidden>
          <svg
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="currentColor"
            class="octicon"
            style="display:inline-block;vertical-align:text-bottom"
          >
            <path
              fill-rule="evenodd"
              d="M3.72 3.72a.75.75 0 011.06 1.06L2.56 7h10.88l-2.22-2.22a.75.75 0 011.06-1.06l3.5 3.5a.75.75 0 010 1.06l-3.5 3.5a.75.75 0 11-1.06-1.06l2.22-2.22H2.56l2.22 2.22a.75.75 0 11-1.06 1.06l-3.5-3.5a.75.75 0 010-1.06l3.5-3.5z"
            ></path>
          </svg>
        </summary>
        <details-dialog class="Box Box--overlay render-full-screen d-flex flex-column anim-fade-in fast">
          <div>
            <button
              aria-label="Close dialog"
              data-close-dialog=""
              type="button"
              data-view-component="true"
              class="Link--muted btn-link position-absolute render-full-screen-close"
            >
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="currentColor"
                style="display:inline-block;vertical-align:text-bottom"
                class="octicon octicon-x"
              >
                <path
                  fill-rule="evenodd"
                  d="M5.72 5.72a.75.75 0 011.06 0L12 10.94l5.22-5.22a.75.75 0 111.06 1.06L13.06 12l5.22 5.22a.75.75 0 11-1.06 1.06L12 13.06l-5.22 5.22a.75.75 0 01-1.06-1.06L10.94 12 5.72 6.78a.75.75 0 010-1.06z"
                ></path>
              </svg>
            </button>
            <div class="Box-body"></div>
          </div>
        </details-dialog>
      </details>
      ${t}
    </div>`
                    }
                    generateIframeCode(t = "") {
                        const n = this.identifier + t,
                            o = `${this.iframeUrl}#${n}`;
                        return de.dy `
      <div
        class="render-container js-render-target p-0"
        data-identity="${n}"
        data-host="${this.iframeOrigin}"
        data-type="${this.iframeContentType}"
      >
        <iframe
          class="render-viewer"
          src="${o}"
          name="${n}"
          data-content="${this.iframeContent}"
          sandbox="allow-scripts allow-same-origin allow-top-navigation"
        >
        </iframe>
      </div>
    `
                    }
                }
                i(ur, "EnrichableMarkdownRenderer"), (0, v.N7)(".js-render-needs-enrichment", function(e) {
                    const t = e;
                    new ur(t).enrich()
                }), (0, f.on)("preview:toggle:off", ".js-previewable-comment-form", function(e) {
                    const n = e.currentTarget.querySelector(".js-render-needs-enrichment"),
                        o = n == null ? void 0 : n.querySelector(".js-render-enrichment-target");
                    !o || (o.innerHTML = "")
                }), (0, f.on)("preview:rendered", ".js-previewable-comment-form", function(e) {
                    const n = e.currentTarget.querySelector(".js-render-needs-enrichment");
                    n && lr(n, !1)
                });
                const vf = null,
                    Qt = ["is-render-pending", "is-render-ready", "is-render-loading", "is-render-loaded"],
                    el = ["is-render-ready", "is-render-loading", "is-render-loaded", "is-render-failed", "is-render-failed-fatally"],
                    et = new WeakMap;

                function dr(e) {
                    const t = et.get(e);
                    t != null && (t.load = t.hello = null, t.helloTimer && (clearTimeout(t.helloTimer), t.helloTimer = null), t.loadTimer && (clearTimeout(t.loadTimer), t.loadTimer = null))
                }
                i(dr, "resetTiming");

                function gt(e, t = "") {
                    var n;
                    e.classList.remove(...Qt), e.classList.add("is-render-failed");
                    const o = nl(t),
                        s = (n = e.parentElement) == null ? void 0 : n.closest(".js-render-needs-enrichment");
                    s ? Qc(s, o) : tl(e, o), dr(e)
                }
                i(gt, "renderFailed");

                function tl(e, t) {
                    const n = e.querySelector(".render-viewer-error");
                    n && (n.remove(), e.classList.remove("render-container"), (0, de.sY)(t, e))
                }
                i(tl, "fileRenderError");

                function nl(e) {
                    let t = de.dy `<p>Unable to render code block</p>`;
                    if (e !== "") {
                        const n = e.split(`
`);
                        t = de.dy `<p><b>Error rendering embedded code</b></p>
      <p>${n.map(o=>de.dy`${o}<br />`)}</p>`
                    }
                    return de.dy `<div class="flash flash-error">${t}</div>`
                }
                i(nl, "renderError");

                function fr(e, t = !1) {
                    var n;
                    !(0, Ot.Z)(e) || e.classList.contains("is-render-ready") || e.classList.contains("is-render-failed") || e.classList.contains("is-render-failed-fatally") || t && !((n = et.get(e)) == null ? void 0 : n.hello) || gt(e)
                }
                i(fr, "timeoutWatchdog"), (0, v.N7)(".js-render-target", function(e) {
                    var t;
                    const n = e;
                    n.classList.remove(...el), n.style.height = "auto", !((t = et.get(e)) == null ? void 0 : t.load) && (dr(e), !et.get(e) && (et.set(e, {
                        load: Date.now(),
                        hello: null,
                        helloTimer: window.setTimeout(fr, 1e4, e, !0),
                        loadTimer: window.setTimeout(fr, 45e3, e)
                    }), e.classList.add("is-render-automatic", "is-render-requested")))
                });

                function en(e, t) {
                    e && e.postMessage && e.postMessage(JSON.stringify(t), "*")
                }
                i(en, "postAsJson");

                function ol(e) {
                    let t = e.data;
                    if (!t) return;
                    if (typeof t == "string") try {
                        t = JSON.parse(t)
                    } catch {
                        return
                    }
                    if (t.type !== "render" || typeof t.identity != "string") return;
                    const n = t.identity;
                    if (typeof t.body != "string") return;
                    const o = t.body;
                    let s = null;
                    for (const d of document.querySelectorAll(".js-render-target"))
                        if (d.getAttribute("data-identity") === n) {
                            s = d;
                            break
                        }
                    if (!s || e.origin !== s.getAttribute("data-host")) return;
                    const r = t.payload != null ? t.payload : void 0,
                        a = s.querySelector("iframe"),
                        c = a == null ? void 0 : a.contentWindow;

                    function l() {
                        const d = a == null ? void 0 : a.getAttribute("data-content");
                        if (!d) return;
                        const p = {
                            type: "render:cmd",
                            body: {
                                cmd: "code_rendering_service:data:ready",
                                "code_rendering_service:data:ready": {
                                    data: JSON.parse(d).data,
                                    width: s == null ? void 0 : s.getBoundingClientRect().width
                                }
                            }
                        };
                        en(c, p)
                    }
                    switch (i(l, "postData"), o) {
                        case "hello":
                            {
                                const d = et.get(s) || {
                                    untimed: !0
                                };d.hello = Date.now();
                                const p = {
                                        type: "render:cmd",
                                        body: {
                                            cmd: "ack",
                                            ack: !0
                                        }
                                    },
                                    j = {
                                        type: "render:cmd",
                                        body: {
                                            cmd: "branding",
                                            branding: !1
                                        }
                                    };
                                if (!c) return;en(c, p),
                                en(c, j)
                            }
                            break;
                        case "error":
                            r ? gt(s, r.error) : gt(s);
                            break;
                        case "error:fatal":
                            {
                                gt(s),
                                s.classList.add("is-render-failed-fatal");
                                break
                            }
                        case "error:invalid":
                            gt(s), s.classList.add("is-render-failed-invalid");
                            break;
                        case "loading":
                            s.classList.remove(...Qt), s.classList.add("is-render-loading");
                            break;
                        case "loaded":
                            s.classList.remove(...Qt), s.classList.add("is-render-loaded");
                            break;
                        case "ready":
                            Yc(s), s.classList.remove(...Qt), s.classList.add("is-render-ready"), r && typeof r.height == "number" && (s.style.height = `${r.height}px`);
                            break;
                        case "resize":
                            r && typeof r.height == "number" && (s.style.height = `${r.height}px`);
                            break;
                        case "code_rendering_service:container:get_size":
                            en(c, {
                                type: "render:cmd",
                                body: {
                                    cmd: "code_rendering_service:container:size",
                                    "code_rendering_service:container:size": {
                                        width: s == null ? void 0 : s.getBoundingClientRect().width
                                    }
                                }
                            });
                            break;
                        case "code_rendering_service:markdown:get_data":
                            if (!c) return;
                            l();
                            break;
                        default:
                            break
                    }
                }
                i(ol, "handleMessage"), window.addEventListener("message", ol), (0, K.AC)("form[data-replace-remote-form]", async function(e, t) {
                    e.classList.remove("is-error"), e.classList.add("is-loading");
                    try {
                        let n = e;
                        const o = await t.html(),
                            s = e.closest("[data-replace-remote-form-target]");
                        if (s) {
                            const r = s.getAttribute("data-replace-remote-form-target");
                            n = r ? document.getElementById(r) : s
                        }
                        n.replaceWith(o.html)
                    } catch {
                        e.classList.remove("is-loading"), e.classList.add("is-error")
                    }
                }), PerformanceObserver && (PerformanceObserver.supportedEntryTypes || []).includes("longtask") && new PerformanceObserver(function(t) {
                    const n = t.getEntries().map(({
                        name: o,
                        duration: s
                    }) => ({
                        name: o,
                        duration: s,
                        url: window.location.href
                    }));
                    (0, Le.b)({
                        longTasks: n
                    })
                }).observe({
                    entryTypes: ["longtask"]
                });
                const mr = new WeakMap;

                function sl(e) {
                    return e.closest("markdown-toolbar").field
                }
                i(sl, "getTextarea"), (0, f.on)("click", ".js-markdown-link-button", async function({
                    currentTarget: e
                }) {
                    const n = document.querySelector(".js-markdown-link-dialog").content.cloneNode(!0);
                    if (!(n instanceof DocumentFragment)) return;
                    const o = await (0, Me.W)({
                        content: n,
                        labelledBy: "box-title"
                    });
                    e instanceof HTMLElement && mr.set(o, sl(e).selectionEnd)
                }), (0, f.on)("click", ".js-markdown-link-insert", ({
                    currentTarget: e
                }) => {
                    const t = e.closest("details-dialog"),
                        n = document.querySelector(`#${e.getAttribute("data-for-textarea")}`),
                        o = mr.get(t) || 0,
                        s = t.querySelector("#js-dialog-link-href").value,
                        a = `[${t.querySelector("#js-dialog-link-text").value}](${s}) `,
                        c = n.value.slice(0, o),
                        l = n.value.slice(o);
                    n.value = c + a + l, n.focus(), n.selectionStart = n.selectionEnd = o + a.length
                });
                var wf = u(23651);
                (0, f.on)("details-menu-select", ".js-saved-reply-menu", function(e) {
                    if (!(e.target instanceof Element)) return;
                    const t = e.detail.relatedTarget.querySelector(".js-saved-reply-body");
                    if (!t) return;
                    const n = (t.textContent || "").trim(),
                        s = e.target.closest(".js-previewable-comment-form").querySelector("textarea.js-comment-field");
                    (0, Ye.Om)(s, n), setTimeout(() => s.focus(), 0)
                }, {
                    capture: !0
                }), (0, X.w4)("keydown", ".js-saved-reply-shortcut-comment-field", function(e) {
                    (0, to.EL)(e) === "Control+." && (e.target.closest(".js-previewable-comment-form").querySelector(".js-saved-reply-container").setAttribute("open", ""), e.preventDefault())
                }), (0, X.w4)("keydown", ".js-saved-reply-filter-input", function(e) {
                    if (/^Control\+[1-9]$/.test((0, to.EL)(e))) {
                        const n = e.target.closest(".js-saved-reply-container").querySelectorAll('[role="menuitem"]'),
                            o = Number(e.key),
                            s = n[o - 1];
                        s instanceof HTMLElement && (s.click(), e.preventDefault())
                    } else if (e.key === "Enter") {
                        const n = e.target.closest(".js-saved-reply-container").querySelectorAll('[role="menuitem"]');
                        n.length > 0 && n[0] instanceof HTMLButtonElement && n[0].click(), e.preventDefault()
                    }
                });

                function rl(e, t) {
                    return e.querySelector(`#LC${t}`)
                }
                i(rl, "scanning_queryLineElement");

                function il(e, t) {
                    const n = Go(e, o => rl(t, o));
                    if (n) {
                        const o = document.createElement("span"),
                            s = ["text-bold", "hx_keyword-hl", "rounded-2", "d-inline-block"];
                        o.classList.add(...s), es(n, o)
                    }
                }
                i(il, "highlightColumns");

                function al(e) {
                    const t = parseInt(e.getAttribute("data-start-line")),
                        n = parseInt(e.getAttribute("data-end-line")),
                        o = parseInt(e.getAttribute("data-start-column")),
                        s = parseInt(e.getAttribute("data-end-column"));
                    return t !== n || t === n && o === s ? null : {
                        start: {
                            line: t,
                            column: o
                        },
                        end: {
                            line: n,
                            column: s !== 0 ? s : null
                        }
                    }
                }
                i(al, "parseColumnHighlightRange"), (0, v.N7)(".js-highlight-code-snippet-columns", function(e) {
                    const t = al(e);
                    t !== null && il(t, e)
                }), (0, f.on)("click", ".js-segmented-nav-button", function(e) {
                    e.preventDefault();
                    const t = e.currentTarget,
                        n = t.getAttribute("data-selected-tab"),
                        o = t.closest(".js-segmented-nav"),
                        s = o.parentElement;
                    for (const r of o.querySelectorAll(".js-segmented-nav-button")) r.classList.remove("selected");
                    t.classList.add("selected");
                    for (const r of s.querySelectorAll(".js-selected-nav-tab")) r.parentElement === s && r.classList.remove("active");
                    document.querySelector(`.${n}`).classList.add("active")
                });
                var fe = u(407);

                function me(e) {
                    const t = e || window.location,
                        n = document.head && document.head.querySelector("meta[name=session-resume-id]");
                    return n instanceof HTMLMetaElement && n.content || t.pathname
                }
                i(me, "getPageID");
                const cl = (0, Ze.D)(function() {
                    (0, fe.e6)(me())
                }, 50);

                function ll() {
                    var e, t;
                    return (t = (e = document.querySelector("html")) == null ? void 0 : e.hasAttribute("data-turbo-preview")) != null ? t : !1
                }
                i(ll, "isTurboRenderingCachePreview"), window.addEventListener("submit", fe.iO, {
                    capture: !0
                }), window.addEventListener("pageshow", function() {
                    (0, fe.e6)(me())
                }), window.addEventListener("pjax:end", function() {
                    (0, fe.e6)(me())
                }), (0, v.N7)(".js-session-resumable", function() {
                    ll() || cl()
                }), window.addEventListener("pagehide", function() {
                    (0, fe.Xm)(me(), {
                        selector: ".js-session-resumable"
                    })
                }), window.addEventListener("pjax:beforeReplace", function(e) {
                    const t = e.detail.previousState,
                        n = t ? t.url : null;
                    if (n)(0, fe.Xm)(me(new URL(n, window.location.origin)), {
                        selector: ".js-session-resumable"
                    });
                    else {
                        const o = new Error("pjax:beforeReplace event.detail.previousState.url is undefined");
                        setTimeout(function() {
                            throw o
                        })
                    }
                }), window.addEventListener("turbo:before-visit", function() {
                    (0, fe.Xm)(me(), {
                        selector: ".js-session-resumable"
                    })
                }), window.addEventListener("turbo:load", function() {
                    (0, fe.e6)(me())
                });
                var Ef = u(74675),
                    tn = u(46836);
                const ho = ["notification_referrer_id", "notifications_before", "notifications_after", "notifications_query"],
                    nn = "notification_shelf";

                function ul(e, t = null) {
                    return e.has("notification_referrer_id") ? (fl(e, t), ml(e)) : null
                }
                i(ul, "storeAndStripShelfParams");

                function dl(e = null) {
                    const t = hr(e);
                    if (!t) return (0, tn.cl)(nn), null;
                    try {
                        const n = (0, tn.rV)(nn);
                        if (!n) return null;
                        const o = JSON.parse(n);
                        if (!o || !o.pathname) throw new Error("Must have a pathname");
                        if (o.pathname !== t) throw new Error("Stored pathname does not match current pathname.");
                        const s = {};
                        for (const r of ho) s[r] = o[r];
                        return s
                    } catch {
                        return (0, tn.cl)(nn), null
                    }
                }
                i(dl, "getStoredShelfParamsForCurrentPage");

                function fl(e, t) {
                    const n = hr(t);
                    if (!n) return;
                    const o = {
                        pathname: n
                    };
                    for (const s of ho) {
                        const r = e.get(s);
                        r && (o[s] = r)
                    }(0, tn.LS)(nn, JSON.stringify(o))
                }
                i(fl, "storeShelfParams");

                function ml(e) {
                    for (const t of ho) e.delete(t);
                    return e
                }
                i(ml, "deleteShelfParams");

                function hr(e) {
                    e = e || window.location.pathname;
                    const t = /^(\/[^/]+\/[^/]+\/pull\/[^/]+)/,
                        n = e.match(t);
                    return n ? n[0] : null
                }
                i(hr, "getCurrentPullRequestPathname");
                var hl = u(75509);
                async function pl() {
                    return (0, K.AC)(".js-notification-shelf .js-notification-action form", async function(e, t) {
                        if (e.hasAttribute("data-redirect-to-inbox-on-submit")) {
                            await pr(t);
                            const o = document.querySelector(".js-notifications-back-to-inbox");
                            o && o.click();
                            return
                        }(0, hl.a)(e, e), await pr(t)
                    })
                }
                i(pl, "remoteShelfActionForm");

                function gl() {
                    const e = new URLSearchParams(window.location.search),
                        t = ul(e);
                    if (t) {
                        const n = new URL(window.location.href, window.location.origin);
                        return n.search = t.toString(), n.toString()
                    }
                }
                i(gl, "urlWithoutNotificationParameters");

                function bl(e) {
                    if (!(e instanceof Io.Z)) return;
                    const t = dl();
                    if (!t) return;
                    const n = e.getAttribute("data-base-src");
                    if (!n) return;
                    const o = new URL(n, window.location.origin),
                        s = new URLSearchParams(o.search);
                    for (const [r, a] of Object.entries(t)) typeof a == "string" && s.set(r, a);
                    o.search = s.toString(), e.setAttribute("src", o.toString())
                }
                i(bl, "loadShelfFromStoredParams");
                async function pr(e) {
                    try {
                        await e.text()
                    } catch {}
                }
                i(pr, "performRequest"), pl();

                function yl() {
                    const e = gl();
                    e && (0, lt.lO)(null, "", e)
                }
                i(yl, "removeNotificationParams"), yl(), (0, v.N7)(".js-notification-shelf-include-fragment", bl), (0, f.on)("submit", ".js-mark-notification-form", async function(e) {
                    const t = e.currentTarget;
                    e.preventDefault();
                    try {
                        await fetch(t.action, {
                            method: t.method,
                            body: new FormData(t),
                            headers: {
                                Accept: "application/json",
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        })
                    } catch {}
                });
                async function vl() {
                    await Ee.C;
                    const e = document.querySelector(".js-mark-notification-form");
                    e instanceof HTMLFormElement && (0, Z.Bt)(e)
                }
                i(vl, "markNotificationAsRead"), vl();

                function wl(e) {
                    return !!e.closest(".js-jump-to-field")
                }
                i(wl, "isJumpToAvailable");

                function po(e, t) {
                    if (wl(e)) return;
                    const n = document.querySelector(".js-site-search-form");
                    document.querySelector(".js-site-search").classList.toggle("scoped-search", t);
                    let o, s;
                    t ? (o = n.getAttribute("data-scoped-search-url"), s = e.getAttribute("data-scoped-placeholder")) : (o = n.getAttribute("data-unscoped-search-url"), s = e.getAttribute("data-unscoped-placeholder")), n.setAttribute("action", o), e.setAttribute("placeholder", s)
                }
                i(po, "toggleSearchScope"), (0, X.w4)("keyup", ".js-site-search-field", function(e) {
                    const t = e.target,
                        n = t.value.length === 0;
                    n && e.key === "Backspace" && t.classList.contains("is-clearable") && po(t, !1), n && e.key === "Escape" && po(t, !0), t.classList.toggle("is-clearable", n)
                }), (0, X.ZG)(".js-site-search-focus", function(e) {
                    const t = e.closest(".js-chromeless-input-container");
                    t.classList.add("focus");

                    function n() {
                        t.classList.remove("focus"), e.value.length === 0 && e.classList.contains("js-site-search-field") && po(e, !0), e.removeEventListener("blur", n)
                    }
                    i(n, "blurHandler"), e.addEventListener("blur", n)
                }), (0, f.on)("submit", ".js-site-search-form", function(e) {
                    if (!(e.target instanceof Element)) return;
                    const t = e.target.querySelector(".js-site-search-type-field");
                    t.value = new URLSearchParams(window.location.search).get("type") || ""
                });
                var El = u(54430);
                (0, v.N7)("textarea.js-size-to-fit", {
                    constructor: HTMLTextAreaElement,
                    subscribe: El.Z
                });
                var Lf = u(53488);
                const Ll = 1e3,
                    gr = new WeakMap,
                    br = document.querySelector("#snippet-clipboard-copy-button");
                async function Sl(e, t) {
                    const n = e.getAttribute("data-snippet-clipboard-copy-content");
                    if (n === null || (e.removeAttribute("data-snippet-clipboard-copy-content"), !(br instanceof HTMLTemplateElement))) return;
                    const s = br.content.cloneNode(!0).children[0];
                    if (!(s instanceof HTMLElement)) return;
                    const r = s.children[0];
                    if (!(r instanceof HTMLElement)) return;
                    r.setAttribute("value", n), document.addEventListener("selectionchange", () => {
                        const c = document.getSelection();
                        if (c && e.contains(c.anchorNode)) {
                            const l = c == null ? void 0 : c.toString();
                            r.style.display = l.trim() === "" ? "inherit" : "none"
                        }
                    }, {
                        signal: t
                    });
                    const a = e.querySelector("pre");
                    if (a !== null) {
                        let c;
                        a.addEventListener("scroll", () => {
                            c && clearTimeout(c), r.style.display = "none", c = setTimeout(() => {
                                r.style.display = "inherit"
                            }, Ll)
                        }, {
                            signal: t
                        })
                    }
                    e.appendChild(s)
                }
                i(Sl, "insertSnippetClipboardCopyButton"), (0, v.N7)("[data-snippet-clipboard-copy-content]", {
                    constructor: HTMLElement,
                    add(e) {
                        if (e.parentElement && e.parentElement.classList.contains("js-no-snippet-clipboard-copy")) return;
                        const t = new AbortController;
                        gr.set(e, t), Sl(e, t.signal)
                    }
                }), (0, v.N7)(".snippet-clipboard-content clipboard-copy", {
                    constructor: HTMLElement,
                    remove(e) {
                        const t = gr.get(e);
                        t && t.abort()
                    }
                });

                function yr(e, t, n) {
                    vr(e, t), n && e.classList.toggle("on");
                    const o = Array.from(e.querySelectorAll(".js-social-updatable"), Be.x0);
                    return Promise.all(o)
                }
                i(yr, "handleSocialResponse"), (0, K.AC)(".js-social-form", async function(e, t) {
                    var n, o;
                    let s;
                    const r = e.closest(".js-social-container"),
                        a = e.classList.contains("js-deferred-toggler-target");
                    try {
                        s = await t.json(), r && await yr(r, s.json.count, a)
                    } catch (c) {
                        if (((n = c.response) == null ? void 0 : n.status) === 409 && c.response.json.confirmationDialog) {
                            const l = c.response.json.confirmationDialog,
                                d = document.querySelector(l.templateSelector),
                                p = (o = e.querySelector(".js-confirm-csrf-token")) == null ? void 0 : o.value;
                            if (d instanceof HTMLTemplateElement && p) {
                                const j = new we.R(d, {
                                        confirmUrl: e.action,
                                        confirmCsrfToken: p,
                                        ...l.inputs || {}
                                    }),
                                    T = await (0, Me.W)({
                                        content: j
                                    });
                                T.addEventListener("social-confirmation-form:success", async k => {
                                    k instanceof CustomEvent && r && await yr(r, k.detail.count, a)
                                }), T.addEventListener("social-confirmation-form:error", () => {
                                    (0, ct.v)()
                                })
                            }
                        } else r && !a && r.classList.toggle("on"), (0, ct.v)()
                    }
                }), (0, K.AC)(".js-social-confirmation-form", async function(e, t) {
                    try {
                        const n = await t.json();
                        (0, f.f)(e, "social-confirmation-form:success", n.json)
                    } catch {
                        (0, f.f)(e, "social-confirmation-form:error")
                    }
                });

                function vr(e, t) {
                    for (const n of e.querySelectorAll(".js-social-count")) {
                        n.textContent = t;
                        const o = n.getAttribute("data-singular-suffix"),
                            s = n.getAttribute("data-plural-suffix"),
                            r = t === "1" ? o : s;
                        r && n.setAttribute("aria-label", `${t} ${r}`)
                    }
                }
                i(vr, "updateSocialCounts");
                var $e = u(21461);
                class wr extends $e.a2 {
                    constructor(t, n, o, s) {
                        super(t, () => this.getUrlFromRefreshUrl(), o, s);
                        this.refreshUrl = n
                    }
                    getUrlFromRefreshUrl() {
                        return jl(this.refreshUrl)
                    }
                }
                i(wr, "AliveSession");
                async function jl(e) {
                    const t = await Tl(e);
                    return t && t.url && t.token ? Al(t.url, t.token) : null
                }
                i(jl, "fetchRefreshUrl");
                async function Tl(e) {
                    const t = await fetch(e, {
                        headers: {
                            Accept: "application/json"
                        }
                    });
                    if (t.ok) return t.json();
                    if (t.status === 404) return null;
                    throw new Error("fetch error")
                }
                i(Tl, "fetchJSON");
                async function Al(e, t) {
                    const n = await fetch(e, {
                        method: "POST",
                        mode: "same-origin",
                        headers: {
                            "Scoped-CSRF-Token": t
                        }
                    });
                    if (n.ok) return n.text();
                    throw new Error("fetch error")
                }
                i(Al, "post");
                const on = [],
                    Cl = 3e4,
                    kl = 0;
                let sn = document.hidden,
                    rn;

                function xl(e) {
                    return e(sn), on.push(e), new H.w0(() => {
                        const t = on.indexOf(e);
                        t !== -1 && on.splice(t, 1)
                    })
                }
                i(xl, "addIdleStateListener"), document.addEventListener("visibilitychange", () => {
                    const e = document.hidden;
                    rn !== void 0 && clearTimeout(rn), rn = setTimeout(() => {
                        if (e !== sn) {
                            sn = e, rn = void 0;
                            for (const n of on) n(sn)
                        }
                    }, e ? Cl : kl)
                });
                var Ml = u(60785);

                function ql() {
                    return "SharedWorker" in window && (0, Ml.Z)("localStorage").getItem("bypassSharedWorker") !== "true"
                }
                i(ql, "isSharedWorkerSupported");

                function Pl() {
                    var e, t;
                    return (t = (e = document.head.querySelector("link[rel=shared-web-socket-src]")) == null ? void 0 : e.href) != null ? t : null
                }
                i(Pl, "workerSrc");

                function Rl() {
                    var e, t;
                    return (t = (e = document.head.querySelector("link[rel=shared-web-socket]")) == null ? void 0 : e.href) != null ? t : null
                }
                i(Rl, "socketUrl");

                function Il() {
                    var e, t;
                    return (t = (e = document.head.querySelector("link[rel=shared-web-socket]")) == null ? void 0 : e.getAttribute("data-refresh-url")) != null ? t : null
                }
                i(Il, "socketRefreshUrl");

                function Nl() {
                    var e, t;
                    return (t = (e = document.head.querySelector("link[rel=shared-web-socket]")) == null ? void 0 : e.getAttribute("data-session-id")) != null ? t : null
                }
                i(Nl, "sessionIdentifier");

                function Dl(e) {
                    return Er(e).map(t => ({
                        subscriber: e,
                        topic: t
                    }))
                }
                i(Dl, "subscriptions");

                function Er(e) {
                    return (e.getAttribute("data-channel") || "").trim().split(/\s+/).map($e.Zf.parse).filter(Hl)
                }
                i(Er, "channels");

                function Hl(e) {
                    return e != null
                }
                i(Hl, "isPresent");

                function Lr(e, {
                    channel: t,
                    type: n,
                    data: o
                }) {
                    for (const s of e) s.dispatchEvent(new CustomEvent(`socket:${n}`, {
                        bubbles: !1,
                        cancelable: !1,
                        detail: {
                            name: t,
                            data: o
                        }
                    }))
                }
                i(Lr, "notify");
                class Sr {
                    constructor(t, n, o, s, r) {
                        this.subscriptions = new $e.vk, this.presenceMetadata = new $e.ah, this.notifyPresenceDebouncedByChannel = new Map, this.notify = r, this.worker = new SharedWorker(t, `github-socket-worker-v2-${s}`), this.worker.port.onmessage = ({
                            data: a
                        }) => this.receive(a), this.worker.port.postMessage({
                            connect: {
                                url: n,
                                refreshUrl: o
                            }
                        })
                    }
                    subscribe(t) {
                        const n = this.subscriptions.add(...t);
                        n.length && this.worker.port.postMessage({
                            subscribe: n
                        });
                        const o = new Set(n.map(r => r.name)),
                            s = t.reduce((r, a) => {
                                const c = a.topic.name;
                                return (0, $e.A)(c) && !o.has(c) && r.add(c), r
                            }, new Set);
                        s.size && this.worker.port.postMessage({
                            requestPresence: Array.from(s)
                        })
                    }
                    unsubscribeAll(...t) {
                        const n = this.subscriptions.drain(...t);
                        n.length && this.worker.port.postMessage({
                            unsubscribe: n
                        });
                        const o = this.presenceMetadata.removeSubscribers(t);
                        this.sendPresenceMetadataUpdate(o)
                    }
                    updatePresenceMetadata(t) {
                        const n = new Set;
                        for (const o of t) this.presenceMetadata.setMetadata(o), n.add(o.channelName);
                        this.sendPresenceMetadataUpdate(n)
                    }
                    sendPresenceMetadataUpdate(t) {
                        if (!t.size) return;
                        const n = [];
                        for (const o of t) n.push({
                            channelName: o,
                            metadata: this.presenceMetadata.getChannelMetadata(o)
                        });
                        this.worker.port.postMessage({
                            updatePresenceMetadata: n
                        })
                    }
                    online() {
                        this.worker.port.postMessage({
                            online: !0
                        })
                    }
                    offline() {
                        this.worker.port.postMessage({
                            online: !1
                        })
                    }
                    hangup() {
                        this.worker.port.postMessage({
                            hangup: !0
                        })
                    }
                    receive(t) {
                        const {
                            channel: n
                        } = t;
                        if (t.type === "presence") {
                            let o = this.notifyPresenceDebouncedByChannel.get(n);
                            o || (o = (0, Ze.D)((s, r) => {
                                this.notify(s, r), this.notifyPresenceDebouncedByChannel.delete(n)
                            }, 100), this.notifyPresenceDebouncedByChannel.set(n, o)), o(this.subscriptions.subscribers(n), t);
                            return
                        }
                        this.notify(this.subscriptions.subscribers(n), t)
                    }
                }
                i(Sr, "AliveSessionProxy");

                function Ol() {
                    const e = Pl();
                    if (!e) return;
                    const t = Rl();
                    if (!t) return;
                    const n = Il();
                    if (!n) return;
                    const o = Nl();
                    if (!o) return;
                    const r = i(() => {
                            if (ql()) try {
                                return new Sr(e, t, n, o, Lr)
                            } catch {}
                            return new wr(t, n, !1, Lr)
                        }, "createSession")(),
                        a = (0, Ce.g)(d => r.subscribe(d.flat())),
                        c = (0, Ce.g)(d => r.unsubscribeAll(...d)),
                        l = (0, Ce.g)(d => r.updatePresenceMetadata(d));
                    (0, v.N7)(".js-socket-channel[data-channel]", {
                        subscribe: d => {
                            const p = Dl(d),
                                j = p.map(k => k.topic.name).filter(k => (0, $e.A)(k));
                            let T = {
                                unsubscribe() {}
                            };
                            if (j.length) {
                                let k, B;
                                const $ = i(() => {
                                    const G = [];
                                    k && G.push(k), B !== void 0 && G.push({
                                        [$e.ZE]: B ? 1 : 0
                                    });
                                    for (const ee of j) l({
                                        subscriber: d,
                                        channelName: ee,
                                        metadata: G
                                    })
                                }, "queueMetadataOrIdleChange");
                                T = (0, H.qC)((0, H.RB)(d, "socket:set-presence-metadata", G => {
                                    const {
                                        detail: ee
                                    } = G;
                                    k = ee, $()
                                }), xl(G => {
                                    !(0, Re.c)("PRESENCE_IDLE") || (B = G, $())
                                }))
                            }
                            return a(p), T
                        },
                        remove: d => c(d)
                    }), window.addEventListener("online", () => r.online()), window.addEventListener("offline", () => r.offline()), window.addEventListener("pagehide", () => {
                        "hangup" in r && r.hangup()
                    })
                }
                i(Ol, "connect"), (async () => (await Ee.x, Ol()))();
                const jr = new Map;

                function Bl(e, t) {
                    const n = [];
                    for (const o of e) {
                        const s = jr.get(o.name);
                        s && s.arrived > t && n.push(s)
                    }
                    return n
                }
                i(Bl, "stale");

                function _l(e, t) {
                    for (const n of e.querySelectorAll(".js-socket-channel[data-channel]"))
                        for (const o of Bl(Er(n), t)) n.dispatchEvent(new CustomEvent("socket:message", {
                            bubbles: !1,
                            cancelable: !1,
                            detail: {
                                name: o.name,
                                data: o.data,
                                cached: !0
                            }
                        }))
                }
                i(_l, "dispatch");

                function $l(e) {
                    const {
                        name: t,
                        data: n,
                        cached: o
                    } = e.detail;
                    if (o) return;
                    const s = {
                        name: t,
                        data: { ...n
                        },
                        arrived: Date.now()
                    };
                    s.data.wait = 0, jr.set(t, s)
                }
                i($l, "store"), document.addEventListener("socket:message", $l, {
                    capture: !0
                }), document.addEventListener("pjax:popstate", function(e) {
                    const t = e.target,
                        n = e.detail.cachedAt;
                    n && setTimeout(() => _l(t, n))
                }), (0, v.N7)("form.js-auto-replay-enforced-sso-request", {
                    constructor: HTMLFormElement,
                    initialize(e) {
                        (0, Z.Bt)(e)
                    }
                });
                var Sf = u(59371);

                function Tr(e, t, n) {
                    const o = e.getBoundingClientRect().height,
                        s = t.getBoundingClientRect(),
                        r = n.getBoundingClientRect();
                    let a = r.top;
                    a + s.height + 10 >= o && (a = Math.max(o - s.height - 10, 0));
                    let c = r.right;
                    n.closest(".js-build-status-to-the-left") != null && (c = Math.max(r.left - s.width - 10, 0)), t.style.top = `${a}px`, t.style.left = `${c}px`, t.style.right = "auto"
                }
                i(Tr, "updateStatusPosition"), (0, f.on)("toggle", ".js-build-status .js-dropdown-details", function(e) {
                    const t = e.currentTarget,
                        n = t.querySelector(".js-status-dropdown-menu");
                    if (!n) return;

                    function o() {
                        t.hasAttribute("open") || r()
                    }
                    i(o, "closeOnToggle");

                    function s(a) {
                        n.contains(a.target) || r()
                    }
                    i(s, "closeOnScroll");

                    function r() {
                        t.removeAttribute("open"), n.classList.add("d-none"), t.appendChild(n), t.removeEventListener("toggle", o), window.removeEventListener("scroll", s)
                    }
                    i(r, "closeStatusPopover"), t.addEventListener("toggle", o), n.classList.contains("js-close-menu-on-scroll") && window.addEventListener("scroll", s, {
                        capture: !0
                    }), n.classList.remove("d-none"), n.querySelector(".js-details-container").classList.add("open"), n.classList.contains("js-append-menu-to-body") && (document.body.appendChild(n), Tr(document.body, n, t))
                }, {
                    capture: !0
                });
                async function Ar(e) {
                    const t = e.querySelector(".js-dropdown-details"),
                        n = e.querySelector(".js-status-dropdown-menu") || e.closest(".js-status-dropdown-menu");
                    if (!(n instanceof HTMLElement)) return;
                    const o = n.querySelector(".js-status-loader");
                    if (!o) return;
                    const s = n.querySelector(".js-status-loading"),
                        r = n.querySelector(".js-status-error"),
                        a = o.getAttribute("data-contents-url");
                    s.classList.remove("d-none"), r.classList.add("d-none");
                    let c;
                    try {
                        await (0, cr.Z)(), c = await (0, ie.a)(document, a)
                    } catch {
                        s.classList.add("d-none"), r.classList.remove("d-none")
                    }
                    c && (o.replaceWith(c), n.querySelector(".js-details-container").classList.add("open"), t && n.classList.contains("js-append-menu-to-body") && Tr(document.body, n, t))
                }
                i(Ar, "loadStatus"), (0, f.on)("click", ".js-status-retry", ({
                    currentTarget: e
                }) => {
                    Ar(e)
                });

                function Cr(e) {
                    const t = e.currentTarget;
                    Ar(t)
                }
                i(Cr, "onMouseEnter"), (0, v.N7)(".js-build-status", {
                    add(e) {
                        e.addEventListener("mouseenter", Cr, {
                            once: !0
                        })
                    },
                    remove(e) {
                        e.removeEventListener("mouseenter", Cr)
                    }
                });
                var jf = u(54235),
                    Fl = u(24519);
                (0, f.on)("click", "button[data-sudo-required], summary[data-sudo-required]", kr), (0, v.N7)("form[data-sudo-required]", {
                    constructor: HTMLFormElement,
                    subscribe: e => (0, H.RB)(e, "submit", kr)
                });
                async function kr(e) {
                    const t = e.currentTarget;
                    if (!(t instanceof HTMLElement)) return;
                    e.stopPropagation(), e.preventDefault(), await (0, Fl.Z)() && (t.removeAttribute("data-sudo-required"), t instanceof HTMLFormElement ? (0, Z.Bt)(t) : t.click())
                }
                i(kr, "checkSudo");
                var Ie = u(34821),
                    bt = u(71900);
                const xr = {
                    "actor:": "ul.js-user-suggestions",
                    "user:": "ul.js-user-suggestions",
                    "operation:": "ul.js-operation-suggestions",
                    "org:": "ul.js-org-suggestions",
                    "action:": "ul.js-action-suggestions",
                    "repo:": "ul.js-repo-suggestions",
                    "country:": "ul.js-country-suggestions"
                };
                (0, v.N7)("text-expander[data-audit-url]", {
                    subscribe: e => (0, H.qC)((0, H.RB)(e, "text-expander-change", Wl), (0, H.RB)(e, "text-expander-value", Ul))
                });

                function Ul(e) {
                    const t = e.detail;
                    if (!Mr(t.key)) return;
                    const n = t.item.getAttribute("data-value");
                    t.value = `${t.key}${n}`
                }
                i(Ul, "onvalue");

                function Wl(e) {
                    const {
                        key: t,
                        provide: n,
                        text: o
                    } = e.detail;
                    if (!Mr(t)) return;
                    const r = e.target.getAttribute("data-audit-url");
                    n(Kl(r, t, o))
                }
                i(Wl, "onchange");

                function zl(e, t) {
                    const n = t.toLowerCase(),
                        o = i(s => {
                            const r = s.textContent.toLowerCase().trim(),
                                a = (0, Ie.EW)(r, n);
                            return a > 0 ? {
                                score: a,
                                text: r
                            } : null
                        }, "key");
                    return n ? (0, bt.W)(e, o, Ie.qu) : e
                }
                i(zl, "search");
                const Vl = (0, Se.Z)(e => [...e.children], {
                    hash: e => e.className
                });
                async function Kl(e, t, n) {
                    const s = (await Zl(e)).querySelector(Xl(t));
                    if (!s) return {
                        matched: !1
                    };
                    const r = zl(Vl(s), n).slice(0, 5),
                        a = s.cloneNode(!1);
                    a.innerHTML = "";
                    for (const c of r) a.append(c);
                    return {
                        fragment: a,
                        matched: r.length > 0
                    }
                }
                i(Kl, "auditMenu");

                function Mr(e) {
                    return Object.getOwnPropertyNames(xr).includes(e)
                }
                i(Mr, "isActivationKey");

                function Xl(e) {
                    const t = xr[e];
                    if (!t) throw new Error(`Unknown audit log expander key: ${e}`);
                    return t
                }
                i(Xl, "audit_log_suggester_selector");
                async function Gl(e) {
                    const t = await (0, ie.a)(document, e),
                        n = document.createElement("div");
                    return n.append(t), n
                }
                i(Gl, "fetchMenu");
                const Zl = (0, Se.Z)(Gl);

                function Jl(e) {
                    if (e.hasAttribute("data-use-colon-emoji")) return e.getAttribute("data-value");
                    const t = e.firstElementChild;
                    return t && t.tagName === "G-EMOJI" && !t.firstElementChild ? t.textContent : e.getAttribute("data-value")
                }
                i(Jl, "getValue");

                function Yl(e, t) {
                    const n = ` ${t.toLowerCase().replace(/_/g," ")}`,
                        o = i(s => {
                            const r = s.getAttribute("data-emoji-name"),
                                a = eu(Ql(s), n);
                            return a > 0 ? {
                                score: a,
                                text: r
                            } : null
                        }, "key");
                    return (0, bt.W)(e, o, Ie.qu)
                }
                i(Yl, "emoji_suggester_search");

                function Ql(e) {
                    return ` ${e.getAttribute("data-text").trim().toLowerCase().replace(/_/g," ")}`
                }
                i(Ql, "emojiText");

                function eu(e, t) {
                    const n = e.indexOf(t);
                    return n > -1 ? 1e3 - n : 0
                }
                i(eu, "emojiScore"), (0, v.N7)("text-expander[data-emoji-url]", {
                    subscribe: e => (0, H.qC)((0, H.RB)(e, "text-expander-change", nu), (0, H.RB)(e, "text-expander-value", tu))
                });

                function tu(e) {
                    const t = e.detail;
                    t.key === ":" && (t.value = Jl(t.item))
                }
                i(tu, "emoji_suggester_onvalue");

                function nu(e) {
                    const {
                        key: t,
                        provide: n,
                        text: o
                    } = e.detail;
                    if (t !== ":") return;
                    const r = e.target.getAttribute("data-emoji-url");
                    n(ou(r, o))
                }
                i(nu, "emoji_suggester_onchange");
                async function ou(e, t) {
                    const [n, o] = await ru(e), s = Yl(o, t).slice(0, 5);
                    n.innerHTML = "";
                    for (const r of s) n.append(r);
                    return {
                        fragment: n,
                        matched: s.length > 0
                    }
                }
                i(ou, "emojiMenu");
                async function su(e) {
                    const n = (await (0, ie.a)(document, e)).firstElementChild;
                    return [n, [...n.children]]
                }
                i(su, "fetchEmoji");
                const ru = (0, Se.Z)(su);
                var Fe = u(38772);

                function iu(e) {
                    return `${e.number} ${e.title.trim().toLowerCase()}`
                }
                i(iu, "asText");

                function au(e, t) {
                    if (!t) return e;
                    const n = new RegExp(`\\b${cu(t)}`),
                        o = /^\d+$/.test(t) ? r => lu(r, n) : r => (0, Ie.EW)(r, t),
                        s = i(r => {
                            const a = iu(r),
                                c = o(a);
                            return c > 0 ? {
                                score: c,
                                text: a
                            } : null
                        }, "key");
                    return (0, bt.W)(e, s, Ie.qu)
                }
                i(au, "issue_suggester_search");

                function cu(e) {
                    return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
                }
                i(cu, "escapeRegExp");

                function lu(e, t) {
                    const n = e.search(t);
                    return n > -1 ? 1e3 - n : 0
                }
                i(lu, "issueNumberScore");

                function uu(e, t, n) {
                    const o = i(r => Fe.dy `
    <ul role="listbox" class="suggester-container suggester suggestions list-style-none position-absolute">
      ${r.map(s)}
    </ul>
  `, "itemsTemplate"),
                        s = i(r => {
                            const a = r.type in n ? (0, ve.r)(document, n[r.type]) : "";
                            return Fe.dy `
      <li class="markdown-title" role="option" id="suggester-issue-${r.id}" data-value="${r.number}">
        <span class="d-inline-block mr-1">${a}</span>
        <small>#${r.number}</small> ${(0,Fe.Au)(r.title)}
      </li>
    `
                        }, "itemTemplate");
                    (0, Fe.sY)(o(e), t)
                }
                i(uu, "renderResults"), (0, v.N7)("text-expander[data-issue-url]", {
                    subscribe: e => {
                        const t = [(0, H.RB)(e, "text-expander-change", fu), (0, H.RB)(e, "text-expander-value", du), (0, H.RB)(e, "keydown", hu), (0, H.RB)(e, "click", mu)];
                        return (0, H.qC)(...t)
                    }
                });

                function du(e) {
                    const t = e.detail;
                    if (t.key !== "#") return;
                    const n = t.item.getAttribute("data-value");
                    t.value = `#${n}`
                }
                i(du, "issue_suggester_onvalue");

                function fu(e) {
                    const {
                        key: t,
                        provide: n,
                        text: o
                    } = e.detail;
                    if (t !== "#") return;
                    if (o === "#") {
                        go(e.target);
                        return
                    }
                    const r = e.target.getAttribute("data-issue-url");
                    n(pu(r, o))
                }
                i(fu, "issue_suggester_onchange");

                function go(e) {
                    if (!e) return;
                    const t = e.closest("text-expander");
                    t && t.dismiss()
                }
                i(go, "hideSuggestions");

                function mu(e) {
                    go(e.target)
                }
                i(mu, "issue_suggester_onclick");

                function hu(e) {
                    const t = ["ArrowRight", "ArrowLeft"],
                        {
                            key: n
                        } = e;
                    t.indexOf(n) < 0 || go(e.target)
                }
                i(hu, "issue_suggester_onkeydown");
                async function pu(e, t) {
                    const n = await gu(e),
                        o = document.createElement("div"),
                        s = au(n.suggestions, t).slice(0, 5);
                    return uu(s, o, n.icons), {
                        fragment: o.firstElementChild,
                        matched: s.length > 0
                    }
                }
                i(pu, "issueMenu");
                const gu = (0, Se.Z)(async function(e) {
                    const t = await self.fetch(e, {
                        headers: {
                            "X-Requested-With": "XMLHttpRequest",
                            Accept: "application/json"
                        }
                    });
                    if (!t.ok) {
                        const n = new Error,
                            o = t.statusText ? ` ${t.statusText}` : "";
                        throw n.message = `HTTP ${t.status}${o}`, n
                    }
                    return t.json()
                });

                function bu(e) {
                    return e.description ? `${e.name} ${e.description}`.trim().toLowerCase() : `${e.login} ${e.name}`.trim().toLowerCase()
                }
                i(bu, "mention_suggester_asText");

                function yu(e, t) {
                    if (!t) return e;
                    const n = wu(t),
                        o = i(s => {
                            const r = bu(s),
                                a = n(r, s.participant);
                            return a > 0 ? {
                                score: a,
                                text: r
                            } : null
                        }, "key");
                    return (0, bt.W)(e, o, Ie.qu)
                }
                i(yu, "mention_suggester_search");

                function vu(e, t) {
                    const n = i(s => Fe.dy `
    <ul role="listbox" class="suggester-container suggester suggestions list-style-none position-absolute">
      ${s.map(o)}
    </ul>
  `, "itemsTemplate"),
                        o = i(s => {
                            const r = s.type === "user" ? s.login : s.name,
                                a = s.type === "user" ? s.name : s.description;
                            return Fe.dy `
      <li role="option" id="suggester-${s.id}-${s.type}-${r}" data-value="${r}">
        <span>${r}</span>
        <small>${a}</small>
      </li>
    `
                        }, "itemTemplate");
                    (0, Fe.sY)(n(e), t)
                }
                i(vu, "mention_suggester_renderResults");

                function wu(e) {
                    if (!e) return () => 2;
                    const t = e.toLowerCase().split("");
                    return (n, o) => {
                        if (!n) return 0;
                        const s = Eu(n, t);
                        if (!s) return 0;
                        const a = e.length / s[1] / (s[0] / 2 + 1);
                        return o ? a + 1 : a
                    }
                }
                i(wu, "fuzzyScorer");

                function Eu(e, t) {
                    let n, o, s, r;
                    const a = Lu(e, t[0]);
                    if (a.length === 0) return null;
                    if (t.length === 1) return [a[0], 1, []];
                    for (r = null, o = 0, s = a.length; o < s; o++) {
                        const c = a[o];
                        if (!(n = Su(e, t, c + 1))) continue;
                        const l = n[n.length - 1] - c;
                        (!r || l < r[1]) && (r = [c, l, n])
                    }
                    return r
                }
                i(Eu, "shortestMatch");

                function Lu(e, t) {
                    let n = 0;
                    const o = [];
                    for (;
                        (n = e.indexOf(t, n)) > -1;) o.push(n++);
                    return o
                }
                i(Lu, "allIndexesOf");

                function Su(e, t, n) {
                    let o = n;
                    const s = [];
                    for (let r = 1; r < t.length; r += 1) {
                        if (o = e.indexOf(t[r], o), o === -1) return;
                        s.push(o++)
                    }
                    return s
                }
                i(Su, "indexesOfChars"), (0, v.N7)("text-expander[data-mention-url]", {
                    subscribe: e => (0, H.qC)((0, H.RB)(e, "text-expander-change", Tu), (0, H.RB)(e, "text-expander-value", ju))
                });

                function ju(e) {
                    const t = e.detail;
                    if (t.key !== "@") return;
                    const n = t.item.getAttribute("data-value");
                    t.value = `@${n}`
                }
                i(ju, "mention_suggester_onvalue");

                function Tu(e) {
                    const {
                        key: t,
                        provide: n,
                        text: o
                    } = e.detail;
                    if (t !== "@" || (o == null ? void 0 : o.split(" ").length) > 1) return;
                    const r = e.target.getAttribute("data-mention-url");
                    n(Au(r, o))
                }
                i(Tu, "mention_suggester_onchange");
                async function Au(e, t) {
                    const n = await Cu(e),
                        o = document.createElement("div"),
                        s = yu(n, t).slice(0, 5);
                    return vu(s, o), {
                        fragment: o.firstElementChild,
                        matched: s.length > 0
                    }
                }
                i(Au, "mentionMenu");
                const Cu = (0, Se.Z)(async function(e) {
                        const t = await self.fetch(e, {
                            headers: {
                                "X-Requested-With": "XMLHttpRequest",
                                Accept: "application/json"
                            }
                        });
                        if (!t.ok) {
                            const n = new Error,
                                o = t.statusText ? ` ${t.statusText}` : "";
                            throw n.message = `HTTP ${t.status}${o}`, n
                        }
                        return t.json()
                    }),
                    bo = "/";

                function ku(e, t) {
                    const n = t.toLowerCase().trim(),
                        o = i(s => {
                            const r = (s.getAttribute("data-text") || "").trim().toLowerCase(),
                                a = (0, Ie.EW)(r, n);
                            return a > 0 ? {
                                score: a,
                                text: r
                            } : null
                        }, "key");
                    return n ? (0, bt.W)(e, o, Ie.qu) : e
                }
                i(ku, "slash_command_suggester_search"), (0, v.N7)("slash-command-expander[data-slash-command-url]", {
                    subscribe: e => (0, H.qC)((0, H.RB)(e, "text-expander-change", Hu), (0, H.RB)(e, "text-expander-value", xu))
                }), (0, f.on)("click", ".js-slash-command-toolbar-button", async e => {
                    if (!(e.target instanceof Element)) return;
                    const t = e.target.closest(".js-previewable-comment-form");
                    if (!t) return;
                    const n = t.querySelector("textarea.js-comment-field");
                    if (!n) return;
                    const o = bo,
                        s = n.selectionEnd || 0,
                        r = n.value.substring(0, s),
                        a = n.value.substring(s),
                        c = n.value === "" || r.match(/\s$/) ? "" : " ",
                        l = s + o.length + 1;
                    n.value = r + c + o + a, n.selectionStart = l, n.selectionEnd = l, n.focus(), (0, f.f)(n, "input")
                });
                async function xu(e) {
                    const t = e.detail,
                        {
                            key: n,
                            item: o
                        } = t;
                    if (n !== bo) return;
                    const s = o.getAttribute("data-url");
                    if (!s) return;
                    const r = e.currentTarget,
                        a = o.querySelector(".js-slash-command-suggestion-form");
                    if (!a) return;
                    const c = a.querySelector(".js-data-url-csrf");
                    if (!c) return;
                    const l = new FormData(a);
                    r.isLoading();
                    try {
                        const d = await (0, ie.a)(document, s, {
                            method: "PATCH",
                            body: l,
                            headers: {
                                Accept: "text/html",
                                "Scoped-CSRF-Token": c.value
                            }
                        });
                        if (!d) return;
                        qr(r, d)
                    } catch {
                        r.showError()
                    }
                }
                i(xu, "onValue");

                function qr(e, t) {
                    var n;
                    const o = t.firstElementChild;
                    if (!o) return;
                    t.children.length > 1 && Du(t.lastElementChild, e), o.hasAttribute("data-reload-suggestions") && (Ir = (0, Se.Z)(Rr));
                    const s = o.getAttribute("data-component-type");
                    s === "fill" ? /<\/?[a-z][\s\S]*>/i.test(o.innerHTML) ? e.setValue(o.innerHTML.trim()) : e.setValue(((n = o.textContent) == null ? void 0 : n.trim()) || "") : s === "menu" || s === "error" ? e.setMenu(o.querySelector(".js-slash-command-menu")) : s === "action" ? e.closeMenu() : s === "embedded_form" ? Iu(e, o) : s === "dialog_form" ? Pu(e, o) : s === "modal_form" && Ru(e, o), (0, fe.e6)(me())
                }
                i(qr, "handleResponse");

                function Mu(e) {
                    if (!(e.metaKey && e.key === "Enter")) return;
                    e.preventDefault(), e.stopPropagation();
                    const t = e.target,
                        n = t == null ? void 0 : t.form;
                    if (!!n)
                        if (n.requestSubmit) n.requestSubmit();
                        else {
                            const o = n.querySelector("[type='submit']");
                            o == null || o.click()
                        }
                }
                i(Mu, "submitOnCommandEnter");

                function Pr(e) {
                    const t = new FormData(e);
                    let n = "";
                    for (const o of t) n = n + o[0], n = n + o[1].toString();
                    return n
                }
                i(Pr, "getFormContents");

                function yo(e) {
                    let t = !1;
                    for (const n of e.querySelectorAll("select,input,textarea")) {
                        const o = n;
                        o.type !== "hidden" && (t || (o.focus(), t = !0), o.addEventListener("keydown", Mu))
                    }
                }
                i(yo, "focusFirstFormInput");

                function vo(e, t) {
                    const n = e.querySelectorAll("[data-close-dialog]");
                    for (const o of n) o.addEventListener("click", s => {
                        s.preventDefault(), (0, fe.Xm)(me(), {
                            selector: ".js-session-resumable"
                        }), t()
                    })
                }
                i(vo, "hookUpCancelActionListeners");

                function wo(e, t, n, o) {
                    const s = Pr(e);
                    t.addEventListener("keydown", r => {
                        if (r.key === "Escape") {
                            const a = "Are you sure you want to dismiss the form?",
                                c = Pr(e);
                            (s === c || confirm(a)) && ((0, fe.Xm)(me(), {
                                selector: ".js-session-resumable"
                            }), o(), n && n.focus())
                        }
                    })
                }
                i(wo, "addDismissAlertListener");

                function Eo(e, t, n) {
                    e.addEventListener("submit", async o => {
                        o.preventDefault();
                        const s = o.target,
                            r = s.querySelector(".js-data-url-csrf");
                        if (!r) return;
                        const a = s.getAttribute("action");
                        if (!a) return;
                        qu(t);
                        const c = new FormData(s),
                            l = await (0, ie.a)(document, a, {
                                method: "PATCH",
                                body: c,
                                headers: {
                                    Accept: "text/html",
                                    "Scoped-CSRF-Token": r.value
                                }
                            });
                        n(), !!l && qr(t, l)
                    })
                }
                i(Eo, "addSubmitButtonListener");

                function qu(e) {
                    const t = e.closest(".js-slash-command-surface"),
                        n = e.closest("form"),
                        o = t || n;
                    if (o)
                        for (const s of o.querySelectorAll("[data-disable-with][disabled]")) s.disabled = !1
                }
                i(qu, "reenableParentFormButtons");

                function Pu(e, t) {
                    const n = t.querySelector(".js-slash-command-menu");
                    e.setMenu(n, !0);
                    const o = n.querySelector("form"),
                        s = document.activeElement;
                    yo(o);
                    const r = i(() => {
                        e.closeMenu()
                    }, "closeForm");
                    wo(o, o, s, r), vo(o, r), Eo(o, e, r)
                }
                i(Pu, "handleDialogForm");

                function Ru(e, t) {
                    const n = e.closest("form");
                    if (!n) return;
                    const o = t.querySelector('[data-component="form"]');
                    n.insertAdjacentElement("afterend", o);
                    const s = document.activeElement;
                    yo(o);
                    const r = i(() => {
                        n.hidden = !1, o.remove()
                    }, "closeForm");
                    vo(o, r);
                    const a = o.getElementsByTagName("form")[0];
                    wo(a, o, s, r), Eo(o, e, r)
                }
                i(Ru, "handleModalForm");

                function Iu(e, t) {
                    const n = e.closest(".js-slash-command-surface"),
                        o = e.closest("form"),
                        s = n || o;
                    if (!s) return;
                    s.hidden = !0;
                    const r = t.querySelector('[data-component="form"]');
                    s.insertAdjacentElement("afterend", r);
                    const a = document.activeElement;
                    yo(r);
                    const c = i(() => {
                        s.hidden = !1, r.remove()
                    }, "closeForm");
                    vo(r, c);
                    const l = r.getElementsByTagName("form")[0];
                    wo(l, r, a, c), Eo(r, e, c)
                }
                i(Iu, "handleEmbeddedForm");
                const Nu = 5e3;

                function Du(e, t) {
                    var n, o;
                    const s = (n = t.parentElement) == null ? void 0 : n.parentElement;
                    if (!s) return;
                    const r = s.querySelector(".drag-and-drop .default");
                    let a = !1;
                    r && (a = r.hidden, r.hidden = !0), (o = r == null ? void 0 : r.parentElement) == null || o.prepend(e), setTimeout(() => {
                        r && (r.hidden = a), e.remove()
                    }, Nu)
                }
                i(Du, "showFooter");

                function Hu(e) {
                    const {
                        key: t,
                        provide: n,
                        text: o
                    } = e.detail;
                    if (t !== bo) return;
                    const s = e.target;
                    s.isLoading();
                    const r = s.getAttribute("data-slash-command-url");
                    n(Ou(r, o, s))
                }
                i(Hu, "onChange");
                async function Ou(e, t, n) {
                    try {
                        const [o, s] = await Ir(e), r = o.querySelector(".js-slash-command-menu-items"), a = ku(s, t);
                        if (r) {
                            r.innerHTML = "";
                            for (const c of s)
                                if (c.classList.contains("js-group-divider")) {
                                    const l = c.getAttribute("data-group-id");
                                    a.filter(p => p.getAttribute("data-group-id") === l).length > 0 && r.append(c)
                                } else a.includes(c) && r.append(c)
                        }
                        return {
                            fragment: o,
                            matched: a.length > 0
                        }
                    } catch (o) {
                        throw n.showError(), new Error(o)
                    }
                }
                i(Ou, "slashCommandMenu");
                async function Rr(e) {
                    const n = (await (0, ie.a)(document, e)).firstElementChild,
                        o = n.querySelectorAll(".js-slash-command-menu-items li");
                    return [n, [...o]]
                }
                i(Rr, "fetchSlashCommands");
                let Ir = (0, Se.Z)(Rr);

                function Bu(e, t) {
                    const n = e.closest(".js-survey-question-form"),
                        o = n.querySelector("input.js-survey-other-text"),
                        s = t && !n.classList.contains("is-other-selected");
                    n.classList.toggle("is-other-selected", s), o.hidden = !t, s ? (o.required = !0, o.focus()) : o.required = !1, (0, f.f)(o, "change")
                }
                i(Bu, "handleOther"), (0, f.on)("change", "input.js-survey-radio", function({
                    currentTarget: e
                }) {
                    Bu(e, e.classList.contains("js-survey-radio-other"))
                }), (0, f.on)("change", "input.js-survey-checkbox-enable-submit", function({
                    currentTarget: e
                }) {
                    var t;
                    const n = e.checked,
                        o = (t = e.closest("form")) == null ? void 0 : t.querySelector("button[type=submit]");
                    o.disabled = !n
                }), (0, f.on)("change", "input.js-survey-contact-checkbox", function(e) {
                    const t = e.currentTarget,
                        o = t.closest(".js-survey-question-form").querySelector(".js-survey-contact-checkbox-hidden");
                    t.checked ? o.setAttribute("disabled", "true") : o.removeAttribute("disabled")
                }), (0, f.on)("details-menu-selected", ".js-sync-select-menu-text", function(e) {
                    const t = document.querySelector(".js-sync-select-menu-button"),
                        n = e.detail.relatedTarget.querySelector("span[data-menu-button-text]").textContent;
                    t.textContent = n, t.focus()
                }, {
                    capture: !0
                }), (0, f.on)("click", 'tab-container [role="tab"]', function(e) {
                    const {
                        currentTarget: t
                    } = e, o = t.closest("tab-container").querySelector(".js-filterable-field, [data-filter-placeholder-input]");
                    if (o instanceof HTMLInputElement) {
                        const s = t.getAttribute("data-filter-placeholder");
                        s && o.setAttribute("placeholder", s), o.focus()
                    }
                }), (0, f.on)("tab-container-changed", "tab-container", function(e) {
                    const t = e.detail.relatedTarget,
                        n = t.getAttribute("data-fragment-url"),
                        o = t.querySelector("include-fragment");
                    n && o && !o.hasAttribute("src") && (o.src = n)
                });
                var Tf = u(64048),
                    Nr = u(96776);
                document.addEventListener("keydown", e => {
                    if (e.key !== "Escape" || e.target !== document.body) return;
                    const t = document.querySelector(".js-targetable-element:target");
                    !t || (0, Nr.uQ)(t, () => {
                        window.location.hash = "", window.history.replaceState(null, "", window.location.pathname + window.location.search)
                    })
                }), document.addEventListener("click", e => {
                    const t = document.querySelector(".js-targetable-element:target");
                    !t || e.target instanceof HTMLAnchorElement || e.target instanceof HTMLElement && (t.contains(e.target) || (0, Nr.uQ)(t, () => {
                        window.location.hash = "", window.history.replaceState(null, "", window.location.pathname + window.location.search)
                    }))
                });
                var Af = u(36099);
                async function _u(e) {
                    const t = e.currentTarget;
                    if (Fu(t)) {
                        t.classList.remove("tooltipped");
                        return
                    }
                    const n = t.getAttribute("data-url");
                    if (!n) return;
                    const o = await fetch(n, {
                        headers: {
                            Accept: "application/json"
                        }
                    });
                    if (!o.ok) return;
                    const s = await o.json(),
                        r = t.getAttribute("data-id"),
                        a = document.querySelectorAll(`.js-team-mention[data-id='${r}']`);
                    for (const c of a) c.removeAttribute("data-url");
                    try {
                        s.total === 0 ? s.members.push("This team has no members") : s.total > s.members.length && s.members.push(`${s.total-s.members.length} more`), Dr(a, $u(s.members))
                    } catch (c) {
                        const l = c.response ? c.response.status : 500,
                            d = t.getAttribute(l === 404 ? "data-permission-text" : "data-error-text");
                        Dr(a, d)
                    }
                }
                i(_u, "members");

                function Dr(e, t) {
                    for (const n of e) n instanceof HTMLElement && (n.setAttribute("aria-label", t), n.classList.add("tooltipped", "tooltipped-s", "tooltipped-multiline"))
                }
                i(Dr, "tip");

                function $u(e) {
                    if ("ListFormat" in Intl) return new Intl.ListFormat().format(e);
                    if (e.length === 0) return "";
                    if (e.length === 1) return e[0];
                    if (e.length === 2) return e.join(" and "); {
                        const t = e[e.length - 1];
                        return e.slice(0, -1).concat(`and ${t}`).join(", ")
                    }
                }
                i($u, "sentence");

                function Fu(e) {
                    return !!e.getAttribute("data-hovercard-url") && !!e.closest("[data-team-hovercards-enabled]")
                }
                i(Fu, "teamHovercardEnabled"), (0, v.N7)(".js-team-mention", function(e) {
                    e.addEventListener("mouseenter", _u)
                });
                var Uu = Object.defineProperty,
                    Wu = Object.getOwnPropertyDescriptor,
                    an = i((e, t, n, o) => {
                        for (var s = o > 1 ? void 0 : o ? Wu(t, n) : t, r = e.length - 1, a; r >= 0; r--)(a = e[r]) && (s = (o ? a(t, n, s) : a(s)) || s);
                        return o && s && Uu(t, n, s), s
                    }, "text_suggester_element_decorateClass");
                let yt = i(class extends HTMLElement {
                    acceptSuggestion() {
                        var e;
                        ((e = this.suggestion) == null ? void 0 : e.textContent) && (this.input.value = this.suggestion.textContent, this.input.dispatchEvent(new Event("input")), this.suggestionContainer && (this.suggestionContainer.hidden = !0), this.input.focus())
                    }
                }, "TextSuggesterElement");
                an([R.fA], yt.prototype, "input", 2), an([R.fA], yt.prototype, "suggestionContainer", 2), an([R.fA], yt.prototype, "suggestion", 2), yt = an([R.Ih], yt);

                function zu() {
                    const e = document.querySelector(".js-timeline-marker");
                    return e != null ? e.getAttribute("data-last-modified") : null
                }
                i(zu, "getTimelineLastModified");

                function Hr(e) {
                    if (Ku(e) || Vu(e)) return;
                    const t = zu();
                    t && e.headers.set("X-Timeline-Last-Modified", t)
                }
                i(Hr, "addTimelineLastModifiedHeader");

                function Vu(e) {
                    return e.headers.get("X-PJAX") === "true"
                }
                i(Vu, "isPjax");

                function Ku(e) {
                    let t;
                    try {
                        t = new URL(e.url)
                    } catch {
                        return !0
                    }
                    return t.host !== window.location.host
                }
                i(Ku, "isCrossDomain"), (0, K.AC)(".js-needs-timeline-marker-header", function(e, t, n) {
                    Hr(n)
                }), (0, f.on)("deprecatedAjaxSend", "[data-remote]", function(e) {
                    const {
                        request: t
                    } = e.detail;
                    Hr(t)
                });
                const Or = 5e3,
                    Xu = ".js-comment-body img",
                    Gu = ".js-comment-body video";
                (0, Bt.Z)(function() {
                    cn()
                }), (0, v.N7)(".js-timeline-progressive-focus-container", function(e) {
                    const t = ln();
                    if (!t || document.querySelector(".js-pull-discussion-timeline")) return;
                    const o = document.getElementById(t);
                    o && e.contains(o) && Lo(o)
                });

                function cn(e = !0) {
                    const t = ln();
                    if (!t) return;
                    const n = document.getElementById(t);
                    if (n) Lo(n);
                    else {
                        if (Zu(t)) return;
                        const o = document.querySelector("#js-timeline-progressive-loader");
                        o && e && $r(t, o)
                    }
                }
                i(cn, "focusOrLoadElement");

                function Zu(e) {
                    return Ju(e) || Br(e, ".js-thread-hidden-comment-ids") || Br(e, ".js-review-hidden-comment-ids")
                }
                i(Zu, "loadComments");

                function Ju(e) {
                    const t = _r(e, ".js-comment-container");
                    return t ? ((0, Fn.$)(t), !0) : !1
                }
                i(Ju, "loadResolvedComments");

                function Br(e, t) {
                    const n = _r(e, t);
                    return n ? (n.addEventListener("page:loaded", function() {
                        cn()
                    }), n.querySelector("button[type=submit]").click(), !0) : !1
                }
                i(Br, "loadHiddenComments");

                function _r(e, t) {
                    var n;
                    const o = document.querySelectorAll(t);
                    for (const s of o) {
                        const r = s.getAttribute("data-hidden-comment-ids");
                        if (r) {
                            const a = r.split(","),
                                c = (n = e.match(/\d+/g)) == null ? void 0 : n[0];
                            if (c && a.includes(c)) return s
                        }
                    }
                    return null
                }
                i(_r, "findCommentContainer"), (0, v.N7)(".js-inline-comments-container", function(e) {
                    const t = ln();
                    if (!t) return;
                    const n = document.getElementById(t);
                    n && e.contains(n) && Lo(n)
                }), (0, v.N7)("#js-discussions-timeline-anchor-loader", {
                    constructor: HTMLElement,
                    add: e => {
                        if (document.querySelector("#js-timeline-progressive-loader")) return;
                        const n = ln();
                        if (!n) return;
                        document.getElementById(n) || $r(n, e)
                    }
                });
                async function Yu() {
                    const e = document.querySelectorAll(Gu),
                        t = Array.from(e).map(n => new Promise(o => {
                            if (n.readyState >= n.HAVE_METADATA) o(n);
                            else {
                                const s = setTimeout(() => o(n), Or),
                                    r = i(() => {
                                        clearTimeout(s), o(n)
                                    }, "done");
                                n.addEventListener("loadeddata", () => {
                                    n.readyState >= n.HAVE_METADATA && r()
                                }), n.addEventListener("error", () => r())
                            }
                        }));
                    return Promise.all(t)
                }
                i(Yu, "videosReady");
                async function Qu() {
                    const e = document.querySelectorAll(Xu),
                        t = Array.from(e).map(n => {
                            new Promise(o => {
                                if (n.complete) o(n);
                                else {
                                    const s = setTimeout(() => o(n), Or),
                                        r = i(() => {
                                            clearTimeout(s), o(n)
                                        }, "done");
                                    n.addEventListener("load", () => r()), n.addEventListener("error", () => r())
                                }
                            })
                        });
                    return Promise.all(t)
                }
                i(Qu, "imagesReady");
                async function ed() {
                    return Promise.all([Yu(), Qu()])
                }
                i(ed, "mediaLoaded");
                async function Lo(e) {
                    await ed(), td(e);
                    const t = e.querySelector(`[href='#${e.id}']`);
                    if (t) {
                        const n = t.getAttribute("data-turbo");
                        t.setAttribute("data-turbo", "false"), t.click(), n === null ? t.removeAttribute("data-turbo") : t.setAttribute("data-turbo", n)
                    }
                }
                i(Lo, "focusElement");
                async function $r(e, t) {
                    if (!t) return;
                    const n = t.getAttribute("data-timeline-item-src");
                    if (!n) return;
                    const o = new URL(n, window.location.origin),
                        s = new URLSearchParams(o.search.slice(1));
                    s.append("anchor", e), o.search = s.toString();
                    let r;
                    try {
                        r = await (0, ie.a)(document, o.toString())
                    } catch {
                        return
                    }
                    const a = r.querySelector(".js-timeline-item");
                    if (!a) return;
                    const c = a.getAttribute("data-gid");
                    if (!c) return;
                    const l = document.querySelector(`.js-timeline-item[data-gid='${c}']`);
                    if (l) l.replaceWith(a), cn(!1);
                    else {
                        const d = document.getElementById("js-progressive-timeline-item-container");
                        d && d.replaceWith(r), cn(!1)
                    }
                }
                i($r, "loadElement");

                function td(e) {
                    const t = e.closest("details, .js-details-container");
                    !t || (t.nodeName === "DETAILS" ? t.setAttribute("open", "open") : (0, $n.jo)(t) || (0, $n.Qp)(t))
                }
                i(td, "expandDetailsIfPresent");

                function ln() {
                    return window.location.hash.slice(1)
                }
                i(ln, "urlAnchor"), (0, v.N7)(".js-discussion", nd);

                function nd() {
                    let e = new WeakSet;
                    t(), document.addEventListener("pjax:end", t), (0, v.N7)(".js-timeline-item", n => {
                        n instanceof HTMLElement && (e.has(n) || (0, ue.N)(n))
                    });

                    function t() {
                        e = new WeakSet(document.querySelectorAll(".js-timeline-item"))
                    }
                    i(t, "setExistingTimelineItems")
                }
                i(nd, "announceTimelineEvents");
                var vt = u(82131);

                function wt(e) {
                    const {
                        name: t,
                        value: n
                    } = e, o = {
                        name: window.location.href
                    };
                    switch (t) {
                        case "CLS":
                            o.cls = n;
                            break;
                        case "FCP":
                            o.fcp = n;
                            break;
                        case "FID":
                            o.fid = n;
                            break;
                        case "LCP":
                            o.lcp = n;
                            break;
                        case "TTFB":
                            o.ttfb = n;
                            break
                    }(0, Le.b)({
                        webVitalTimings: [o]
                    }), od(t, n)
                }
                i(wt, "sendVitals");

                function od(e, t) {
                    const n = document.querySelector("#staff-bar-web-vitals"),
                        o = n == null ? void 0 : n.querySelector(`[data-metric=${e.toLowerCase()}]`);
                    !o || (o.textContent = t.toPrecision(6))
                }
                i(od, "updateStaffBar");

                function sd() {
                    return !!(window.performance && window.performance.timing && window.performance.getEntriesByType)
                }
                i(sd, "isTimingSuppported");
                async function rd() {
                    if (!sd()) return;
                    await Ee.C, await new Promise(n => setTimeout(n));
                    const e = window.performance.getEntriesByType("resource");
                    e.length && (0, Le.b)({
                        resourceTimings: e
                    });
                    const t = window.performance.getEntriesByType("navigation");
                    t.length && (0, Le.b)({
                        navigationTimings: t
                    })
                }
                i(rd, "sendTimingResults"), rd(), (0, vt.kz)(wt), (0, vt.Y)(wt), (0, vt.Tx)(wt), (0, vt.Tb)(wt), (0, vt.CA)(wt), (0, f.on)("click", ".js-toggler-container .js-toggler-target", function(e) {
                    if (e.button !== 0) return;
                    const t = e.currentTarget.closest(".js-toggler-container");
                    t && t.classList.toggle("on")
                }), (0, K.AC)(".js-toggler-container", async (e, t) => {
                    e.classList.remove("success", "error"), e.classList.add("loading");
                    try {
                        await t.text(), e.classList.add("success")
                    } catch {
                        e.classList.add("error")
                    } finally {
                        e.classList.remove("loading")
                    }
                }), async function() {
                    var e;
                    if ("serviceWorker" in navigator) {
                        await Ee.x;
                        const t = (e = document.querySelector('link[rel="service-worker-src"]')) == null ? void 0 : e.href;
                        t ? navigator.serviceWorker.register(t, {
                            scope: "/"
                        }) : await id()
                    }
                }();
                async function id() {
                    let e = [];
                    try {
                        e = await navigator.serviceWorker.getRegistrations()
                    } catch (t) {
                        if (t.name === "SecurityError") return
                    }
                    for (const t of e) t.unregister()
                }
                i(id, "unregisterAllServiceWorkers");
                var je = u(79785);
                if ((0, Re.c)("TURBO")) {
                    (async () => {
                        const {
                            PageRenderer: t,
                            session: n
                        } = await u.e(6184).then(u.bind(u, 36184)), o = n.adapter;
                        document.addEventListener("turbo:before-fetch-request", c => {
                            const l = c.target;
                            (l == null ? void 0 : l.tagName) === "TURBO-FRAME" && (o.progressBar.setValue(0), o.progressBar.show())
                        }), document.addEventListener("turbo:frame-render", c => {
                            const l = c.target;
                            (l == null ? void 0 : l.tagName) === "TURBO-FRAME" && (o.progressBar.setValue(100), o.progressBar.hide())
                        });
                        const s = Object.getOwnPropertyDescriptor(t.prototype, "trackedElementsAreIdentical").get;
                        Object.defineProperty(t.prototype, "trackedElementsAreIdentical", {
                            get() {
                                const c = s.call(this);
                                return c || r(this.currentHeadSnapshot, this.newHeadSnapshot), c
                            }
                        });

                        function r(c, l) {
                            const d = Object.fromEntries(a(c));
                            for (const [p, j] of a(l))
                                if (d[p] !== j) {
                                    (0, je.Ak)(`${p.replace(/^x-/,"")} changed`);
                                    break
                                }
                        }
                        i(r, "setReasonForTurboFail");

                        function* a(c) {
                            for (const l of Object.values(c.detailsByOuterHTML))
                                if (l.tracked)
                                    for (const d of l.elements) d instanceof HTMLMetaElement && d.getAttribute("http-equiv") && (yield [d.getAttribute("http-equiv") || "", d.getAttribute("content") || ""])
                        }
                        i(a, "getSnapshotSignatures")
                    })();
                    const e = i((t, n) => {
                        const o = new URL(t, window.location.origin),
                            s = new URL(n, window.location.origin);
                        return o.host === s.host && o.pathname === s.pathname
                    }, "isIntraPageNavigation");
                    document.addEventListener("turbo:click", function(t) {
                        if (!(t.target instanceof HTMLElement)) return;
                        const n = t.target.closest("[data-turbo-frame]");
                        n instanceof HTMLElement && t.target.setAttribute("data-turbo-frame", n.getAttribute("data-turbo-frame") || ""), t instanceof CustomEvent && e(location.href, t.detail.url) && t.preventDefault()
                    }), document.addEventListener("turbo:before-render", t => {
                        if (!(t instanceof CustomEvent)) return;
                        const n = t.detail.newBody.ownerDocument.documentElement,
                            o = document.documentElement;
                        for (const s of o.attributes) !n.hasAttribute(s.nodeName) && s.nodeName !== "aria-busy" && o.removeAttribute(s.nodeName);
                        for (const s of n.attributes) o.getAttribute(s.nodeName) !== s.nodeValue && o.setAttribute(s.nodeName, s.nodeValue)
                    }), document.addEventListener("turbo:visit", je.LD), document.addEventListener("turbo:render", je.FP), document.addEventListener("beforeunload", je.FP), document.addEventListener("turbo:load", t => {
                        Object.keys(t.detail.timing).length === 0 ? (0, je.OE)() || (0, je.Po)() ? (0, je.Ys)() : (0, je.F6)() : (0, je.Xk)()
                    })
                }

                function ad() {
                    if ("Intl" in window) try {
                        return new window.Intl.DateTimeFormat().resolvedOptions().timeZone
                    } catch {}
                }
                i(ad, "timezone"), window.requestIdleCallback(() => {
                    const e = ad();
                    e && (0, dt.d8)("tz", encodeURIComponent(e))
                });
                var Fr = u(70112),
                    cd = Object.defineProperty,
                    ld = Object.getOwnPropertyDescriptor,
                    oe = i((e, t, n, o) => {
                        for (var s = o > 1 ? void 0 : o ? ld(t, n) : t, r = e.length - 1, a; r >= 0; r--)(a = e[r]) && (s = (o ? a(t, n, s) : a(s)) || s);
                        return o && s && cd(t, n, s), s
                    }, "webauthn_get_decorateClass"),
                    ud = (e => (e.Initializing = "initializing", e.Unsupported = "unsupported", e.Ready = "ready", e.Waiting = "waiting", e.Error = "error", e.Submitting = "submitting", e))(ud || {});
                let pe = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.state = "initializing", this.json = "", this.autofocusWhenReady = !1, this.autoPrompt = !1, this.hasErrored = !1
                    }
                    connectedCallback() {
                        this.originalButtonText = this.button.textContent, this.setState((0, Fr.Zh)() ? "ready" : "unsupported"), this.autoPrompt && this.prompt(void 0, !0)
                    }
                    setState(e) {
                        this.button.textContent = this.hasErrored ? this.button.getAttribute("data-retry-message") : this.originalButtonText, this.button.disabled = !1, this.button.hidden = !1;
                        for (const t of this.messages) t.hidden = !0;
                        switch (e) {
                            case "initializing":
                                this.button.disabled = !0;
                                break;
                            case "unsupported":
                                this.button.disabled = !0, this.unsupportedMessage.hidden = !1;
                                break;
                            case "ready":
                                this.autofocusWhenReady && this.button.focus();
                                break;
                            case "waiting":
                                this.waitingMessage.hidden = !1, this.button.hidden = !0;
                                break;
                            case "error":
                                this.errorMessage.hidden = !1;
                                break;
                            case "submitting":
                                this.button.textContent = "Verifying\u2026", this.button.disabled = !0;
                                break;
                            default:
                                throw new Error("invalid state")
                        }
                        this.state = e
                    }
                    async prompt(e, t) {
                        e == null || e.preventDefault(), this.dispatchEvent(new CustomEvent("webauthn-get-prompt"));
                        try {
                            t || this.setState("waiting");
                            const n = JSON.parse(this.json),
                                o = await (0, Fr.U2)(n);
                            this.setState("submitting");
                            const s = this.closest(".js-webauthn-form"),
                                r = s.querySelector(".js-webauthn-response");
                            r.value = JSON.stringify(o), (0, Z.Bt)(s)
                        } catch (n) {
                            if (!t) throw this.hasErrored = !0, this.setState("error"), n
                        }
                    }
                }, "WebauthnGetElement");
                oe([R.fA], pe.prototype, "button", 2), oe([R.GO], pe.prototype, "messages", 2), oe([R.fA], pe.prototype, "unsupportedMessage", 2), oe([R.fA], pe.prototype, "waitingMessage", 2), oe([R.fA], pe.prototype, "errorMessage", 2), oe([R.Lj], pe.prototype, "json", 2), oe([R.Lj], pe.prototype, "autofocusWhenReady", 2), oe([R.Lj], pe.prototype, "autoPrompt", 2), pe = oe([R.Ih], pe);
                var dd = (e => (e.Initializing = "initializing", e.ShowingForm = "showing-form", e.ShowingRevealer = "showing-revealer", e))(dd || {});
                let tt = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.state = "showing-form"
                    }
                    connectedCallback() {
                        this.setState(this.state)
                    }
                    setState(e) {
                        switch (this.revealer.hidden = !0, this.form.hidden = !1, e) {
                            case "initializing":
                                break;
                            case "showing-form":
                                this.passwordField.focus(), this.dispatchEvent(new CustomEvent("sudo-password-showing-form"));
                                break;
                            case "showing-revealer":
                                this.revealer.hidden = !1, this.form.hidden = !0;
                                break;
                            default:
                                throw new Error("invalid state")
                        }
                        this.state = e
                    }
                    reveal() {
                        this.setState("showing-form")
                    }
                }, "SudoPasswordElement");
                oe([R.Lj], tt.prototype, "state", 2), oe([R.fA], tt.prototype, "revealer", 2), oe([R.fA], tt.prototype, "form", 2), oe([R.fA], tt.prototype, "passwordField", 2), tt = oe([R.Ih], tt);
                let un = i(class extends HTMLElement {
                    connectedCallback() {
                        var e;
                        (e = this.webauthnGet) == null || e.addEventListener("webauthn-get-prompt", () => {
                            this.sudoPassword.setState("showing-revealer")
                        }), this.sudoPassword.addEventListener("sudo-password-showing-form", () => {
                            var t;
                            (t = this.webauthnGet) == null || t.setState("ready")
                        })
                    }
                }, "SudoAuthElement");
                oe([R.fA], un.prototype, "webauthnGet", 2), oe([R.fA], un.prototype, "sudoPassword", 2), un = oe([R.Ih], un);
                let So = 0;

                function fd() {
                    if (!document.hasFocus()) return;
                    const e = document.querySelector(".js-timeline-marker-form");
                    e && e instanceof HTMLFormElement && (0, Z.Bt)(e)
                }
                i(fd, "markThreadAsRead");
                const dn = "IntersectionObserver" in window ? new IntersectionObserver(function(e) {
                    for (const t of e) t.isIntersecting && Ur(t.target)
                }, {
                    root: null,
                    rootMargin: "0px",
                    threshold: 1
                }) : null;
                (0, v.N7)(".js-unread-item", {
                    constructor: HTMLElement,
                    add(e) {
                        So++, dn && dn.observe(e)
                    },
                    remove(e) {
                        So--, dn && dn.unobserve(e), So === 0 && fd()
                    }
                });

                function Ur(e) {
                    e.classList.remove("js-unread-item", "unread-item")
                }
                i(Ur, "clearUnread"), (0, v.N7)(".js-discussion[data-channel-target]", {
                    subscribe: e => (0, H.RB)(e, "socket:message", function(t) {
                        const n = t.target,
                            o = t.detail.data;
                        if (n.getAttribute("data-channel-target") === o.gid)
                            for (const s of document.querySelectorAll(".js-unread-item")) Ur(s)
                    })
                });
                let fn = 0;
                const Wr = /^\(\d+\)\s+/;

                function zr() {
                    const e = fn ? `(${fn}) ` : "";
                    document.title.match(Wr) ? document.title = document.title.replace(Wr, e) : document.title = `${e}${document.title}`
                }
                i(zr, "updateTitle"), (0, v.N7)(".js-unread-item", {
                    add() {
                        fn++, zr()
                    },
                    remove() {
                        fn--, zr()
                    }
                }), (0, v.N7)(".js-socket-channel.js-updatable-content", {
                    subscribe: e => (0, H.RB)(e, "socket:message", function(t) {
                        const {
                            gid: n,
                            wait: o
                        } = t.detail.data, s = t.target, r = n ? md(s, n) : s;
                        r && setTimeout(Be.x0, o || 0, r)
                    })
                });

                function md(e, t) {
                    if (e.getAttribute("data-gid") === t) return e;
                    for (const n of e.querySelectorAll("[data-url][data-gid]"))
                        if (n.getAttribute("data-gid") === t) return n;
                    return null
                }
                i(md, "findByGid");
                async function hd() {
                    if (!(!history.state || !history.state.staleRecords)) {
                        await Ee.x;
                        for (const e in history.state.staleRecords)
                            for (const t of document.querySelectorAll(`.js-updatable-content [data-url='${e}'], .js-updatable-content[data-url='${e}']`)) {
                                const n = history.state.staleRecords[e];
                                t instanceof HTMLElement && (0, Be.Of)(t, n, !0)
                            }(0, lt.lO)(null, "", location.href)
                    }
                }
                i(hd, "reapplyPreviouslyUpdatedContent"), window.addEventListener("pagehide", Be.z8);
                try {
                    hd()
                } catch {}(0, f.on)("upload:setup", ".js-upload-avatar-image", function(e) {
                    const {
                        form: t
                    } = e.detail, n = e.currentTarget.getAttribute("data-alambic-organization"), o = e.currentTarget.getAttribute("data-alambic-owner-type"), s = e.currentTarget.getAttribute("data-alambic-owner-id");
                    n && t.append("organization_id", n), o && t.append("owner_type", o), s && t.append("owner_id", s)
                }), (0, f.on)("upload:complete", ".js-upload-avatar-image", function(e) {
                    const {
                        attachment: t
                    } = e.detail, n = `/settings/avatars/${t.id}`;
                    (0, Me.W)({
                        content: (0, ie.a)(document, n)
                    })
                });
                var Vr = u(14037);

                function mn() {
                    if (document.querySelector(":target")) return;
                    const e = (0, Vr.$z)(location.hash).toLowerCase(),
                        t = (0, Vr.Q)(document, `user-content-${e}`);
                    t && (0, Kn.zT)(t)
                }
                i(mn, "hashchange"), window.addEventListener("hashchange", mn), document.addEventListener("pjax:success", mn), async function() {
                    await Ee.x, mn()
                }(), (0, f.on)("click", "a[href]", function(e) {
                    const {
                        currentTarget: t
                    } = e;
                    t instanceof HTMLAnchorElement && t.href === location.href && location.hash.length > 1 && setTimeout(function() {
                        e.defaultPrevented || mn()
                    })
                });
                async function pd(e) {
                    const t = e.currentTarget,
                        {
                            init: n
                        } = await u.e(5691).then(u.bind(u, 35691));
                    n(t)
                }
                i(pd, "user_status_loader_load"), (0, v.N7)(".js-user-status-container", {
                    subscribe: e => (0, H.RB)(e, "click", pd, {
                        once: !0
                    })
                });
                var hn = u(78694);

                function gd(e, t) {
                    const n = e.querySelector(".js-user-list-base");
                    n && (n.textContent = t || n.getAttribute("data-generic-message"), n.hidden = !1)
                }
                i(gd, "setFlashError");

                function Kr(e, t) {
                    const o = (t || e).querySelectorAll(".js-user-list-error");
                    for (const a of o) a.hidden = !0;
                    const s = t ? [t] : e.querySelectorAll(".errored.js-user-list-input-container");
                    for (const a of s) a.classList.remove("errored");
                    const r = e.querySelector(".js-user-list-base");
                    r && (r.hidden = !0)
                }
                i(Kr, "resetValidation"), (0, K.AC)(".js-user-list-form", async function(e, t) {
                    var n;
                    Kr(e);
                    const o = e.querySelector("[data-submitting-message]"),
                        s = o == null ? void 0 : o.textContent;
                    o && (o.textContent = o.getAttribute("data-submitting-message"), o.disabled = !0);
                    for (const r of e.querySelectorAll(".js-user-list-input")) r.disabled = !0;
                    try {
                        const r = await t.html();
                        (0, f.f)(e, "user-list-form:success", r.html)
                    } catch (r) {
                        if (((n = r.response) == null ? void 0 : n.status) === 422) e.replaceWith(r.response.html);
                        else {
                            gd(e), o && (s && (o.textContent = s), o.disabled = !1);
                            for (const a of e.querySelectorAll(".js-user-list-input")) a.disabled = !1
                        }
                    }
                }), (0, f.on)("user-list-form:success", ".js-follow-list", e => {
                    const t = e.detail,
                        n = t instanceof DocumentFragment ? t.querySelector(".js-target-url") : null;
                    (n == null ? void 0 : n.textContent) ? location.href = n.textContent: location.reload()
                });

                function Xr(e) {
                    if (!(e.currentTarget instanceof HTMLElement)) return;
                    const t = e.currentTarget.closest(".js-user-list-form"),
                        n = e.currentTarget.closest(".js-user-list-input-container");
                    t && n && Kr(t, n)
                }
                i(Xr, "clearErrorsFromInput"), (0, X.q6)(".js-user-list-form input", Xr), (0, X.q6)(".js-user-list-form textarea", Xr), (0, f.on)("auto-check-error", ".js-user-list-form input", function(e) {
                    const t = e.currentTarget.closest(".js-user-list-input-container"),
                        n = t == null ? void 0 : t.querySelector(".js-user-list-error");
                    n && (n.hidden = !1)
                });

                function bd(e) {
                    var t;
                    const n = new Map;
                    for (const o of e) {
                        const s = (t = o.querySelector(".js-user-lists-create-trigger")) == null ? void 0 : t.getAttribute("data-repository-id");
                        if (s) {
                            const r = n.get(s);
                            r ? r.push(o) : n.set(s, [o])
                        }
                    }
                    return n
                }
                i(bd, "groupRootsByRepositoryId");
                async function yd(e, t, n) {
                    const o = new FormData;
                    o.set("authenticity_token", t);
                    for (const a of n) o.append("repository_ids[]", a);
                    const s = await fetch(e, {
                            method: "POST",
                            body: o,
                            headers: {
                                Accept: "application/json",
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        }),
                        r = new Map;
                    if (s.ok) {
                        const a = await s.json();
                        for (const c in a) r.set(c, (0, ve.r)(document, a[c]))
                    }
                    return r
                }
                i(yd, "requestMenuBatchRender");

                function vd(e, t) {
                    for (const [n, o] of e.entries()) {
                        const s = t.get(n) || [];
                        for (const r of s) r.replaceWith(s.length === 1 ? o : o.cloneNode(!0))
                    }
                }
                i(vd, "replaceUserListMenuRoots");
                async function Gr() {
                    var e;
                    const t = document.querySelectorAll(".js-user-list-menu-content-root");
                    if (t.length === 0) return;
                    const n = t[0].getAttribute("data-batch-update-url");
                    if (!n) return;
                    const o = (e = t[0].querySelector(".js-user-list-batch-update-csrf")) == null ? void 0 : e.value;
                    if (!o) return;
                    const s = bd(t),
                        r = s.keys(),
                        a = await yd(n, o, r);
                    a.size > 0 && vd(a, s)
                }
                i(Gr, "updateAllUserListMenus");

                function wd(e) {
                    const t = new Promise((n, o) => {
                        e.addEventListener("user-list-menu-form:success", () => n()), e.addEventListener("user-list-menu-form:error", s => o(s))
                    });
                    return (0, Z.Bt)(e), t
                }
                i(wd, "requestUserListMenuFormSubmit");

                function Ed(e) {
                    const t = e.target;
                    if (!(t instanceof HTMLDetailsElement) || t.hasAttribute("open")) return;
                    const n = t.querySelector(".js-user-list-menu-form");
                    n && (0, hn.T)(n) && (0, Z.Bt)(n);
                    const o = t.querySelector(".js-user-list-create-trigger-text");
                    o && (o.textContent = "")
                }
                i(Ed, "submitUserListFormOnToggle"), (0, f.on)("toggle", ".js-user-list-menu", Ed, {
                    capture: !0
                }), (0, X.q6)(".js-user-lists-menu-filter", e => {
                    const t = e.currentTarget,
                        n = t.value.trim(),
                        o = t.closest(".js-user-list-menu-content-root"),
                        s = o == null ? void 0 : o.querySelector(".js-user-list-create-trigger-text");
                    !s || (s.textContent = n ? `"${n}"` : "")
                }), (0, K.AC)(".js-user-list-menu-form", async function(e, t) {
                    let n;
                    try {
                        n = await t.json()
                    } catch (s) {
                        (0, ct.v)(), (0, f.f)(e, "user-list-menu-form:error", s);
                        return
                    }
                    if (n.json.didStar) {
                        const s = e.closest(".js-toggler-container");
                        s && s.classList.add("on");
                        const r = n.json.starCount;
                        if (r) {
                            const a = e.closest(".js-social-container");
                            a && vr(a, r)
                        }
                    }
                    const o = e.closest(".js-user-list-menu-content-root[data-update-after-submit]");
                    if (o)
                        for (const s of e.querySelectorAll(".js-user-list-menu-item")) s.checked = s.defaultChecked;
                    n.json.didCreate ? await Gr() : o && await (0, Be.x0)(o), (0, f.f)(e, "user-list-menu-form:success")
                }), (0, f.on)("click", ".js-user-list-delete-confirmation-trigger", e => {
                    const {
                        currentTarget: t
                    } = e, n = t.getAttribute("data-template-id");
                    if (!n) return;
                    const o = document.getElementById(n);
                    if (!o || !(o instanceof HTMLTemplateElement)) return;
                    const s = t.closest(".js-edit-user-list-dialog");
                    s && (s.open = !1);
                    const r = o.content.cloneNode(!0),
                        a = o.getAttribute("data-labelledby");
                    (0, Me.W)({
                        content: r,
                        labelledBy: a
                    })
                }), (0, f.on)("click", ".js-user-lists-create-trigger", async function(e) {
                    const {
                        currentTarget: t
                    } = e, n = document.querySelector(".js-user-list-create-dialog-template"), o = e.currentTarget.getAttribute("data-repository-id"), s = t.closest(".js-user-list-menu-content-root"), r = s == null ? void 0 : s.querySelector(".js-user-lists-menu-filter"), a = r == null ? void 0 : r.value.trim();
                    if (!n || !(n instanceof HTMLTemplateElement) || !o) {
                        t instanceof HTMLButtonElement && (t.disabled = !0);
                        return
                    }
                    const c = n.getAttribute("data-label");
                    if (s && (0, hn.T)(s)) {
                        const p = s.querySelector(".js-user-list-menu-form");
                        p && await wd(p)
                    }
                    const l = new we.R(n, {
                            repositoryId: o,
                            placeholderName: a
                        }),
                        d = await (0, Me.W)({
                            content: l,
                            label: c
                        });
                    d.addEventListener("user-list-form:success", async () => {
                        await Gr();
                        const p = d.closest("details");
                        p && (p.open = !1)
                    })
                });
                var Ld = Object.defineProperty,
                    Sd = Object.getOwnPropertyDescriptor,
                    pn = i((e, t, n, o) => {
                        for (var s = o > 1 ? void 0 : o ? Sd(t, n) : t, r = e.length - 1, a; r >= 0; r--)(a = e[r]) && (s = (o ? a(t, n, s) : a(s)) || s);
                        return o && s && Ld(t, n, s), s
                    }, "visible_password_element_decorateClass");
                let Et = i(class extends HTMLElement {
                    show() {
                        this.input.type = "text", this.input.focus(), this.showButton.hidden = !0, this.hideButton.hidden = !1
                    }
                    hide() {
                        this.input.type = "password", this.input.focus(), this.hideButton.hidden = !0, this.showButton.hidden = !1
                    }
                }, "VisiblePasswordElement");
                pn([R.fA], Et.prototype, "input", 2), pn([R.fA], Et.prototype, "showButton", 2), pn([R.fA], Et.prototype, "hideButton", 2), Et = pn([R.Ih], Et), (0, v.N7)("[data-warn-unsaved-changes]", {
                    add(e) {
                        e.addEventListener("input", gn), e.addEventListener("change", gn), e.addEventListener("submit", Lt);
                        const t = e.closest("details-dialog");
                        t && (t.closest("details").addEventListener("toggle", Zr), t.addEventListener("details-dialog-close", Jr))
                    },
                    remove(e) {
                        e.removeEventListener("input", gn), e.removeEventListener("change", gn), e.removeEventListener("submit", Lt);
                        const t = e.closest("details-dialog");
                        t && (t.closest("details").removeEventListener("toggle", Zr), t.removeEventListener("details-dialog-close", Jr), Lt())
                    }
                });

                function gn(e) {
                    const t = e.currentTarget;
                    (0, hn.T)(t) ? jd(t): Lt()
                }
                i(gn, "prepareUnsavedChangesWarning");

                function jd(e) {
                    const t = e.getAttribute("data-warn-unsaved-changes") || "Changes you made may not be saved.";
                    window.onbeforeunload = function(n) {
                        return n.returnValue = t, t
                    }
                }
                i(jd, "enableSaveChangesReminder");

                function Lt() {
                    window.onbeforeunload = null
                }
                i(Lt, "disableSaveChangesReminder");

                function Zr({
                    currentTarget: e
                }) {
                    e.hasAttribute("open") || Lt()
                }
                i(Zr, "disableSaveChangesReminderOnClosedDialogs");

                function Jr(e) {
                    const t = e.currentTarget;
                    if (!t.closest("details[open]")) return;
                    let o = !0;
                    const s = t.querySelectorAll("form[data-warn-unsaved-changes]");
                    for (const r of s)
                        if ((0, hn.T)(r)) {
                            const a = r.getAttribute("data-warn-unsaved-changes");
                            o = confirm(a);
                            break
                        }
                    o || e.preventDefault()
                }
                i(Jr, "promptOnDialogClosing"), (0, v.N7)(".will-transition-once", {
                    constructor: HTMLElement,
                    subscribe: e => (0, H.RB)(e, "transitionend", Td)
                });

                function Td(e) {
                    e.target.classList.remove("will-transition-once")
                }
                i(Td, "onTransitionEnd");

                function Ad(e, t = 0) {
                    const n = e.getBoundingClientRect(),
                        o = n.top - t,
                        s = n.bottom - window.innerHeight + t;
                    o < 0 ? window.scrollBy(0, o) : s > 0 && window.scrollBy(0, s)
                }
                i(Ad, "adjustViewport"), (0, f.on)("click", ".js-video-play, .js-video-close", function(e) {
                    const n = e.currentTarget.closest(".js-video-container"),
                        o = n.querySelector(".js-video-iframe");
                    n.tagName.toLowerCase() === "details" && n.addEventListener("details-dialog-close", function() {
                        o.removeAttribute("src"), window.setTimeout(function() {
                            n.classList.remove("is-expanded")
                        }, 10)
                    }), n.classList.contains("is-expanded") ? (o.removeAttribute("src"), n.classList.remove("is-expanded")) : (o.src = o.getAttribute("data-src") || "", n.classList.add("is-expanded")), Ad(o, 20)
                });
                async function Cd(e) {
                    const t = e.currentTarget,
                        n = t.getAttribute("data-url");
                    if (!n || kd(t)) return;
                    const o = t.getAttribute("data-id") || "",
                        s = t.textContent,
                        r = document.querySelectorAll(`.js-issue-link[data-id='${o}']`);
                    for (const a of r) a.removeAttribute("data-url");
                    try {
                        const a = `${n}/title`,
                            c = await fetch(a, {
                                headers: {
                                    "X-Requested-With": "XMLHttpRequest",
                                    Accept: "application/json"
                                }
                            });
                        if (!c.ok) {
                            const d = new Error,
                                p = c.statusText ? ` ${c.statusText}` : "";
                            throw d.message = `HTTP ${c.status}${p}`, d
                        }
                        const l = await c.json();
                        Yr(r, `${s}, ${l.title}`)
                    } catch (a) {
                        const c = (a.response != null ? a.response.status : void 0) || 500,
                            l = (() => {
                                switch (c) {
                                    case 404:
                                        return t.getAttribute("data-permission-text");
                                    default:
                                        return t.getAttribute("data-error-text")
                                }
                            })();
                        Yr(r, l || "")
                    }
                }
                i(Cd, "issueLabel");

                function Yr(e, t) {
                    for (const n of e) n instanceof HTMLElement && (n.classList.add("tooltipped", "tooltipped-ne"), n.setAttribute("aria-label", t))
                }
                i(Yr, "setLabel");

                function kd(e) {
                    switch (e.getAttribute("data-hovercard-type")) {
                        case "issue":
                        case "pull_request":
                            return !!e.closest("[data-issue-and-pr-hovercards-enabled]");
                        case "discussion":
                            return !!e.closest("[data-discussion-hovercards-enabled]");
                        default:
                            return !1
                    }
                }
                i(kd, "isHovercardEnabled"), (0, v.N7)(".js-issue-link", {
                    subscribe: e => (0, H.RB)(e, "mouseenter", Cd)
                });
                var xd = u(12085),
                    Ue = u.n(xd);

                function jo() {
                    return [Math.floor(Math.random() * (255 - 0) + 0), Math.floor(Math.random() * (255 - 0) + 0), Math.floor(Math.random() * (255 - 0) + 0)]
                }
                i(jo, "randomRGBColor");

                function St(e, t) {
                    const n = Ue().rgb.hsl(t);
                    e.style.setProperty("--label-r", t[0].toString()), e.style.setProperty("--label-g", t[1].toString()), e.style.setProperty("--label-b", t[2].toString()), e.style.setProperty("--label-h", n[0].toString()), e.style.setProperty("--label-s", n[1].toString()), e.style.setProperty("--label-l", n[2].toString())
                }
                i(St, "setColorSwatch");

                function To(e, t) {
                    e.blur();
                    const n = e.closest("form"),
                        o = n.querySelector(".js-new-label-color-input");
                    (0, Z.Se)(o, `#${Ue().rgb.hex(t)}`);
                    const s = n.querySelector(".js-new-label-color");
                    St(s, t)
                }
                i(To, "setInputColorFromButton");

                function Md(e, t) {
                    e.closest(".js-label-error-container").classList.add("errored"), e.textContent = t, e.hidden = !1
                }
                i(Md, "addErrorToField");

                function qd(e) {
                    e.closest(".js-label-error-container").classList.remove("errored"), e.hidden = !0
                }
                i(qd, "removeErrorFromField");

                function nt(e, t, n) {
                    const o = t.querySelector(e);
                    !o || (n ? Md(o, n[0]) : qd(o))
                }
                i(nt, "showOrHideLabelError");

                function Ao(e, t) {
                    nt(".js-label-name-error", e, t.name), nt(".js-label-description-error", e, t.description), nt(".js-label-color-error", e, t.color)
                }
                i(Ao, "showLabelErrors");

                function We(e) {
                    nt(".js-label-name-error", e, null), nt(".js-label-description-error", e, null), nt(".js-label-color-error", e, null)
                }
                i(We, "hideLabelErrors");

                function Pd(e, t, n, o, s) {
                    const r = new URL(`${e}${encodeURIComponent(t)}`, window.location.origin),
                        a = new URLSearchParams(r.search.slice(1));
                    return a.append("color", n), o && a.append("description", o), s && a.append("id", s), r.search = a.toString(), r.toString()
                }
                i(Pd, "labelPreviewUrl");

                function Rd(e) {
                    let t = null;
                    const n = e.querySelector(".js-new-label-description-input");
                    return n instanceof HTMLInputElement && n.value.trim().length > 0 && (t = n.value.trim()), t
                }
                i(Rd, "labelDescriptionFrom");

                function Id(e) {
                    const t = e.querySelector(".js-new-label-color-input");
                    return t.checkValidity() ? t.value.trim().replace(/^#/, "") : "ededed"
                }
                i(Id, "labelColorFrom");

                function Nd(e, t) {
                    let o = e.querySelector(".js-new-label-name-input").value.trim();
                    return o.length < 1 && (o = t.getAttribute("data-default-name")), o
                }
                i(Nd, "labelNameFrom");
                async function ot(e) {
                    const t = e.closest(".js-label-preview-container");
                    if (!t) return;
                    const n = e.closest(".js-label-form"),
                        o = n.querySelector(".js-new-label-error"),
                        s = n.getAttribute("data-label-id"),
                        r = t.querySelector(".js-label-preview"),
                        a = Nd(n, r);
                    if (!n.checkValidity() && a !== "Label preview") return;
                    const c = Id(n),
                        l = Rd(n),
                        d = r.getAttribute("data-url-template"),
                        p = Pd(d, a, c, l, s);
                    if (t.hasAttribute("data-last-preview-url")) {
                        const T = t.getAttribute("data-last-preview-url");
                        if (p === T) return
                    }
                    let j;
                    try {
                        j = await (0, ie.a)(document, p)
                    } catch (T) {
                        const k = await T.response.json();
                        Ao(n, k), o && (o.textContent = k.message, o.hidden = !1);
                        return
                    }
                    o && (o.textContent = "", o.hidden = !0), We(n), r.innerHTML = "", r.appendChild(j), t.setAttribute("data-last-preview-url", p)
                }
                i(ot, "updateLabelPreview");

                function Dd(e) {
                    ot(e.target)
                }
                i(Dd, "onLabelFormInputChange");

                function Qr(e, t) {
                    e.closest(".js-details-container").classList.toggle("is-empty", t)
                }
                i(Qr, "toggleBlankSlate");

                function ei(e) {
                    const t = document.querySelector(".js-labels-count"),
                        o = Number(t.textContent) + e;
                    t.textContent = o.toString();
                    const s = document.querySelector(".js-labels-label");
                    return s.textContent = s.getAttribute(o === 1 ? "data-singular-string" : "data-plural-string"), o
                }
                i(ei, "updateCount"), (0, X.q6)(".js-label-filter-field", function(e) {
                    const t = e.target,
                        o = t.closest("details-menu").querySelector(".js-new-label-name");
                    if (!o) return;
                    const s = t.value.trim();
                    o.textContent = s
                }), (0, f.on)("filterable:change", ".js-filterable-issue-labels", function(e) {
                    const t = e.currentTarget.closest("details-menu"),
                        n = t.querySelector(".js-add-label-button");
                    if (!n) return;
                    const s = e.detail.inputField.value.trim().toLowerCase();
                    let r = !1;
                    for (const a of t.querySelectorAll("input[data-label-name]"))
                        if ((a.getAttribute("data-label-name") || "").toLowerCase() === s) {
                            r = !0;
                            break
                        }
                    n.hidden = s.length === 0 || r
                }), (0, X.ZG)(".js-new-label-color-input", function(e) {
                    const n = e.closest("form").querySelector(".js-new-label-swatches");
                    n.hidden = !1, e.addEventListener("blur", function() {
                        n.hidden = !0
                    }, {
                        once: !0
                    })
                }), (0, X.q6)(".js-new-label-color-input", function(e) {
                    const t = e.target;
                    let n = t.value.trim();
                    if (!(n.length < 1))
                        if (n.indexOf("#") !== 0 && (n = `#${n}`, t.value = n), t.checkValidity()) {
                            t.classList.remove("color-fg-danger");
                            const s = t.closest("form").querySelector(".js-new-label-color");
                            St(s, Ue().hex.rgb(n))
                        } else t.classList.add("color-fg-danger")
                }), (0, X.w4)("keyup", ".js-new-label-color-input", function(e) {
                    const t = e.target;
                    let n = t.value.trim();
                    if (n.indexOf("#") !== 0 && (n = `#${n}`, t.value = n), t.checkValidity()) {
                        const r = t.closest("form").querySelector(".js-new-label-color");
                        St(r, Ue().hex.rgb(n))
                    }(0, f.f)(t, "change", !1);
                    const o = t.closest("form");
                    We(o)
                }), (0, X.w4)("keyup", ".js-new-label-description-input", function(e) {
                    const n = e.target.form;
                    We(n)
                }), (0, X.w4)("keyup", ".js-new-label-color-input", function(e) {
                    const n = e.target.form;
                    We(n)
                }), (0, f.on)("click", ".js-new-label-color", async function(e) {
                    const t = e.currentTarget,
                        n = jo();
                    To(t, n), ot(t)
                }), (0, f.on)("mousedown", ".js-new-label-color-swatch", function(e) {
                    const t = e.currentTarget,
                        n = t.getAttribute("data-color");
                    To(t, Ue().hex.rgb(n)), ot(t);
                    const o = t.closest(".js-new-label-swatches");
                    o.hidden = !0
                }), (0, f.on)("toggle", ".js-new-label-modal", function(e) {
                    e.target.hasAttribute("open") && ti(e.target)
                }, {
                    capture: !0
                });
                async function ti(e) {
                    const t = e.querySelector(".js-new-label-name-input");
                    if (!t) return;
                    const n = e.querySelector(".js-new-label-color-input"),
                        o = jo(),
                        s = `#${Ue().rgb.hex(o)}`;
                    n.value = s;
                    const r = e.querySelector(".js-new-label-color");
                    St(r, o);
                    const c = document.querySelector(".js-new-label-name").textContent;
                    (0, Z.Se)(t, c), (0, Pn.OD)(t), ot(r)
                }
                i(ti, "initLabelModal"), (0, K.AC)(".js-new-label-modal-form", async function(e, t) {
                    const n = e.querySelector(".js-new-label-error");
                    let o;
                    try {
                        o = await t.html()
                    } catch (c) {
                        const l = c.response.json;
                        n.textContent = l.message, n.hidden = !1
                    }
                    if (!o) return;
                    n.hidden = !0, document.querySelector(".js-new-label-modal").removeAttribute("open");
                    const s = document.querySelector(".js-filterable-issue-labels"),
                        r = o.html.querySelector("input");
                    s.prepend(o.html), r && r.dispatchEvent(new Event("change", {
                        bubbles: !0
                    }));
                    const a = document.querySelector(".js-label-filter-field");
                    a.value = a.defaultValue, a.focus()
                }), (0, f.on)("click", ".js-edit-label-cancel", function(e) {
                    const t = e.target.closest("form");
                    We(t), t.reset();
                    const n = t.querySelector(".js-new-label-color-input"),
                        o = n.value,
                        s = t.querySelector(".js-new-label-color");
                    St(s, Ue().hex.rgb(o)), (0, Pn.Qc)(t), ot(n);
                    const r = e.currentTarget.closest(".js-labels-list-item");
                    if (r) {
                        r.querySelector(".js-update-label").classList.add("d-none");
                        const c = r.querySelector(".js-label-preview");
                        c && (c.classList.add("d-none"), r.querySelector(".js-label-link").classList.remove("d-none"));
                        const l = r.querySelectorAll(".js-hide-on-label-edit");
                        for (const d of l) d.hidden = !d.hidden
                    }
                }), (0, K.AC)(".js-update-label", async function(e, t) {
                    let n;
                    try {
                        n = await t.html()
                    } catch (s) {
                        const r = s.response.json;
                        Ao(e, r);
                        return
                    }
                    We(e), e.closest(".js-labels-list-item").replaceWith(n.html)
                }), (0, K.AC)(".js-create-label", async function(e, t) {
                    let n;
                    try {
                        n = await t.html()
                    } catch (a) {
                        const c = a.response.json;
                        Ao(e, c);
                        return
                    }
                    e.reset(), We(e), document.querySelector(".js-label-list").prepend(n.html), ei(1), Qr(e, !1);
                    const o = e.querySelector(".js-new-label-color"),
                        s = jo();
                    To(o, s), ot(e.querySelector(".js-new-label-name-input")), (0, Pn.Qc)(e);
                    const r = e.closest(".js-details-container");
                    r instanceof HTMLElement && (0, $n.Qp)(r)
                }), (0, f.on)("click", ".js-details-target-new-label", function() {
                    document.querySelector(".js-create-label").querySelector(".js-new-label-name-input").focus()
                }), (0, f.on)("click", ".js-edit-label", function(e) {
                    const t = e.currentTarget.closest(".js-labels-list-item"),
                        n = t.querySelector(".js-update-label");
                    n.classList.remove("d-none"), n.querySelector(".js-new-label-name-input").focus();
                    const s = t.querySelector(".js-label-preview");
                    s && (s.classList.remove("d-none"), t.querySelector(".js-label-link").classList.add("d-none"));
                    const r = t.querySelectorAll(".js-hide-on-label-edit");
                    for (const a of r) a.hidden = !a.hidden
                }), (0, K.AC)(".js-delete-label", async function(e, t) {
                    const n = e.closest(".js-labels-list-item");
                    n.querySelector(".js-label-delete-spinner").hidden = !1, await t.text();
                    const o = ei(-1);
                    Qr(e, o === 0), n.remove()
                });
                const bn = (0, Ze.D)(Dd, 500);
                (0, f.on)("suggester:complete", ".js-new-label-name-input", bn), (0, X.q6)(".js-new-label-name-input", bn), (0, X.q6)(".js-new-label-description-input", bn), (0, X.q6)(".js-new-label-color-input", bn), (0, X.w4)("keypress", ".js-new-label-name-input", function(e) {
                    const t = e.target,
                        n = parseInt(t.getAttribute("data-maxlength"));
                    (0, Ye.rq)(t.value) >= n && e.preventDefault()
                }), (0, f.on)("click", ".js-issues-label-select-menu-item", function(e) {
                    !e.altKey && !e.shiftKey || (e.preventDefault(), e.stopPropagation(), e.altKey && (window.location.href = e.currentTarget.getAttribute("data-excluded-url")), e.shiftKey && (window.location.href = e.currentTarget.getAttribute("data-included-url")))
                }), (0, X.w4)("keydown", ".js-issues-label-select-menu-item", function(e) {
                    if (e.key !== "Enter" || !e.altKey && !e.shiftKey) return;
                    const t = e.currentTarget;
                    e.preventDefault(), e.stopPropagation(), t instanceof HTMLAnchorElement && (e.altKey && (window.location.href = t.getAttribute("data-excluded-url")), e.shiftKey && (window.location.href = t.getAttribute("data-included-url")))
                }), (0, f.on)("click", ".js-open-label-creation-modal", async function(e) {
                    e.stopImmediatePropagation();
                    const t = await (0, Me.W)({
                        content: document.querySelector(".js-label-creation-template").content.cloneNode(!0),
                        detailsClass: "js-new-label-modal"
                    });
                    ti(t)
                }, {
                    capture: !0
                }), (0, f.on)("change", ".js-thread-notification-setting", Co), (0, f.on)("change", ".js-custom-thread-notification-option", Co), (0, f.on)("reset", ".js-custom-thread-settings-form", Co);

                function Co() {
                    const e = document.querySelector(".js-reveal-custom-thread-settings").checked,
                        t = !document.querySelector(".js-custom-thread-notification-option:checked"),
                        n = document.querySelector(".js-custom-thread-settings"),
                        o = document.querySelector("[data-custom-option-required-text]"),
                        s = e && t ? o.getAttribute("data-custom-option-required-text") : "";
                    o.setCustomValidity(s), n.hidden = !e
                }
                i(Co, "toggleEventSettings");
                var Hd = Object.defineProperty,
                    Od = Object.getOwnPropertyDescriptor,
                    ni = i((e, t, n, o) => {
                        for (var s = o > 1 ? void 0 : o ? Od(t, n) : t, r = e.length - 1, a; r >= 0; r--)(a = e[r]) && (s = (o ? a(t, n, s) : a(s)) || s);
                        return o && s && Hd(t, n, s), s
                    }, "sidebar_widget_decorateClass");
                let ko = i(class extends HTMLElement {
                    get activeClass() {
                        return this.getAttribute("active-class") || "collapsible-sidebar-widget-active"
                    }
                    get loadingClass() {
                        return this.getAttribute("loading-class") || "collapsible-sidebar-widget-loading"
                    }
                    get url() {
                        return this.getAttribute("url") || ""
                    }
                    get isOpen() {
                        return this.hasAttribute("open")
                    }
                    set isOpen(e) {
                        e ? this.setAttribute("open", "") : this.removeAttribute("open")
                    }
                    onKeyDown(e) {
                        if (e.code === "Enter" || e.code === "Space") return e.preventDefault(), this.load()
                    }
                    onMouseDown(e) {
                        return e.preventDefault(), this.load()
                    }
                    load() {
                        return this.pendingRequest ? this.pendingRequest.abort() : this.collapsible.hasAttribute("loaded") ? this.isOpen ? this.setClose() : this.setOpen() : (this.setLoading(), this.updateCollapsible())
                    }
                    setLoading() {
                        this.classList.add(this.loadingClass), this.classList.remove(this.activeClass)
                    }
                    setOpen() {
                        this.classList.add(this.activeClass), this.classList.remove(this.loadingClass), this.isOpen = !0
                    }
                    setClose() {
                        this.classList.remove(this.activeClass), this.classList.remove(this.loadingClass), this.isOpen = !1
                    }
                    handleAbort() {
                        this.pendingRequest = null, this.setClose()
                    }
                    async updateCollapsible() {
                        var e;
                        try {
                            this.pendingRequest = new AbortController, this.pendingRequest.signal.addEventListener("abort", () => this.handleAbort());
                            const t = await fetch(this.url, {
                                signal: (e = this.pendingRequest) == null ? void 0 : e.signal,
                                headers: {
                                    Accept: "text/html",
                                    "X-Requested-With": "XMLHttpRequest"
                                }
                            });
                            if (this.pendingRequest = null, !t.ok) return this.setClose();
                            const n = await t.text();
                            this.collapsible.innerHTML = n, this.collapsible.setAttribute("loaded", ""), this.setOpen()
                        } catch {
                            return this.pendingRequest = null, this.setClose()
                        }
                    }
                }, "CollapsibleSidebarWidgetElement");
                ni([R.fA], ko.prototype, "collapsible", 2), ko = ni([R.Ih], ko);
                var Bd = Object.defineProperty,
                    _d = Object.getOwnPropertyDescriptor,
                    Te = i((e, t, n, o) => {
                        for (var s = o > 1 ? void 0 : o ? _d(t, n) : t, r = e.length - 1, a; r >= 0; r--)(a = e[r]) && (s = (o ? a(t, n, s) : a(s)) || s);
                        return o && s && Bd(t, n, s), s
                    }, "sidebar_memex_input_decorateClass");
                let ge = i(class extends HTMLElement {
                    constructor() {
                        super(...arguments);
                        this.url = "", this.csrf = "", this.instrument = "", this.column = 1
                    }
                    get isDisabled() {
                        var e;
                        return (e = this.read) == null ? void 0 : e.hasAttribute("disabled")
                    }
                    set hasErrored(e) {
                        e ? this.setAttribute("errored", "") : this.removeAttribute("errored")
                    }
                    set disabled(e) {
                        e ? this.setAttribute("disabled", "") : this.removeAttribute("disabled")
                    }
                    get hasExpanded() {
                        return this.read.getAttribute("aria-expanded") === "true"
                    }
                    connectedCallback() {
                        var e, t;
                        this.disabled = (t = (e = this.read) == null ? void 0 : e.disabled) != null ? t : !0, this.querySelector("details") !== null && this.classList.toggle("no-pointer")
                    }
                    handleDetailsSelect(e) {
                        var t;
                        const n = e,
                            o = e.target,
                            s = (t = n.detail) == null ? void 0 : t.relatedTarget,
                            r = o.closest("details"),
                            a = r == null ? void 0 : r.querySelector("[data-menu-button]");
                        if (s.getAttribute("aria-checked") === "true") {
                            s.setAttribute("aria-checked", "false"), e.preventDefault();
                            for (const c of this.inputs)
                                if (s.contains(c)) {
                                    this.updateCell(c.name, ""), (a == null ? void 0 : a.innerHTML) && (a.innerHTML = c.placeholder);
                                    break
                                }
                            r == null || r.removeAttribute("open")
                        }
                    }
                    handleDetailsSelected(e) {
                        var t;
                        const o = (t = e.detail) == null ? void 0 : t.relatedTarget;
                        for (const s of this.inputs)
                            if (o.contains(s)) {
                                this.updateCell(s.name, s.value);
                                break
                            }
                    }
                    mouseDownFocus(e) {
                        !this.isDisabled || this.onFocus(e)
                    }
                    keyDownFocus(e) {
                        (e.code === "Enter" || e.code === "Space") && this.read !== document.activeElement && this.onFocus(e)
                    }
                    onChange(e) {
                        var t, n;
                        e.target.getAttribute("type") !== "date" && this.updateCell((t = this.read) == null ? void 0 : t.name, (n = this.read) == null ? void 0 : n.value)
                    }
                    onFocus(e) {
                        e.preventDefault(), this.disabled = !1, this.read.disabled = !1, this.read.focus()
                    }
                    onBlur(e) {
                        var t, n;
                        if (this.hasExpanded) {
                            e.preventDefault();
                            return
                        }
                        e.target.getAttribute("type") === "date" && this.updateCell((t = this.read) == null ? void 0 : t.name, (n = this.read) == null ? void 0 : n.value), this.read.disabled = !0, this.disabled = !0
                    }
                    onKeyDown(e) {
                        if (e.code === "Enter" || e.code === "Tab") {
                            if (e.preventDefault(), e.stopPropagation(), this.hasExpanded) return;
                            this.read.blur()
                        }
                    }
                    async updateCell(e = "", t = "") {
                        const n = new FormData;
                        n.set(e, t), n.set("ui", this.instrument);
                        for (const s of this.parameters) n.set(s.name, s.value);
                        const o = Intl.DateTimeFormat("en-US", {
                            month: "short",
                            day: "numeric",
                            year: "numeric",
                            timeZone: "UTC"
                        });
                        try {
                            if (this.write) {
                                const p = this.read.value,
                                    j = this.read.type === "date" && p ? o.format(Date.parse(p)) : p;
                                this.write.textContent = p ? j : this.read.placeholder
                            }
                            const s = await fetch(this.url, {
                                method: "PUT",
                                body: n,
                                headers: {
                                    Accept: "application/json",
                                    "X-Requested-With": "XMLHttpRequest",
                                    "Scoped-CSRF-Token": `${this.csrf}`
                                }
                            });
                            if (!s.ok) throw new Error("connection error");
                            if (!this.write) return;
                            const c = (await s.json()).memexProjectItem.memexProjectColumnValues.find(p => p.memexProjectColumnId === Number(this.column)).value,
                                l = this.read.type === "date" ? Date.parse(c.value) : c.html,
                                d = this.read.type === "date" && l ? o.format(l) : l;
                            this.write.innerHTML = t ? d : this.read.placeholder
                        } catch {
                            this.hasErrored = !0
                        }
                    }
                }, "SidebarMemexInputElement");
                Te([R.Lj], ge.prototype, "url", 2), Te([R.Lj], ge.prototype, "csrf", 2), Te([R.Lj], ge.prototype, "instrument", 2), Te([R.Lj], ge.prototype, "column", 2), Te([R.GO], ge.prototype, "inputs", 2), Te([R.fA], ge.prototype, "read", 2), Te([R.fA], ge.prototype, "write", 2), Te([R.GO], ge.prototype, "parameters", 2), ge = Te([R.Ih], ge);

                function jt(e, t = !1) {
                    (t || !zd(e)) && (e instanceof HTMLFormElement ? (0, Z.Bt)(e) : vn(e))
                }
                i(jt, "submitForm");

                function oi(e) {
                    const t = e.currentTarget,
                        n = t.closest(".js-issue-sidebar-form") || t.querySelector(".js-issue-sidebar-form");
                    jt(n)
                }
                i(oi, "submitOnMenuClose"), (0, f.on)("details-menu-selected", ".js-discussion-sidebar-menu", function(e) {
                    const t = e.detail.relatedTarget,
                        n = e.currentTarget,
                        o = t.closest(".js-issue-sidebar-form"),
                        s = n.hasAttribute("data-multiple");
                    if (t.hasAttribute("data-clear-assignees")) {
                        const r = n.querySelectorAll('input[name="issue[user_assignee_ids][]"]:checked');
                        for (const a of r) a.disabled = !1, a.checked = !1;
                        jt(o)
                    } else s ? n.closest("details").addEventListener("toggle", oi, {
                        once: !0
                    }) : jt(o)
                }, {
                    capture: !0
                });

                function $d(e, t) {
                    e.replaceWith((0, ve.r)(document, t))
                }
                i($d, "updateSidebar");

                function si(e) {
                    const t = document.querySelector(`[data-menu-trigger="${e}"]`);
                    t == null || t.focus()
                }
                i(si, "returnFocusToTrigger"), (0, K.AC)(".js-issue-sidebar-form", async function(e, t) {
                    var n;
                    const o = await t.html(),
                        s = e.closest(".js-discussion-sidebar-item"),
                        r = (n = s == null ? void 0 : s.querySelector(".select-menu")) == null ? void 0 : n.getAttribute("id");
                    s.replaceWith(o.html), r && si(r)
                }), (0, f.on)("click", "div.js-issue-sidebar-form .js-suggested-reviewer", function(e) {
                    const t = e.currentTarget,
                        n = t.closest(".js-issue-sidebar-form");
                    vn(n, "post", {
                        name: t.name,
                        value: t.value
                    }), e.preventDefault()
                }), (0, f.on)("click", "div.js-issue-sidebar-form .js-issue-assign-self", function(e) {
                    var t;
                    const n = e.currentTarget,
                        o = n.closest(".js-issue-sidebar-form");
                    vn(o, "post", {
                        name: n.name,
                        value: n.value
                    }), n.remove(), (t = document.querySelector("form#new_issue .is-submit-button-value")) == null || t.remove(), e.preventDefault()
                }), (0, f.on)("click", ".js-issue-unassign-self", function(e) {
                    const t = e.currentTarget.closest(".js-issue-sidebar-form");
                    vn(t, "delete"), e.preventDefault()
                }), (0, K.AC)(".js-pages-preview-toggle-form", async function(e, t) {
                    const n = await t.json();
                    e.querySelector("button.btn").textContent = n.json.new_button_value
                });

                function Fd(e, t) {
                    const n = e.getAttribute("data-cache-name");
                    return `${t}:sidebar:${n}`
                }
                i(Fd, "getCacheKey");

                function Ud(e, t, n) {
                    const o = e.getAttribute("data-cache-name");
                    if (!o) return;
                    const s = [];
                    for (const [a, c] of t.entries()) a.indexOf(o) !== -1 && s.push([a, c]);
                    const r = s.filter(a => a[1] !== "");
                    r.length > 0 ? sessionStorage.setItem(n, JSON.stringify(r)) : sessionStorage.removeItem(n)
                }
                i(Ud, "cacheValues");
                const yn = new Set;

                function ri() {
                    yn.clear()
                }
                i(ri, "clearHasFired");
                async function Wd(e, t) {
                    const n = e.getAttribute("data-cache-name"),
                        o = sessionStorage.getItem(t);
                    if (!n || !o || yn.has(n)) return;
                    yn.add(n);
                    const s = JSON.parse(o),
                        r = [];
                    for (const [a, c] of s) {
                        if (Object.prototype.toString.call(c) !== "[object String]") continue;
                        const l = document.createElement("input");
                        l.type = "hidden", l.value = c, l.name = a, e.appendChild(l), r.push(l)
                    }
                    try {
                        await ii(e);
                        for (const a of r) a.remove()
                    } catch {
                        yn.delete(n)
                    }
                }
                i(Wd, "restoreCachedValues");

                function xo(e, t) {
                    const n = Mo(e);
                    Ud(e, n, t), ri()
                }
                i(xo, "cacheValuesOnHide"), (0, v.N7)("[data-cacher]", {
                    add(e) {
                        const t = Fd(e, me());
                        Wd(e, t), window.addEventListener("pagehide", () => xo(e, t)), window.addEventListener("pjax:beforeReplace", () => xo(e, t)), window.addEventListener("turbo:before-visit", () => xo(e, t)), window.addEventListener("submit", n => {
                            n.defaultPrevented || setTimeout(() => {
                                for (const o of Object.keys(sessionStorage)) o.indexOf(t) !== -1 && (sessionStorage.removeItem(o), ri())
                            }, 0)
                        }, {
                            capture: !0
                        })
                    }
                });
                async function vn(e, t = "post", n) {
                    var o;
                    await ii(e, t, n);
                    const s = e.closest(".js-discussion-sidebar-item"),
                        r = (o = s == null ? void 0 : s.querySelector(".select-menu")) == null ? void 0 : o.getAttribute("id");
                    r && si(r)
                }
                i(vn, "previewSubmit");
                async function ii(e, t = "post", n) {
                    const o = Mo(e);
                    n && o.append(n.name, n.value);
                    const s = e.getAttribute("data-url");
                    if (!s) return;
                    const r = e.querySelector(".js-data-url-csrf"),
                        a = await fetch(s, {
                            method: t,
                            body: t === "delete" ? "" : o,
                            mode: "same-origin",
                            headers: {
                                "Scoped-CSRF-Token": r.value,
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        });
                    if (!a.ok) return;
                    const c = await a.text();
                    $d(e.closest(".js-discussion-sidebar-item"), c)
                }
                i(ii, "requestPreview");

                function zd(e) {
                    const t = e.getAttribute("data-reviewers-team-size-check-url");
                    if (!t) return !1;
                    const n = [...document.querySelectorAll(".js-reviewer-team")].map(c => c.getAttribute("data-id")),
                        o = e instanceof HTMLFormElement ? new FormData(e) : Mo(e),
                        r = new URLSearchParams(o).getAll("reviewer_team_ids[]").filter(c => !n.includes(c));
                    if (r.length === 0) return !1;
                    const a = new URLSearchParams(r.map(c => ["reviewer_team_ids[]", c]));
                    return Vd(e, `${t}?${a}`), !0
                }
                i(zd, "reviewerTeamsCheckRequired");
                async function Vd(e, t) {
                    const n = await fetch(t);
                    if (!n.ok) return;
                    const o = await n.text();
                    if (o.match(/[^\w-]js-large-team[^\w-]/)) Kd(e, o);
                    else {
                        jt(e, !0);
                        return
                    }
                }
                i(Vd, "triggerTeamReviewerCheck");

                function Kd(e, t) {
                    const n = e.querySelector(".js-large-teams-check-warning-container");
                    for (; n.firstChild;) n.removeChild(n.firstChild);
                    n.appendChild((0, ve.r)(document, t));
                    const o = n.querySelector("details");

                    function s(r) {
                        if (r.target instanceof Element) {
                            if (o.open = !1, !r.target.classList.contains("js-large-teams-confirm-button")) {
                                const a = e.querySelectorAll("input[name='reviewer_team_ids[]']");
                                for (const c of a) n.querySelector(`.js-large-team[data-id='${c.value}']`) && (c.checked = !1)
                            }
                            jt(e, !0), r.preventDefault()
                        }
                    }
                    i(s, "dialogAction"), n.querySelector(".js-large-teams-confirm-button").addEventListener("click", s, {
                        once: !0
                    }), n.querySelector(".js-large-teams-cancel-button").addEventListener("click", s, {
                        once: !0
                    }), o.addEventListener("details-dialog-close", s, {
                        once: !0
                    }), o.open = !0
                }
                i(Kd, "showTeamReviewerConfirmationDialog"), (0, f.on)("click", "div.js-project-column-menu-container .js-project-column-menu-item button", async function(e) {
                    const t = e.currentTarget;
                    Xd(t);
                    const n = t.getAttribute("data-url"),
                        o = t.parentElement.querySelector(".js-data-url-csrf"),
                        s = t.getAttribute("data-card-id"),
                        r = new FormData;
                    if (r.append("card_id", s), r.append("use_automation_prioritization", "true"), e.preventDefault(), !(await fetch(n, {
                            method: "PUT",
                            mode: "same-origin",
                            body: r,
                            headers: {
                                "Scoped-CSRF-Token": o.value,
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        })).ok) return;
                    const c = document.activeElement,
                        l = t.closest(".js-project-column-menu-dropdown");
                    if (c && l.contains(c)) try {
                        c.blur()
                    } catch {}
                });

                function Xd(e) {
                    const n = e.closest(".js-project-column-menu-dropdown").querySelector(".js-project-column-menu-summary"),
                        o = e.getAttribute("data-column-name");
                    n.textContent = o
                }
                i(Xd, "updateProjectColumnMenuSummary"), (0, f.on)("click", ".js-prompt-dismiss", function(e) {
                    e.currentTarget.closest(".js-prompt").remove()
                });

                function Mo(e) {
                    const t = e.closest("form");
                    if (!t) return new FormData;
                    const o = new FormData(t).entries(),
                        s = new FormData;
                    for (const [r, a] of o) t.contains(Gd(t, r, a.toString())) && s.append(r, a);
                    return s
                }
                i(Mo, "scopedFormData");

                function Gd(e, t, n) {
                    for (const o of e.elements)
                        if ((o instanceof HTMLInputElement || o instanceof HTMLTextAreaElement || o instanceof HTMLButtonElement) && o.name === t && o.value === n) return o;
                    return null
                }
                i(Gd, "findParam"), (0, f.on)("click", ".js-convert-to-draft", function(e) {
                    const t = e.currentTarget.getAttribute("data-url"),
                        n = e.currentTarget.parentElement.querySelector(".js-data-url-csrf");
                    fetch(t, {
                        method: "POST",
                        mode: "same-origin",
                        headers: {
                            "Scoped-CSRF-Token": n.value,
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    })
                }), (0, f.on)("click", "div.js-restore-item", async function(e) {
                    const t = e.currentTarget.getAttribute("data-url"),
                        n = e.currentTarget.getAttribute("data-column"),
                        o = e.currentTarget.querySelector(".js-data-url-csrf"),
                        s = new FormData;
                    if (s.set("memexProjectItemIds[]", n), !(await fetch(t, {
                            method: "PUT",
                            mode: "same-origin",
                            body: s,
                            headers: {
                                "Scoped-CSRF-Token": o.value,
                                "X-Requested-With": "XMLHttpRequest"
                            }
                        })).ok) throw new Error("connection error");
                    oi(e)
                })
            },
            2235: (O, x, u) => {
                "use strict";
                u.d(x, {
                    S: () => M
                });

                function w(y) {
                    const m = document.querySelectorAll(y);
                    if (m.length > 0) return m[m.length - 1]
                }
                i(w, "queryLast");

                function A() {
                    const y = w("meta[name=analytics-location]");
                    return y ? y.content : window.location.pathname
                }
                i(A, "pagePathname");

                function P() {
                    const y = w("meta[name=analytics-location-query-strip]");
                    let m = "";
                    y || (m = window.location.search);
                    const b = w("meta[name=analytics-location-params]");
                    b && (m += (m ? "&" : "?") + b.content);
                    for (const h of document.querySelectorAll("meta[name=analytics-param-rename]")) {
                        const E = h.content.split(":", 2);
                        m = m.replace(new RegExp(`(^|[?&])${E[0]}($|=)`, "g"), `$1${E[1]}$2`)
                    }
                    return m
                }
                i(P, "pageQuery");

                function M() {
                    return `${window.location.protocol}//${window.location.host}${A()+P()}`
                }
                i(M, "requestUri")
            },
            49908: () => {
                let O, x = !1;

                function u() {
                    O = document.activeElement, document.body && document.body.classList.toggle("intent-mouse", x)
                }
                i(u, "setClass"), document.addEventListener("mousedown", function() {
                    x = !0, O === document.activeElement && u()
                }, {
                    capture: !0
                }), document.addEventListener("keydown", function() {
                    x = !1
                }, {
                    capture: !0
                }), document.addEventListener("focusin", u, {
                    capture: !0
                })
            },
            81266: (O, x, u) => {
                "use strict";
                u.d(x, {
                    OD: () => m,
                    Qc: () => b,
                    nz: () => y
                });
                var w = u(77434),
                    A = u(84570);

                function P(h, E, L) {
                    const g = L.closest(".js-characters-remaining-container");
                    if (!g) return;
                    const C = g.querySelector(".js-characters-remaining"),
                        q = String(C.getAttribute("data-suffix")),
                        _ = (0, w.rq)(h),
                        N = E - _;
                    N <= 20 ? (C.textContent = `${N} ${q}`, C.classList.toggle("color-fg-danger", N <= 5), C.hidden = !1) : C.hidden = !0
                }
                i(P, "showRemainingCharacterCount");

                function M(h) {
                    return h.hasAttribute("data-maxlength") ? parseInt(h.getAttribute("data-maxlength") || "") : h.maxLength
                }
                i(M, "getFieldLimit");

                function y(h) {
                    const E = M(h),
                        L = (0, w.rq)(h.value);
                    return E - L < 0
                }
                i(y, "hasExceededCharacterLimit");

                function m(h) {
                    const E = M(h);
                    P(h.value, E, h)
                }
                i(m, "updateInputRemainingCharacters");

                function b(h) {
                    const E = h.querySelectorAll(".js-characters-remaining-container");
                    for (const L of E) {
                        const g = L.querySelector(".js-characters-remaining-field");
                        m(g)
                    }
                }
                i(b, "resetCharactersRemainingCounts"), (0, A.ZG)(".js-characters-remaining-field", function(h) {
                    function E() {
                        (h instanceof HTMLInputElement || h instanceof HTMLTextAreaElement) && m(h)
                    }
                    i(E, "onInput"), E(), h.addEventListener("input", E), h.addEventListener("blur", () => {
                        h.removeEventListener("input", E)
                    }, {
                        once: !0
                    })
                })
            },
            24473: () => {
                document.addEventListener("click", function(O) {
                    if (!(O.target instanceof Element)) return;
                    const x = "a[data-confirm], input[type=submit][data-confirm], input[type=checkbox][data-confirm], button[data-confirm]",
                        u = O.target.closest(x);
                    if (!u) return;
                    const w = u.getAttribute("data-confirm");
                    !w || u instanceof HTMLInputElement && u.hasAttribute("data-confirm-checked") && !u.checked || confirm(w) || (O.stopImmediatePropagation(), O.preventDefault())
                }, !0)
            },
            17364: (O, x, u) => {
                "use strict";
                u.d(x, {
                    $: () => h,
                    G: () => b
                });
                var w = u(86404),
                    A = u(64463),
                    P = u(59753);
                (0, A.N7)("include-fragment, poll-include-fragment", {
                    subscribe: L => (0, w.qC)((0, w.RB)(L, "error", m), (0, w.RB)(L, "loadstart", y))
                }), (0, P.on)("click", "include-fragment button[data-retry-button]", ({
                    currentTarget: L
                }) => {
                    const g = L.closest("include-fragment"),
                        C = g.src;
                    g.src = "", g.src = C
                });

                function M(L, g) {
                    const C = L.currentTarget;
                    if (C instanceof Element) {
                        for (const q of C.querySelectorAll("[data-show-on-error]")) q instanceof HTMLElement && (q.hidden = !g);
                        for (const q of C.querySelectorAll("[data-hide-on-error]")) q instanceof HTMLElement && (q.hidden = g)
                    }
                }
                i(M, "toggleElements");

                function y(L) {
                    M(L, !1)
                }
                i(y, "onLoad");

                function m(L) {
                    M(L, !0)
                }
                i(m, "onError");

                function b({
                    currentTarget: L
                }) {
                    L instanceof Element && h(L)
                }
                i(b, "loadDeferredContentByEvent");

                function h(L) {
                    const g = L.closest("details");
                    g && E(g)
                }
                i(h, "loadDeferredContent");

                function E(L) {
                    const g = L.getAttribute("data-deferred-details-content-url");
                    if (g) {
                        L.removeAttribute("data-deferred-details-content-url");
                        const C = L.querySelector("include-fragment, poll-include-fragment");
                        C && (C.src = g)
                    }
                }
                i(E, "setIncludeFragmentSrc")
            },
            13728: () => {
                document.addEventListener("pjax:click", function(O) {
                    if (window.onbeforeunload) return O.preventDefault()
                })
            },
            23651: (O, x, u) => {
                "use strict";
                u.d(x, {
                    k: () => y
                });
                var w = u(86404),
                    A = u(34782),
                    P = u(64463),
                    M = u(86276);
                (0, P.N7)(".js-responsive-underlinenav", {
                    constructor: HTMLElement,
                    subscribe: h => (y(h), (0, w.RB)(window, "resize", () => b(h)))
                });
                async function y(h) {
                    await A.C, b(h)
                }
                i(y, "asyncCalculateVisibility");

                function m(h, E) {
                    h.style.visibility = E ? "hidden" : "";
                    const L = h.getAttribute("data-tab-item");
                    if (L) {
                        const g = document.querySelector(`[data-menu-item=${L}]`);
                        g instanceof HTMLElement && (g.hidden = !E)
                    }
                }
                i(m, "toggleItem");

                function b(h) {
                    const E = h.querySelectorAll(".js-responsive-underlinenav-item"),
                        L = h.querySelector(".js-responsive-underlinenav-overflow"),
                        g = (0, M.oE)(L, h);
                    if (!g) return;
                    let C = !1;
                    for (const q of E) {
                        const _ = (0, M.oE)(q, h);
                        if (_) {
                            const N = _.left + q.offsetWidth >= g.left;
                            m(q, N), C = C || N
                        }
                    }
                    L.style.visibility = C ? "" : "hidden"
                }
                i(b, "calculateVisibility")
            },
            74675: () => {
                document.addEventListener("pjax:end", function() {
                    const O = document.querySelector('meta[name="selected-link"]'),
                        x = O && O.getAttribute("value");
                    if (!!x)
                        for (const u of document.querySelectorAll(".js-sidenav-container-pjax .js-selected-navigation-item")) {
                            const w = (u.getAttribute("data-selected-links") || "").split(" ").indexOf(x) >= 0;
                            w ? u.setAttribute("aria-current", "page") : u.removeAttribute("aria-current"), u.classList.toggle("selected", w)
                        }
                })
            },
            59371: () => {
                function O(w) {
                    const A = document.querySelector(".js-stale-session-flash"),
                        P = A.querySelector(".js-stale-session-flash-signed-in"),
                        M = A.querySelector(".js-stale-session-flash-signed-out");
                    A.hidden = !1, P.hidden = w === "false", M.hidden = w === "true", window.addEventListener("popstate", function(y) {
                        y.state && y.state.container != null && location.reload()
                    }), document.addEventListener("submit", function(y) {
                        y.preventDefault()
                    })
                }
                i(O, "sessionChanged");
                let x;
                if (typeof BroadcastChannel == "function") try {
                    x = new BroadcastChannel("stale-session"), x.onmessage = w => {
                        typeof w.data == "string" && O(w.data)
                    }
                } catch {}
                if (!x) {
                    let w = !1;
                    x = {
                        postMessage(A) {
                            w = !0;
                            try {
                                window.localStorage.setItem("logged-in", A)
                            } finally {
                                w = !1
                            }
                        }
                    }, window.addEventListener("storage", function(A) {
                        if (!w && A.storageArea === window.localStorage && A.key === "logged-in") try {
                            (A.newValue === "true" || A.newValue === "false") && O(A.newValue)
                        } finally {
                            window.localStorage.removeItem(A.key)
                        }
                    })
                }
                const u = document.querySelector(".js-stale-session-flash[data-signedin]");
                if (u) {
                    const w = u.getAttribute("data-signedin") || "";
                    x.postMessage(w)
                }
            },
            64048: (O, x, u) => {
                "use strict";
                var w = u(11793),
                    A = u(59753),
                    P = u(64463);
                class M {
                    constructor(m) {
                        this.container = m.container, this.selections = m.selections, this.inputWrap = m.inputWrap, this.input = m.input, this.tagTemplate = m.tagTemplate, this.form = this.input.form, this.autoComplete = m.autoComplete, this.multiTagInput = m.multiTagInput
                    }
                    setup() {
                        this.container.addEventListener("click", m => {
                            m.target.closest(".js-remove") ? this.removeTag(m) : this.onFocus()
                        }), this.input.addEventListener("focus", this.onFocus.bind(this)), this.input.addEventListener("blur", this.onBlur.bind(this)), this.input.addEventListener("keydown", this.onKeyDown.bind(this)), this.form.addEventListener("submit", this.onSubmit.bind(this)), this.autoComplete.addEventListener("auto-complete-change", () => {
                            this.selectTag(this.autoComplete.value)
                        })
                    }
                    onFocus() {
                        this.inputWrap.classList.add("focus"), this.input !== document.activeElement && this.input.focus()
                    }
                    onBlur() {
                        this.inputWrap.classList.remove("focus"), this.autoComplete.open || this.onSubmit()
                    }
                    onSubmit() {
                        this.input.value && (this.selectTag(this.input.value), this.autoComplete.open = !1)
                    }
                    onKeyDown(m) {
                        switch ((0, w.EL)(m)) {
                            case "Backspace":
                                this.onBackspace();
                                break;
                            case "Enter":
                            case "Tab":
                                this.taggifyValueWhenSuggesterHidden(m);
                                break;
                            case ",":
                            case " ":
                                this.taggifyValue(m);
                                break
                        }
                    }
                    taggifyValueWhenSuggesterHidden(m) {
                        !this.autoComplete.open && this.input.value && (m.preventDefault(), this.selectTag(this.input.value))
                    }
                    taggifyValue(m) {
                        this.input.value && (m.preventDefault(), this.selectTag(this.input.value), this.autoComplete.open = !1)
                    }
                    selectTag(m) {
                        const b = this.normalizeTag(m),
                            h = this.selectedTags();
                        let E = !1;
                        for (let L = 0; L < b.length; L++) {
                            const g = b[L];
                            h.indexOf(g) < 0 && (this.selections.appendChild(this.templateTag(g)), E = !0)
                        }
                        E && (this.input.value = "", (0, A.f)(this.form, "tags:changed"))
                    }
                    removeTag(m) {
                        const b = m.target;
                        m.preventDefault(), b.closest(".js-tag-input-tag").remove(), (0, A.f)(this.form, "tags:changed")
                    }
                    templateTag(m) {
                        const b = this.tagTemplate.cloneNode(!0);
                        return b.querySelector("input").value = m, b.querySelector(".js-placeholder-tag-name").replaceWith(m), b.classList.remove("d-none", "js-template"), b
                    }
                    normalizeTag(m) {
                        const b = m.toLowerCase().trim();
                        return b ? this.multiTagInput ? b.split(/[\s,']+/) : [b.replace(/[\s,']+/g, "-")] : []
                    }
                    onBackspace() {
                        if (!this.input.value) {
                            const m = this.selections.querySelector("li:last-child .js-remove");
                            m instanceof HTMLElement && m.click()
                        }
                    }
                    selectedTags() {
                        const m = this.selections.querySelectorAll("input");
                        return Array.from(m).map(b => b.value).filter(b => b.length > 0)
                    }
                }
                i(M, "TagInput"), (0, P.N7)(".js-tag-input-container", {
                    constructor: HTMLElement,
                    initialize(y) {
                        new M({
                            container: y,
                            inputWrap: y.querySelector(".js-tag-input-wrapper"),
                            input: y.querySelector('input[type="text"], input:not([type])'),
                            selections: y.querySelector(".js-tag-input-selected-tags"),
                            tagTemplate: y.querySelector(".js-template"),
                            autoComplete: y.querySelector("auto-complete"),
                            multiTagInput: !1
                        }).setup()
                    }
                }), (0, P.N7)(".js-multi-tag-input-container", {
                    constructor: HTMLElement,
                    initialize(y) {
                        new M({
                            container: y,
                            inputWrap: y.querySelector(".js-tag-input-wrapper"),
                            input: y.querySelector('input[type="text"], input:not([type])'),
                            selections: y.querySelector(".js-tag-input-selected-tags"),
                            tagTemplate: y.querySelector(".js-template"),
                            autoComplete: y.querySelector("auto-complete"),
                            multiTagInput: !0
                        }).setup()
                    }
                })
            },
            34078: (O, x, u) => {
                "use strict";
                u.d(x, {
                    P: () => P,
                    g: () => M
                });
                var w = u(59753);
                const A = new WeakMap;

                function P(b) {
                    return A.get(b)
                }
                i(P, "getCodeEditor");
                async function M(b) {
                    return A.get(b) || y(await m(b, "codeEditor:ready"))
                }
                i(M, "getAsyncCodeEditor");

                function y(b) {
                    if (!(b instanceof CustomEvent)) throw new Error("assert: event is not a CustomEvent");
                    const h = b.detail.editor;
                    if (!b.target) throw new Error("assert: event.target is null");
                    return A.set(b.target, h), h
                }
                i(y, "onEditorFromEvent"), (0, w.on)("codeEditor:ready", ".js-code-editor", y);

                function m(b, h) {
                    return new Promise(E => {
                        b.addEventListener(h, E, {
                            once: !0
                        })
                    })
                }
                i(m, "nextEvent")
            },
            81503: (O, x, u) => {
                "use strict";
                u.d(x, {
                    $1: () => A,
                    d8: () => M,
                    ej: () => w,
                    kT: () => y
                });

                function w(m) {
                    return A(m)[0]
                }
                i(w, "getCookie");

                function A(m) {
                    const b = [];
                    for (const h of P()) {
                        const [E, L] = h.trim().split("=");
                        m === E && typeof L != "undefined" && b.push({
                            key: E,
                            value: L
                        })
                    }
                    return b
                }
                i(A, "getCookies");

                function P() {
                    try {
                        return document.cookie.split(";")
                    } catch {
                        return []
                    }
                }
                i(P, "readCookies");

                function M(m, b, h = null, E = !1, L = "lax") {
                    let g = document.domain;
                    if (g == null) throw new Error("Unable to get document domain");
                    g.endsWith(".github.com") && (g = "github.com");
                    const C = location.protocol === "https:" ? "; secure" : "",
                        q = h ? `; expires=${h}` : "";
                    E === !1 && (g = `.${g}`);
                    try {
                        document.cookie = `${m}=${b}; path=/; domain=${g}${q}${C}; samesite=${L}`
                    } catch {}
                }
                i(M, "setCookie");

                function y(m, b = !1) {
                    let h = document.domain;
                    if (h == null) throw new Error("Unable to get document domain");
                    h.endsWith(".github.com") && (h = "github.com");
                    const E = new Date().getTime(),
                        L = new Date(E - 1).toUTCString(),
                        g = location.protocol === "https:" ? "; secure" : "",
                        C = `; expires=${L}`;
                    b === !1 && (h = `.${h}`);
                    try {
                        document.cookie = `${m}=''; path=/; domain=${h}${C}${g}`
                    } catch {}
                }
                i(y, "deleteCookie")
            },
            26360: (O, x, u) => {
                "use strict";
                u.d(x, {
                    LN: () => L,
                    aJ: () => le,
                    cI: () => J,
                    eK: () => C,
                    mT: () => g
                });
                var w = u(79785),
                    A = u(43452),
                    P = u(82918),
                    M = u(50232),
                    y = u(28382),
                    m = u(2235);
                let b = !1,
                    h = 0;
                const E = Date.now();

                function L(U) {
                    U.error && q(N(_(U.error)))
                }
                i(L, "reportEvent");
                async function g(U) {
                    if (!!U.promise) try {
                        await U.promise
                    } catch (S) {
                        q(N(_(S)))
                    }
                }
                i(g, "reportPromiseRejectionEvent");

                function C(U, S = {}) {
                    U && U.name !== "AbortError" && q(N(_(U), S))
                }
                i(C, "reportError");
                async function q(U) {
                    var S, I;
                    if (!Ae()) return;
                    const D = (I = (S = document.head) == null ? void 0 : S.querySelector('meta[name="browser-errors-url"]')) == null ? void 0 : I.content;
                    if (!!D) {
                        if (ce(U.error.stacktrace)) {
                            b = !0;
                            return
                        }
                        h++;
                        try {
                            await fetch(D, {
                                method: "post",
                                body: JSON.stringify(U)
                            })
                        } catch {}
                    }
                }
                i(q, "report");

                function _(U) {
                    return {
                        type: U.name,
                        value: U.message,
                        stacktrace: J(U)
                    }
                }
                i(_, "formatError");

                function N(U, S = {}) {
                    return Object.assign({
                        error: U,
                        sanitizedUrl: (0, m.S)() || window.location.href,
                        readyState: document.readyState,
                        referrer: (0, w.wP)(),
                        timeSinceLoad: Math.round(Date.now() - E),
                        user: le() || void 0,
                        bundler: Ct()
                    }, S)
                }
                i(N, "errorContext");

                function J(U) {
                    return (0, y.Q)(U.stack || "").map(S => ({
                        filename: S.file || "",
                        function: String(S.methodName),
                        lineno: (S.lineNumber || 0).toString(),
                        colno: (S.column || 0).toString()
                    }))
                }
                i(J, "stacktrace");
                const Y = /(chrome|moz|safari)-extension:\/\//;

                function ce(U) {
                    return U.some(S => Y.test(S.filename) || Y.test(S.function))
                }
                i(ce, "isExtensionError");

                function le() {
                    var U, S;
                    const I = (S = (U = document.head) == null ? void 0 : U.querySelector('meta[name="user-login"]')) == null ? void 0 : S.content;
                    return I || `anonymous-${(0,P.b)()}`
                }
                i(le, "pageUser");
                let se = !1;
                window.addEventListener("pageshow", () => se = !1), window.addEventListener("pagehide", () => se = !0), document.addEventListener(w.QE.ERROR, U => {
                    q(N({
                        type: "SoftNavError",
                        value: U.detail,
                        stacktrace: J(new Error)
                    }))
                });

                function Ae() {
                    return !se && !b && h < 10 && (0, M.Gb)() && !(0, A.Z)(document)
                }
                i(Ae, "reportable");

                function Ct() {
                    return "webpack"
                }
                i(Ct, "bundlerName"), typeof BroadcastChannel == "function" && new BroadcastChannel("shared-worker-error").addEventListener("message", S => {
                    C(S.data.error)
                })
            },
            95186: (O, x, u) => {
                "use strict";
                u.d(x, {
                    Y: () => m,
                    q: () => b
                });
                var w = u(88149),
                    A = u(86058);
                const P = "dimension_";
                let M;
                try {
                    const h = (0, w.n)("octolytics");
                    delete h.baseContext, M = new A.R(h)
                } catch {}

                function y(h) {
                    const E = (0, w.n)("octolytics").baseContext || {};
                    if (E) {
                        delete E.app_id, delete E.event_url, delete E.host;
                        for (const g in E) g.startsWith(P) && (E[g.replace(P, "")] = E[g], delete E[g])
                    }
                    const L = document.querySelector("meta[name=visitor-payload]");
                    if (L) {
                        const g = JSON.parse(atob(L.content));
                        Object.assign(E, g)
                    }
                    return Object.assign(E, h)
                }
                i(y, "extendBaseContext");

                function m(h) {
                    M == null || M.sendPageView(y(h))
                }
                i(m, "sendPageView");

                function b(h, E) {
                    var L, g;
                    const C = (g = (L = document.head) == null ? void 0 : L.querySelector('meta[name="current-catalog-service"]')) == null ? void 0 : g.content,
                        q = C ? {
                            service: C
                        } : {};
                    for (const [_, N] of Object.entries(E)) N != null && (q[_] = `${N}`);
                    M == null || M.sendEvent(h || "unknown", y(q))
                }
                i(b, "sendEvent")
            },
            81654: (O, x, u) => {
                "use strict";
                u.d(x, {
                    $S: () => A,
                    Fk: () => P,
                    sz: () => M
                });
                var w = u(83476);

                function A(y, m, b) {
                    const h = {
                            hydroEventPayload: y,
                            hydroEventHmac: m,
                            visitorPayload: "",
                            visitorHmac: "",
                            hydroClientContext: b
                        },
                        E = document.querySelector("meta[name=visitor-payload]");
                    E instanceof HTMLMetaElement && (h.visitorPayload = E.content);
                    const L = document.querySelector("meta[name=visitor-hmac]") || "";
                    L instanceof HTMLMetaElement && (h.visitorHmac = L.content), (0, w.b)(h, !0)
                }
                i(A, "sendData");

                function P(y) {
                    const m = y.getAttribute("data-hydro-view") || "",
                        b = y.getAttribute("data-hydro-view-hmac") || "",
                        h = y.getAttribute("data-hydro-client-context") || "";
                    A(m, b, h)
                }
                i(P, "trackView");

                function M(y) {
                    const m = y.getAttribute("data-hydro-click-payload") || "",
                        b = y.getAttribute("data-hydro-click-hmac") || "",
                        h = y.getAttribute("data-hydro-client-context") || "";
                    A(m, b, h)
                }
                i(M, "sendHydroEvent")
            },
            19935: (O, x, u) => {
                "use strict";
                var w = u(27034);
                window.IncludeFragmentElement.prototype.fetch = A => (A.headers.append("X-Requested-With", "XMLHttpRequest"), window.fetch(A))
            },
            75552: (O, x, u) => {
                "use strict";
                u.d(x, {
                    vt: () => Y,
                    WF: () => J,
                    DV: () => N,
                    jW: () => Ae,
                    Nc: () => g,
                    $t: () => P
                });
                const w = {
                    frequency: .6,
                    recency: .4
                };

                function A(S, I) {
                    return S.sort((D, z) => I(D) - I(z))
                }
                i(A, "sortBy");

                function P(S) {
                    const I = y(S),
                        D = m(S);
                    return function(z) {
                        return M(I.get(z) || 0, D.get(z) || 0)
                    }
                }
                i(P, "scorer");

                function M(S, I) {
                    return S * w.frequency + I * w.recency
                }
                i(M, "score");

                function y(S) {
                    const I = [...Object.values(S)].reduce((D, z) => D + z.visitCount, 0);
                    return new Map(Object.keys(S).map(D => [D, S[D].visitCount / I]))
                }
                i(y, "frequencyMap");

                function m(S) {
                    const I = A([...Object.keys(S)], z => S[z].lastVisitedAt),
                        D = I.length;
                    return new Map(I.map((z, Q) => [z, (Q + 1) / D]))
                }
                i(m, "recencyMap");
                const b = /^\/orgs\/([a-z0-9-]+)\/teams\/([\w-]+)/,
                    h = [/^\/([^/]+)\/([^/]+)\/?$/, /^\/([^/]+)\/([^/]+)\/blob/, /^\/([^/]+)\/([^/]+)\/tree/, /^\/([^/]+)\/([^/]+)\/issues/, /^\/([^/]+)\/([^/]+)\/pulls?/, /^\/([^/]+)\/([^/]+)\/pulse/],
                    E = [
                        ["organization", /^\/orgs\/([a-z0-9-]+)\/projects\/([0-9-]+)/],
                        ["repository", /^\/([^/]+)\/([^/]+)\/projects\/([0-9-]+)/]
                    ],
                    L = 100;

                function g(S) {
                    const I = S.match(b);
                    if (I) {
                        q(N(I[1], I[2]));
                        return
                    }
                    let D;
                    for (let Q = 0, ae = E.length; Q < ae; Q++) {
                        const [ye, He] = E[Q];
                        if (D = S.match(He), D) {
                            let re = null,
                                Ve = null;
                            switch (ye) {
                                case "organization":
                                    re = D[1], Ve = D[2];
                                    break;
                                case "repository":
                                    re = `${D[1]}/${D[2]}`, Ve = D[3];
                                    break;
                                default:
                            }
                            re && Ve && q(Y(re, Ve));
                            return
                        }
                    }
                    let z;
                    for (let Q = 0, ae = h.length; Q < ae; Q++)
                        if (z = S.match(h[Q]), z) {
                            q(J(z[1], z[2]));
                            return
                        }
                }
                i(g, "logPageView");

                function C(S) {
                    const I = Object.keys(S);
                    if (I.length <= L) return S;
                    const D = P(S),
                        z = I.sort((Q, ae) => D(ae) - D(Q)).slice(0, L / 2);
                    return Object.fromEntries(z.map(Q => [Q, S[Q]]))
                }
                i(C, "limitedPageViews");

                function q(S) {
                    const I = Ae(),
                        D = _(),
                        z = I[S] || {
                            lastVisitedAt: D,
                            visitCount: 0
                        };
                    z.visitCount += 1, z.lastVisitedAt = D, I[S] = z, se(C(I))
                }
                i(q, "logPageViewByKey");

                function _() {
                    return Math.floor(Date.now() / 1e3)
                }
                i(_, "currentEpochTimeInSeconds");

                function N(S, I) {
                    return `team:${S}/${I}`
                }
                i(N, "buildTeamKey");

                function J(S, I) {
                    return `repository:${S}/${I}`
                }
                i(J, "buildRepositoryKey");

                function Y(S, I) {
                    return `project:${S}/${I}`
                }
                i(Y, "buildProjectKey");
                const ce = /^(team|repository|project):[^/]+\/[^/]+(\/([^/]+))?$/,
                    le = "jump_to:page_views";

                function se(S) {
                    Ct(le, JSON.stringify(S))
                }
                i(se, "setPageViewsMap");

                function Ae() {
                    const S = U(le);
                    if (!S) return {};
                    let I;
                    try {
                        I = JSON.parse(S)
                    } catch {
                        return se({}), {}
                    }
                    const D = {};
                    for (const z in I) z.match(ce) && (D[z] = I[z]);
                    return D
                }
                i(Ae, "getPageViewsMap");

                function Ct(S, I) {
                    try {
                        window.localStorage.setItem(S, I)
                    } catch {}
                }
                i(Ct, "setItem");

                function U(S) {
                    try {
                        return window.localStorage.getItem(S)
                    } catch {
                        return null
                    }
                }
                i(U, "getItem")
            },
            75509: (O, x, u) => {
                "use strict";
                u.d(x, {
                    a: () => w
                });

                function w(y, m) {
                    const b = y.closest("[data-notification-id]");
                    m.hasAttribute("data-status") && A(b, m.getAttribute("data-status")), m.hasAttribute("data-subscription-status") && P(b, m.getAttribute("data-subscription-status")), m.hasAttribute("data-starred-status") && M(b, m.getAttribute("data-starred-status"))
                }
                i(w, "updateNotificationStates");

                function A(y, m) {
                    y.classList.toggle("notification-archived", m === "archived"), y.classList.toggle("notification-unread", m === "unread"), y.classList.toggle("notification-read", m === "read")
                }
                i(A, "toggleNotificationStatus");

                function P(y, m) {
                    y.classList.toggle("notification-unsubscribed", m === "unsubscribed")
                }
                i(P, "toggleNotificationSubscriptionStatus");

                function M(y, m) {
                    y.classList.toggle("notification-starred", m === "starred")
                }
                i(M, "toggleNotificationStarredStatus")
            },
            20963: (O, x, u) => {
                "use strict";
                u.d(x, {
                    X: () => A
                });
                var w = u(64463);

                function A() {
                    return /Windows/.test(navigator.userAgent) ? "windows" : /Macintosh/.test(navigator.userAgent) ? "mac" : null
                }
                i(A, "getPlatform");

                function P(M) {
                    const y = (M.getAttribute("data-platforms") || "").split(","),
                        m = A();
                    return Boolean(m && y.includes(m))
                }
                i(P, "runningOnPlatform"), (0, w.N7)(".js-remove-unless-platform", function(M) {
                    P(M) || M.remove()
                })
            },
            46836: (O, x, u) => {
                "use strict";
                u.d(x, {
                    LS: () => P,
                    cl: () => M,
                    rV: () => A
                });
                var w = u(60785);
                const {
                    getItem: A,
                    setItem: P,
                    removeItem: M
                } = (0, w.Z)("sessionStorage")
            },
            79785: (O, x, u) => {
                "use strict";
                u.d(x, {
                    Ak: () => q,
                    F6: () => ce,
                    FP: () => g,
                    LD: () => L,
                    OE: () => E,
                    Po: () => h,
                    QE: () => P,
                    Xk: () => J,
                    Ys: () => Y,
                    wP: () => le
                });
                var w = u(46836),
                    A = u(2235);
                const P = Object.freeze({
                        INITIAL: "soft-nav:initial",
                        SUCCESS: "soft-nav:success",
                        ERROR: "soft-nav:error"
                    }),
                    M = "soft-navigation-fail",
                    y = "soft-navigation-referrer",
                    m = "soft-navigation-marker",
                    b = "reload";

                function h() {
                    return (0, w.rV)(m) === "1"
                }
                i(h, "inSoftNavigation");

                function E() {
                    return Boolean(_())
                }
                i(E, "hasSoftNavFailure");

                function L() {
                    (0, w.LS)(m, "1"), (0, w.LS)(y, (0, A.S)() || window.location.href)
                }
                i(L, "startSoftNav");

                function g() {
                    (0, w.LS)(m, "0")
                }
                i(g, "endSoftNav");

                function C() {
                    (0, w.LS)(m, "0"), (0, w.cl)(y), (0, w.cl)(M)
                }
                i(C, "clearSoftNav");

                function q(se) {
                    (0, w.LS)(M, se || b)
                }
                i(q, "setSoftNavFailReason");

                function _() {
                    return (0, w.rV)(M)
                }
                i(_, "getSoftNavFailReason");
                let N = 0;

                function J() {
                    N += 1, document.dispatchEvent(new CustomEvent(P.SUCCESS, {
                        detail: N
                    }))
                }
                i(J, "softNavSucceeded");

                function Y() {
                    document.dispatchEvent(new CustomEvent(P.ERROR, {
                        detail: _() || b
                    })), N = 0, C()
                }
                i(Y, "softNavFailed");

                function ce() {
                    document.dispatchEvent(new CustomEvent(P.INITIAL)), N = 0, C()
                }
                i(ce, "softNavInitial");

                function le() {
                    return (0, w.rV)(y) || document.referrer
                }
                i(le, "getSoftNavReferrer")
            },
            37713: (O, x, u) => {
                "use strict";
                u.d(x, {
                    kc: () => M,
                    lA: () => y,
                    zT: () => P
                });
                var w = u(14037),
                    A = u(54235);

                function P(m) {
                    const b = m.ownerDocument;
                    setTimeout(() => {
                        b && b.defaultView && (m.scrollIntoView(), b.defaultView.scrollBy(0, -y(b)))
                    }, 0)
                }
                i(P, "scrollIntoView");

                function M(m) {
                    const b = (0, w.Kt)(m);
                    b && P(b)
                }
                i(M, "scrollToFragmentTarget");

                function y(m) {
                    (0, A.H)();
                    const b = m.querySelectorAll(".js-sticky-offset-scroll"),
                        h = m.querySelectorAll(".js-position-sticky"),
                        E = Math.max(0, ...Array.from(b).map(C => {
                            const {
                                top: q,
                                height: _
                            } = C.getBoundingClientRect();
                            return q === 0 ? _ : 0
                        })) + Math.max(0, ...Array.from(h).map(C => {
                            const {
                                top: q,
                                height: _
                            } = C.getBoundingClientRect(), N = parseInt(getComputedStyle(C).top);
                            if (!C.parentElement) return 0;
                            const J = C.parentElement.getBoundingClientRect().top;
                            return q === N && J < 0 ? _ : 0
                        })),
                        L = m.querySelectorAll(".js-position-sticky-stacked"),
                        g = Array.from(L).reduce((C, q) => {
                            const {
                                height: _,
                                top: N
                            } = q.getBoundingClientRect(), J = N < 0, Y = q.classList.contains("is-stuck");
                            return C + (!J && Y ? _ : 0)
                        }, 0);
                    return E + g
                }
                i(y, "computeFixedYOffset")
            },
            24519: (O, x, u) => {
                "use strict";
                u.d(x, {
                    Z: () => L
                });
                var w = u(51374),
                    A = u(52660),
                    P = u(65935),
                    M = u(85806);
                let y = !1;

                function m(g) {
                    const C = new URL(g, window.location.origin),
                        q = new URLSearchParams(C.search.slice(1));
                    return q.set("webauthn-support", (0, M.T)()), C.search = q.toString(), C.toString()
                }
                i(m, "urlWithParams");
                async function b() {
                    const g = document.querySelector("link[rel=sudo-modal]"),
                        C = document.querySelector(".js-sudo-prompt");
                    if (C instanceof HTMLTemplateElement) return C;
                    if (g) {
                        const q = await (0, A.a)(document, m(g.href));
                        return document.body.appendChild(q), document.querySelector(".js-sudo-prompt")
                    } else throw new Error("couldn't load sudo prompt")
                }
                i(b, "loadPromptTemplate");
                let h = !1;
                async function E() {
                    if (y) return !1;
                    y = !0, h = !1;
                    const C = (await b()).content.cloneNode(!0),
                        q = await (0, w.W)({
                            content: C
                        });
                    return await new Promise(_ => {
                        q.addEventListener("dialog:remove", function() {
                            y = !1, _()
                        }, {
                            once: !0
                        })
                    }), h
                }
                i(E, "sudoPrompt"), (0, P.AC)(".js-sudo-form", async function(g, C) {
                    try {
                        await C.text()
                    } catch (q) {
                        if (!q.response) throw q;
                        let _;
                        switch (q.response.status) {
                            case 401:
                                _ = "Incorrect password.";
                                break;
                            case 429:
                                _ = "Too many password attempts. Please wait and try again later.";
                                break;
                            default:
                                _ = "Failed to receive a response. Please try again later."
                        }
                        g.querySelector(".js-sudo-error").textContent = _, g.querySelector(".js-sudo-error").hidden = !1, g.querySelector(".js-sudo-password").value = "";
                        return
                    }
                    h = !0, g.closest("details").removeAttribute("open")
                });
                async function L() {
                    const g = await fetch("/sessions/in_sudo", {
                        headers: {
                            accept: "application/json",
                            "X-Requested-With": "XMLHttpRequest"
                        }
                    });
                    return g.ok && await g.text() === "true" ? !0 : E()
                }
                i(L, "triggerSudoPrompt")
            },
            77434: (O, x, u) => {
                "use strict";
                u.d(x, {
                    Om: () => M,
                    lp: () => A,
                    rq: () => w,
                    t4: () => P
                });

                function w(m) {
                    const b = "\u200D",
                        h = m.split(b);
                    let E = 0;
                    for (const L of h) E += Array.from(L.split(/[\ufe00-\ufe0f]/).join("")).length;
                    return E / h.length
                }
                i(w, "getUtf8StringLength");

                function A(m, b, h) {
                    let E = m.value.substring(0, m.selectionEnd || 0),
                        L = m.value.substring(m.selectionEnd || 0);
                    return E = E.replace(b, h), L = L.replace(b, h), y(m, E + L, E.length), h
                }
                i(A, "replaceText");

                function P(m, b, h) {
                    if (m.selectionStart === null || m.selectionEnd === null) return A(m, b, h);
                    const E = m.value.substring(0, m.selectionStart),
                        L = m.value.substring(m.selectionEnd);
                    return y(m, E + h + L, E.length), h
                }
                i(P, "replaceSelection");

                function M(m, b, h = {}) {
                    const E = m.selectionEnd || 0,
                        L = m.value.substring(0, E),
                        g = m.value.substring(E),
                        C = m.value === "" || L.match(/\n$/) ? "" : `
`,
                        q = h.appendNewline ? `
` : "",
                        _ = C + b + q;
                    m.value = L + _ + g;
                    const N = E + _.length;
                    return m.selectionStart = N, m.selectionEnd = N, m.dispatchEvent(new CustomEvent("change", {
                        bubbles: !0,
                        cancelable: !1
                    })), m.focus(), _
                }
                i(M, "insertText");

                function y(m, b, h) {
                    m.value = b, m.selectionStart = h, m.selectionEnd = h, m.dispatchEvent(new CustomEvent("change", {
                        bubbles: !0,
                        cancelable: !1
                    }))
                }
                i(y, "setTextareaValueAndCursor")
            },
            85806: (O, x, u) => {
                "use strict";
                u.d(x, {
                    T: () => A,
                    k: () => P
                });
                var w = u(70112);

                function A() {
                    return (0, w.Zh)() ? "supported" : "unsupported"
                }
                i(A, "webauthnSupportLevel");
                async function P() {
                    var M;
                    return await ((M = window.PublicKeyCredential) == null ? void 0 : M.isUserVerifyingPlatformAuthenticatorAvailable()) ? "supported" : "unsupported"
                }
                i(P, "iuvpaaSupportLevel")
            }
        },
        O => {
            var x = i(w => O(O.s = w), "__webpack_exec__");
            O.O(0, [5724, 5388, 93, 8932, 1717, 5329, 2486, 8646, 3682, 3932, 3826, 5222], () => x(48776));
            var u = O.O()
        }
    ]);
})();

//# sourceMappingURL=behaviors-4d8a0c4a8bc8.js.map