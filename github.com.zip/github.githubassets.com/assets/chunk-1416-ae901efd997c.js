"use strict";
(() => {
    var D = Object.defineProperty;
    var o = (w, v) => D(w, "name", {
        value: v,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [1416], {
            34782: (w, v, g) => {
                g.d(v, {
                    C: () => b,
                    x: () => m
                });
                const m = function() {
                        return document.readyState === "interactive" || document.readyState === "complete" ? Promise.resolve() : new Promise(f => {
                            document.addEventListener("DOMContentLoaded", () => {
                                f()
                            })
                        })
                    }(),
                    b = function() {
                        return document.readyState === "complete" ? Promise.resolve() : new Promise(f => {
                            window.addEventListener("load", f)
                        })
                    }()
            },
            81654: (w, v, g) => {
                g.d(v, {
                    $S: () => b,
                    Fk: () => f,
                    sz: () => y
                });
                var m = g(83476);

                function b(d, l, s) {
                    const r = {
                            hydroEventPayload: d,
                            hydroEventHmac: l,
                            visitorPayload: "",
                            visitorHmac: "",
                            hydroClientContext: s
                        },
                        a = document.querySelector("meta[name=visitor-payload]");
                    a instanceof HTMLMetaElement && (r.visitorPayload = a.content);
                    const i = document.querySelector("meta[name=visitor-hmac]") || "";
                    i instanceof HTMLMetaElement && (r.visitorHmac = i.content), (0, m.b)(r, !0)
                }
                o(b, "sendData");

                function f(d) {
                    const l = d.getAttribute("data-hydro-view") || "",
                        s = d.getAttribute("data-hydro-view-hmac") || "",
                        r = d.getAttribute("data-hydro-client-context") || "";
                    b(l, s, r)
                }
                o(f, "trackView");

                function y(d) {
                    const l = d.getAttribute("data-hydro-click-payload") || "",
                        s = d.getAttribute("data-hydro-click-hmac") || "",
                        r = d.getAttribute("data-hydro-client-context") || "";
                    b(l, s, r)
                }
                o(y, "sendHydroEvent")
            },
            43452: (w, v, g) => {
                g.d(v, {
                    Z: () => m
                });

                function m(b) {
                    var f, y;
                    const d = (y = (f = b.head) == null ? void 0 : f.querySelector('meta[name="expected-hostname"]')) == null ? void 0 : y.content;
                    if (!d) return !1;
                    const l = d.replace(/\.$/, "").split(".").slice(-2).join("."),
                        s = b.location.hostname.replace(/\.$/, "").split(".").slice(-2).join(".");
                    return l !== s
                }
                o(m, "detectProxySite")
            },
            83476: (w, v, g) => {
                g.d(v, {
                    b: () => y
                });
                var m = g(43452),
                    b = g(34782);
                let f = [];

                function y(a, i = !1) {
                    a.timestamp === void 0 && (a.timestamp = new Date().getTime()), a.loggedIn = r(), a.bundler = "webpack", f.push(a), i ? s() : l()
                }
                o(y, "sendStats");
                let d = null;
                async function l() {
                    await b.C, d == null && (d = window.requestIdleCallback(s))
                }
                o(l, "scheduleSendStats");

                function s() {
                    var a, i;
                    if (d = null, !f.length || (0, m.Z)(document)) return;
                    const h = (i = (a = document.head) == null ? void 0 : a.querySelector('meta[name="browser-stats-url"]')) == null ? void 0 : i.content;
                    if (!h) return;
                    const A = JSON.stringify({
                        stats: f
                    });
                    try {
                        navigator.sendBeacon && navigator.sendBeacon(h, A)
                    } catch {}
                    f = []
                }
                o(s, "flushStats");

                function r() {
                    var a, i;
                    return !!((i = (a = document.head) == null ? void 0 : a.querySelector('meta[name="user-login"]')) == null ? void 0 : i.content)
                }
                o(r, "isLoggedIn"), document.addEventListener("pagehide", s), document.addEventListener("visibilitychange", s)
            },
            61416: (w, v, g) => {
                g.r(v);
                var m = g(90420),
                    b = g(81654),
                    f = Object.defineProperty,
                    y = Object.getOwnPropertyDescriptor,
                    d = o((s, r, a, i) => {
                        for (var h = i > 1 ? void 0 : i ? y(r, a) : r, A = s.length - 1, E; A >= 0; A--)(E = s[A]) && (h = (i ? E(r, a, h) : E(h)) || h);
                        return i && h && f(r, a, h), h
                    }, "__decorateClass");
                let l = o(class extends HTMLElement {
                    connectedCallback() {
                        var s;
                        (s = this.trigger) == null || s.addEventListener("menu:activate", this.onMenuOpened.bind(this));
                        const r = this.getHeadings();
                        this.observer = new IntersectionObserver(() => this.observerCallback(), {
                            root: null,
                            rootMargin: "0px",
                            threshold: 1
                        });
                        for (const a of r || []) this.observer.observe(a)
                    }
                    disconnectedCallback() {
                        var s, r;
                        (s = this.trigger) == null || s.removeEventListener("menu:activate", this.onMenuOpened), (r = this.observer) == null || r.disconnect()
                    }
                    blur() {
                        window.setTimeout(() => {
                            document.activeElement && document.activeElement.blur()
                        }, 0)
                    }
                    onMenuOpened(s) {
                        const r = s.currentTarget,
                            a = r.getAttribute("data-menu-hydro-click") || "",
                            i = r.getAttribute("data-menu-hydro-click-hmac") || "",
                            h = r.getAttribute("data-hydro-client-context") || "";
                        (0, b.$S)(a, i, h), this.observerCallback()
                    }
                    getHeadings() {
                        return this.content ? this.content.querySelectorAll("h1,h2,h3,h4,h5,h6") : null
                    }
                    observerCallback() {
                        const a = Array.prototype.slice.call(this.getHeadings()).filter(i => this.isElementInViewPort(i))[0];
                        for (const i of this.entries || []) i.removeAttribute("aria-current"), i.style.backgroundColor = "";
                        if (a) {
                            const i = this.mapHeadingToListItemUsingAnchor(a);
                            if (i) {
                                i.setAttribute("aria-current", "page"), i.style.backgroundColor = "var(--color-accent-emphasis)";
                                const h = i.closest("div");
                                h && i.offsetTop && (h.scrollTop = i.offsetTop - parseInt(getComputedStyle(h).paddingTop))
                            }
                        }
                    }
                    isElementInViewPort(s) {
                        return s.getBoundingClientRect().y >= 0
                    }
                    mapHeadingToListItemUsingAnchor(s) {
                        const r = s.getElementsByTagName("a")[0];
                        if (r && this.entries) return this.entries.find(a => a.href.replace("user-content-", "") === r.href)
                    }
                }, "ReadmeTocElement");
                d([m.fA], l.prototype, "trigger", 2), d([m.fA], l.prototype, "content", 2), d([m.GO], l.prototype, "entries", 2), l = d([m.Ih], l)
            },
            90420: (w, v, g) => {
                g.d(v, {
                    Lj: () => T,
                    Ih: () => x,
                    P4: () => i,
                    fA: () => A,
                    GO: () => E
                });
                const m = new WeakSet;

                function b(t) {
                    m.add(t), t.shadowRoot && f(t.shadowRoot), l(t), d(t.ownerDocument)
                }
                o(b, "bind");

                function f(t) {
                    l(t), d(t)
                }
                o(f, "bindShadow");
                const y = new WeakMap;

                function d(t = document) {
                    if (y.has(t)) return y.get(t);
                    let e = !1;
                    const n = new MutationObserver(u => {
                        for (const p of u)
                            if (p.type === "attributes" && p.target instanceof Element) a(p.target);
                            else if (p.type === "childList" && p.addedNodes.length)
                            for (const _ of p.addedNodes) _ instanceof Element && l(_)
                    });
                    n.observe(t, {
                        childList: !0,
                        subtree: !0,
                        attributeFilter: ["data-action"]
                    });
                    const c = {
                        get closed() {
                            return e
                        },
                        unsubscribe() {
                            e = !0, y.delete(t), n.disconnect()
                        }
                    };
                    return y.set(t, c), c
                }
                o(d, "listenForBind");

                function l(t) {
                    for (const e of t.querySelectorAll("[data-action]")) a(e);
                    t instanceof Element && t.hasAttribute("data-action") && a(t)
                }
                o(l, "bindElements");

                function s(t) {
                    const e = t.currentTarget;
                    for (const n of r(e))
                        if (t.type === n.type) {
                            const c = e.closest(n.tag);
                            m.has(c) && typeof c[n.method] == "function" && c[n.method](t);
                            const u = e.getRootNode();
                            if (u instanceof ShadowRoot && m.has(u.host) && u.host.matches(n.tag)) {
                                const p = u.host;
                                typeof p[n.method] == "function" && p[n.method](t)
                            }
                        }
                }
                o(s, "handleEvent");

                function* r(t) {
                    for (const e of (t.getAttribute("data-action") || "").trim().split(/\s+/)) {
                        const n = e.lastIndexOf(":"),
                            c = Math.max(0, e.lastIndexOf("#")) || e.length;
                        yield {
                            type: e.slice(0, n),
                            tag: e.slice(n + 1, c),
                            method: e.slice(c + 1) || "handleEvent"
                        }
                    }
                }
                o(r, "bindings");

                function a(t) {
                    for (const e of r(t)) t.addEventListener(e.type, s)
                }
                o(a, "bindActions");

                function i(t, e) {
                    const n = t.tagName.toLowerCase();
                    if (t.shadowRoot) {
                        for (const c of t.shadowRoot.querySelectorAll(`[data-target~="${n}.${e}"]`))
                            if (!c.closest(n)) return c
                    }
                    for (const c of t.querySelectorAll(`[data-target~="${n}.${e}"]`))
                        if (c.closest(n) === t) return c
                }
                o(i, "findTarget");

                function h(t, e) {
                    const n = t.tagName.toLowerCase(),
                        c = [];
                    if (t.shadowRoot)
                        for (const u of t.shadowRoot.querySelectorAll(`[data-targets~="${n}.${e}"]`)) u.closest(n) || c.push(u);
                    for (const u of t.querySelectorAll(`[data-targets~="${n}.${e}"]`)) u.closest(n) === t && c.push(u);
                    return c
                }
                o(h, "findTargets");

                function A(t, e) {
                    return Object.defineProperty(t, e, {
                        configurable: !0,
                        get() {
                            return i(this, e)
                        }
                    })
                }
                o(A, "target");

                function E(t, e) {
                    return Object.defineProperty(t, e, {
                        configurable: !0,
                        get() {
                            return h(this, e)
                        }
                    })
                }
                o(E, "targets");

                function L(t) {
                    const e = t.name.replace(/([A-Z]($|[a-z]))/g, "-$1").replace(/(^-|-Element$)/g, "").toLowerCase();
                    window.customElements.get(e) || (window[t.name] = t, window.customElements.define(e, t))
                }
                o(L, "register");

                function O(t) {
                    for (const e of t.querySelectorAll("template[data-shadowroot]")) e.parentElement === t && t.attachShadow({
                        mode: e.getAttribute("data-shadowroot") === "closed" ? "closed" : "open"
                    }).append(e.content.cloneNode(!0))
                }
                o(O, "autoShadowRoot");
                const C = new WeakMap;

                function T(t, e) {
                    C.has(t) || C.set(t, []), C.get(t).push(e)
                }
                o(T, "attr");

                function k(t, e) {
                    e || (e = S(Object.getPrototypeOf(t)));
                    for (const n of e) {
                        const c = t[n],
                            u = P(n);
                        let p = {
                            configurable: !0,
                            get() {
                                return this.getAttribute(u) || ""
                            },
                            set(_) {
                                this.setAttribute(u, _ || "")
                            }
                        };
                        typeof c == "number" ? p = {
                            configurable: !0,
                            get() {
                                return Number(this.getAttribute(u) || 0)
                            },
                            set(_) {
                                this.setAttribute(u, _)
                            }
                        } : typeof c == "boolean" && (p = {
                            configurable: !0,
                            get() {
                                return this.hasAttribute(u)
                            },
                            set(_) {
                                this.toggleAttribute(u, _)
                            }
                        }), Object.defineProperty(t, n, p), n in t && !t.hasAttribute(u) && p.set.call(t, c)
                    }
                }
                o(k, "initializeAttrs");

                function S(t) {
                    const e = new Set;
                    let n = t;
                    for (; n && n !== HTMLElement;) {
                        const c = C.get(n) || [];
                        for (const u of c) e.add(u);
                        n = Object.getPrototypeOf(n)
                    }
                    return e
                }
                o(S, "getAttrNames");

                function P(t) {
                    return `data-${t.replace(/([A-Z]($|[a-z]))/g,"-$1")}`.replace(/--/g, "-").toLowerCase()
                }
                o(P, "attrToAttributeName");

                function I(t) {
                    let e = t.observedAttributes || [];
                    Object.defineProperty(t, "observedAttributes", {
                        configurable: !0,
                        get() {
                            return [...S(t.prototype)].map(P).concat(e)
                        },
                        set(n) {
                            e = n
                        }
                    })
                }
                o(I, "defineObservedAttributes");
                const M = new WeakSet;

                function R(t, e) {
                    t.toggleAttribute("data-catalyst", !0), customElements.upgrade(t), M.add(t), O(t), k(t), b(t), e && e.call(t), t.shadowRoot && f(t.shadowRoot)
                }
                o(R, "initializeInstance");

                function $(t) {
                    I(t), L(t)
                }
                o($, "initializeClass");

                function H(t) {
                    return M.has(t)
                }
                o(H, "initialized");

                function x(t) {
                    const e = t.prototype.connectedCallback;
                    t.prototype.connectedCallback = function() {
                        R(this, e)
                    }, $(t)
                }
                o(x, "controller")
            }
        }
    ]);
})();

//# sourceMappingURL=1416-c049aa11feac.js.map