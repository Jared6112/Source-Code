"use strict";
(() => {
    var D = Object.defineProperty;
    var i = (O, P) => D(O, "name", {
        value: P,
        configurable: !0
    });
    (globalThis.webpackChunk = globalThis.webpackChunk || []).push([
        [6319], {
            80425: (O, P, E) => {
                E.d(P, {
                    k: () => b
                });
                var h = function() {
                        for (var f = new Uint32Array(256), _ = 256; _--;) {
                            for (var l = _, c = 8; c--;) l = l & 1 ? 3988292384 ^ l >>> 1 : l >>> 1;
                            f[_] = l
                        }
                        return function(a) {
                            var u = -1;
                            typeof a == "string" && (a = function(F) {
                                for (var T = F.length, I = new Array(T), R = -1; ++R < T;) I[R] = F.charCodeAt(R);
                                return I
                            }(a));
                            for (var p = 0, k = a.length; p < k; p++) u = u >>> 8 ^ f[u & 255 ^ a[p]];
                            return (u ^ -1) >>> 0
                        }
                    }(),
                    S = i(function(f) {
                        return f < 0 && (f = 4294967295 + f + 1), ("0000000" + f.toString(16)).slice(-8)
                    }, "hex"),
                    b = i(function(f, _) {
                        var l = h(f);
                        return _ ? S(l) : l
                    }, "crc32")
            },
            3447: (O, P, E) => {
                E.d(P, {
                    D: () => b,
                    P: () => S
                });
                var h = E(46263);

                function S(f = 0, _ = {}) {
                    return (l, c, a) => {
                        if (!a || typeof a.value != "function") throw new Error("debounce can only decorate functions");
                        const u = a.value;
                        a.value = (0, h.P)(u, f, _), Object.defineProperty(l, c, a)
                    }
                }
                i(S, "throttle");

                function b(f = 0, _ = {}) {
                    return (l, c, a) => {
                        if (!a || typeof a.value != "function") throw new Error("debounce can only decorate functions");
                        const u = a.value;
                        a.value = (0, h.D)(u, f, _), Object.defineProperty(l, c, a)
                    }
                }
                i(b, "debounce")
            },
            46263: (O, P, E) => {
                E.d(P, {
                    D: () => S,
                    P: () => h
                });

                function h(b, f = 0, {
                    start: _ = !0,
                    middle: l = !0,
                    once: c = !1
                } = {}) {
                    let a = 0,
                        u, p = !1;

                    function k(...F) {
                        if (p) return;
                        const T = Date.now() - a;
                        a = Date.now(), _ ? (_ = !1, b.apply(this, F), c && k.cancel()) : (l && T < f || !l) && (clearTimeout(u), u = setTimeout(() => {
                            a = Date.now(), b.apply(this, F), c && k.cancel()
                        }, l ? f - T : f))
                    }
                    return i(k, "fn"), k.cancel = () => {
                        clearTimeout(u), p = !0
                    }, k
                }
                i(h, "throttle");

                function S(b, f = 0, {
                    start: _ = !1,
                    middle: l = !1,
                    once: c = !1
                } = {}) {
                    return h(b, f, {
                        start: _,
                        middle: l,
                        once: c
                    })
                }
                i(S, "debounce")
            },
            47142: (O, P, E) => {
                E.d(P, {
                    CD: () => L,
                    Gs: () => R,
                    m7: () => M
                });
                var h = -1 / 0,
                    S = 1 / 0,
                    b = -.005,
                    f = -.005,
                    _ = -.01,
                    l = 1,
                    c = .9,
                    a = .8,
                    u = .7,
                    p = .6;

                function k(y) {
                    return y.toLowerCase() === y
                }
                i(k, "islower");

                function F(y) {
                    return y.toUpperCase() === y
                }
                i(F, "isupper");

                function T(y) {
                    for (var A = y.length, g = new Array(A), w = "/", v = 0; v < A; v++) {
                        var o = y[v];
                        w === "/" ? g[v] = c : w === "-" || w === "_" || w === " " ? g[v] = a : w === "." ? g[v] = p : k(w) && F(o) ? g[v] = u : g[v] = 0, w = o
                    }
                    return g
                }
                i(T, "precompute_bonus");

                function I(y, A, g, w) {
                    for (var v = y.length, o = A.length, e = y.toLowerCase(), n = A.toLowerCase(), s = T(A, s), t = 0; t < v; t++) {
                        g[t] = new Array(o), w[t] = new Array(o);
                        for (var r = h, d = t === v - 1 ? f : _, m = 0; m < o; m++)
                            if (e[t] === n[m]) {
                                var C = h;
                                t ? m && (C = Math.max(w[t - 1][m - 1] + s[m], g[t - 1][m - 1] + l)) : C = m * b + s[m], g[t][m] = C, w[t][m] = r = Math.max(C, r + d)
                            } else g[t][m] = h, w[t][m] = r = r + d
                    }
                }
                i(I, "compute");

                function R(y, A) {
                    var g = y.length,
                        w = A.length;
                    if (!g || !w) return h;
                    if (g === w) return S;
                    if (w > 1024) return h;
                    var v = new Array(g),
                        o = new Array(g);
                    return I(y, A, v, o), o[g - 1][w - 1]
                }
                i(R, "score");

                function M(y, A) {
                    var g = y.length,
                        w = A.length,
                        v = new Array(g);
                    if (!g || !w) return v;
                    if (g === w) {
                        for (var o = 0; o < g; o++) v[o] = o;
                        return v
                    }
                    if (w > 1024) return v;
                    var e = new Array(g),
                        n = new Array(g);
                    I(y, A, e, n);
                    for (var s = !1, o = g - 1, t = w - 1; o >= 0; o--)
                        for (; t >= 0; t--)
                            if (e[o][t] !== h && (s || e[o][t] === n[o][t])) {
                                s = o && t && n[o][t] === e[o - 1][t - 1] + l, v[o] = t--;
                                break
                            }
                    return v
                }
                i(M, "positions");

                function L(y, A) {
                    y = y.toLowerCase(), A = A.toLowerCase();
                    for (var g = y.length, w = 0, v = 0; w < g; w += 1)
                        if (v = A.indexOf(y[w], v) + 1, v === 0) return !1;
                    return !0
                }
                i(L, "hasMatch")
            },
            90420: (O, P, E) => {
                E.d(P, {
                    Lj: () => L,
                    Ih: () => s,
                    P4: () => p,
                    fA: () => F,
                    GO: () => T
                });
                const h = new WeakSet;

                function S(t) {
                    h.add(t), t.shadowRoot && b(t.shadowRoot), l(t), _(t.ownerDocument)
                }
                i(S, "bind");

                function b(t) {
                    l(t), _(t)
                }
                i(b, "bindShadow");
                const f = new WeakMap;

                function _(t = document) {
                    if (f.has(t)) return f.get(t);
                    let r = !1;
                    const d = new MutationObserver(C => {
                        for (const N of C)
                            if (N.type === "attributes" && N.target instanceof Element) u(N.target);
                            else if (N.type === "childList" && N.addedNodes.length)
                            for (const x of N.addedNodes) x instanceof Element && l(x)
                    });
                    d.observe(t, {
                        childList: !0,
                        subtree: !0,
                        attributeFilter: ["data-action"]
                    });
                    const m = {
                        get closed() {
                            return r
                        },
                        unsubscribe() {
                            r = !0, f.delete(t), d.disconnect()
                        }
                    };
                    return f.set(t, m), m
                }
                i(_, "listenForBind");

                function l(t) {
                    for (const r of t.querySelectorAll("[data-action]")) u(r);
                    t instanceof Element && t.hasAttribute("data-action") && u(t)
                }
                i(l, "bindElements");

                function c(t) {
                    const r = t.currentTarget;
                    for (const d of a(r))
                        if (t.type === d.type) {
                            const m = r.closest(d.tag);
                            h.has(m) && typeof m[d.method] == "function" && m[d.method](t);
                            const C = r.getRootNode();
                            if (C instanceof ShadowRoot && h.has(C.host) && C.host.matches(d.tag)) {
                                const N = C.host;
                                typeof N[d.method] == "function" && N[d.method](t)
                            }
                        }
                }
                i(c, "handleEvent");

                function* a(t) {
                    for (const r of (t.getAttribute("data-action") || "").trim().split(/\s+/)) {
                        const d = r.lastIndexOf(":"),
                            m = Math.max(0, r.lastIndexOf("#")) || r.length;
                        yield {
                            type: r.slice(0, d),
                            tag: r.slice(d + 1, m),
                            method: r.slice(m + 1) || "handleEvent"
                        }
                    }
                }
                i(a, "bindings");

                function u(t) {
                    for (const r of a(t)) t.addEventListener(r.type, c)
                }
                i(u, "bindActions");

                function p(t, r) {
                    const d = t.tagName.toLowerCase();
                    if (t.shadowRoot) {
                        for (const m of t.shadowRoot.querySelectorAll(`[data-target~="${d}.${r}"]`))
                            if (!m.closest(d)) return m
                    }
                    for (const m of t.querySelectorAll(`[data-target~="${d}.${r}"]`))
                        if (m.closest(d) === t) return m
                }
                i(p, "findTarget");

                function k(t, r) {
                    const d = t.tagName.toLowerCase(),
                        m = [];
                    if (t.shadowRoot)
                        for (const C of t.shadowRoot.querySelectorAll(`[data-targets~="${d}.${r}"]`)) C.closest(d) || m.push(C);
                    for (const C of t.querySelectorAll(`[data-targets~="${d}.${r}"]`)) C.closest(d) === t && m.push(C);
                    return m
                }
                i(k, "findTargets");

                function F(t, r) {
                    return Object.defineProperty(t, r, {
                        configurable: !0,
                        get() {
                            return p(this, r)
                        }
                    })
                }
                i(F, "target");

                function T(t, r) {
                    return Object.defineProperty(t, r, {
                        configurable: !0,
                        get() {
                            return k(this, r)
                        }
                    })
                }
                i(T, "targets");

                function I(t) {
                    const r = t.name.replace(/([A-Z]($|[a-z]))/g, "-$1").replace(/(^-|-Element$)/g, "").toLowerCase();
                    window.customElements.get(r) || (window[t.name] = t, window.customElements.define(r, t))
                }
                i(I, "register");

                function R(t) {
                    for (const r of t.querySelectorAll("template[data-shadowroot]")) r.parentElement === t && t.attachShadow({
                        mode: r.getAttribute("data-shadowroot") === "closed" ? "closed" : "open"
                    }).append(r.content.cloneNode(!0))
                }
                i(R, "autoShadowRoot");
                const M = new WeakMap;

                function L(t, r) {
                    M.has(t) || M.set(t, []), M.get(t).push(r)
                }
                i(L, "attr");

                function y(t, r) {
                    r || (r = A(Object.getPrototypeOf(t)));
                    for (const d of r) {
                        const m = t[d],
                            C = g(d);
                        let N = {
                            configurable: !0,
                            get() {
                                return this.getAttribute(C) || ""
                            },
                            set(x) {
                                this.setAttribute(C, x || "")
                            }
                        };
                        typeof m == "number" ? N = {
                            configurable: !0,
                            get() {
                                return Number(this.getAttribute(C) || 0)
                            },
                            set(x) {
                                this.setAttribute(C, x)
                            }
                        } : typeof m == "boolean" && (N = {
                            configurable: !0,
                            get() {
                                return this.hasAttribute(C)
                            },
                            set(x) {
                                this.toggleAttribute(C, x)
                            }
                        }), Object.defineProperty(t, d, N), d in t && !t.hasAttribute(C) && N.set.call(t, m)
                    }
                }
                i(y, "initializeAttrs");

                function A(t) {
                    const r = new Set;
                    let d = t;
                    for (; d && d !== HTMLElement;) {
                        const m = M.get(d) || [];
                        for (const C of m) r.add(C);
                        d = Object.getPrototypeOf(d)
                    }
                    return r
                }
                i(A, "getAttrNames");

                function g(t) {
                    return `data-${t.replace(/([A-Z]($|[a-z]))/g,"-$1")}`.replace(/--/g, "-").toLowerCase()
                }
                i(g, "attrToAttributeName");

                function w(t) {
                    let r = t.observedAttributes || [];
                    Object.defineProperty(t, "observedAttributes", {
                        configurable: !0,
                        get() {
                            return [...A(t.prototype)].map(g).concat(r)
                        },
                        set(d) {
                            r = d
                        }
                    })
                }
                i(w, "defineObservedAttributes");
                const v = new WeakSet;

                function o(t, r) {
                    t.toggleAttribute("data-catalyst", !0), customElements.upgrade(t), v.add(t), R(t), y(t), S(t), r && r.call(t), t.shadowRoot && b(t.shadowRoot)
                }
                i(o, "initializeInstance");

                function e(t) {
                    w(t), I(t)
                }
                i(e, "initializeClass");

                function n(t) {
                    return v.has(t)
                }
                i(n, "initialized");

                function s(t) {
                    const r = t.prototype.connectedCallback;
                    t.prototype.connectedCallback = function() {
                        o(this, r)
                    }, e(t)
                }
                i(s, "controller")
            },
            33241: (O, P, E) => {
                E.d(P, {
                    Z4: () => b,
                    ck: () => _
                });
                var h = E(47142),
                    S = E(80425);
                class b {
                    constructor(c, a, u) {
                        this.providers = [], this.scopeType = "static_items_page", this.title = c, this.scopeId = a, this.providers = [new f(u)]
                    }
                }
                i(b, "StaticItemsPage");
                class f {
                    constructor(c) {
                        this.hasCommands = !0, this.debounce = 0;
                        const a = c.length;
                        this.items = c.map((u, p) => (u.priority = a - p, u))
                    }
                    async fetch(c) {
                        return {
                            results: this.fuzzyFilter(this.items, c)
                        }
                    }
                    enabledFor() {
                        return !0
                    }
                    clearCache() {}
                    fuzzyFilter(c, a, u = 0) {
                        if (a.isBlank()) return c;
                        const p = [];
                        for (const k of c) k.calculateScore(a.text) > u && p.push(k);
                        return p
                    }
                }
                i(f, "StaticItemsProvider");
                class _ {
                    constructor(c) {
                        this.score = 0, this.position = "", this.title = c.title, this.priority = c.priority, this.group = c.group, this.subtitle = c.subtitle, this.matchFields = c.matchFields, this.typeahead = c.typeahead, this.hint = c.hint, this.icon = c.icon
                    }
                    get matchingFields() {
                        return this.matchFields ? this.matchFields : [this.title]
                    }
                    get key() {
                        var c;
                        return `${this.title}-${this.group}-${this.subtitle}-${(c=this.matchFields)==null?void 0:c.join("-")}`
                    }
                    get id() {
                        return this._id || (this._id = (0, S.k)(this.key).toString()), this._id
                    }
                    calculateScore(c) {
                        const a = this.matchingFields.map(u => this.calculateScoreForField({
                            field: u,
                            queryText: c
                        }));
                        return Math.max(...a)
                    }
                    calculateScoreForField({
                        field: c,
                        queryText: a
                    }) {
                        return (0, h.CD)(a, c) ? (0, h.Gs)(a, c) : -1 / 0
                    }
                }
                i(_, "Item")
            },
            86058: (O, P, E) => {
                E.d(P, {
                    R: () => c
                });

                function h() {
                    let a;
                    try {
                        a = window.top.document.referrer
                    } catch {
                        if (window.parent) try {
                            a = window.parent.document.referrer
                        } catch {}
                    }
                    return a === "" && (a = document.referrer), a
                }
                i(h, "getReferrer");

                function S() {
                    try {
                        return `${screen.width}x${screen.height}`
                    } catch {
                        return "unknown"
                    }
                }
                i(S, "getScreenResolution");

                function b() {
                    let a = 0,
                        u = 0;
                    try {
                        return typeof window.innerWidth == "number" ? (u = window.innerWidth, a = window.innerHeight) : document.documentElement != null && document.documentElement.clientWidth != null ? (u = document.documentElement.clientWidth, a = document.documentElement.clientHeight) : document.body != null && document.body.clientWidth != null && (u = document.body.clientWidth, a = document.body.clientHeight), `${u}x${a}`
                    } catch {
                        return "unknown"
                    }
                }
                i(b, "getBrowserResolution");

                function f() {
                    return navigator.languages ? navigator.languages.join(",") : navigator.language || ""
                }
                i(f, "getBrowserLanguages");

                function _() {
                    return {
                        referrer: h(),
                        user_agent: navigator.userAgent,
                        screen_resolution: S(),
                        browser_resolution: b(),
                        browser_languages: f(),
                        pixel_ratio: window.devicePixelRatio,
                        timestamp: Date.now(),
                        tz_seconds: new Date().getTimezoneOffset() * -60
                    }
                }
                i(_, "getRequestContext");
                var l = E(82918);
                class c {
                    constructor(u) {
                        this.options = u
                    }
                    get collectorUrl() {
                        return this.options.collectorUrl
                    }
                    get clientId() {
                        return this.options.clientId ? this.options.clientId : (0, l.b)()
                    }
                    createEvent(u) {
                        return {
                            page: location.href,
                            title: document.title,
                            context: { ...this.options.baseContext,
                                ...u
                            }
                        }
                    }
                    sendPageView(u) {
                        const p = this.createEvent(u);
                        this.send({
                            page_views: [p]
                        })
                    }
                    sendEvent(u, p) {
                        const k = { ...this.createEvent(p),
                            type: u
                        };
                        this.send({
                            events: [k]
                        })
                    }
                    send({
                        page_views: u,
                        events: p
                    }) {
                        const k = {
                                client_id: this.clientId,
                                page_views: u,
                                events: p,
                                request_context: _()
                            },
                            F = JSON.stringify(k);
                        try {
                            if (navigator.sendBeacon) {
                                navigator.sendBeacon(this.collectorUrl, F);
                                return
                            }
                        } catch {}
                        fetch(this.collectorUrl, {
                            method: "POST",
                            cache: "no-cache",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: F,
                            keepalive: !1
                        })
                    }
                }
                i(c, "AnalyticsClient")
            },
            82918: (O, P, E) => {
                E.d(P, {
                    b: () => _
                });
                let h;

                function S() {
                    return `${Math.round(Math.random()*(Math.pow(2,31)-1))}.${Math.round(Date.now()/1e3)}`
                }
                i(S, "generateClientId");

                function b(l) {
                    const c = `GH1.1.${l}`,
                        a = Date.now(),
                        u = new Date(a + 1 * 365 * 86400 * 1e3).toUTCString();
                    let {
                        domain: p
                    } = document;
                    p.endsWith(".github.com") && (p = "github.com"), document.cookie = `_octo=${c}; expires=${u}; path=/; domain=${p}; secure; samesite=lax`
                }
                i(b, "setClientIdCookie");

                function f() {
                    let l;
                    const a = document.cookie.match(/_octo=([^;]+)/g);
                    if (!a) return;
                    let u = [0, 0];
                    for (const p of a) {
                        const [, k] = p.split("="), [, F, ...T] = k.split("."), I = F.split("-").map(Number);
                        I > u && (u = I, l = T.join("."))
                    }
                    return l
                }
                i(f, "getClientIdFromCookie");

                function _() {
                    try {
                        const l = f();
                        if (l) return l;
                        const c = S();
                        return b(c), c
                    } catch {
                        return h || (h = S()), h
                    }
                }
                i(_, "getOrCreateClientId")
            },
            88149: (O, P, E) => {
                E.d(P, {
                    n: () => h
                });

                function h(S = "ha") {
                    let b;
                    const f = {},
                        _ = document.head.querySelectorAll(`meta[name^="${S}-"]`);
                    for (const l of Array.from(_)) {
                        const {
                            name: c,
                            content: a
                        } = l, u = c.replace(`${S}-`, "").replace(/-/g, "_");
                        u === "url" ? b = a : f[u] = a
                    }
                    if (!b) throw new Error(`AnalyticsClient ${S}-url meta tag not found`);
                    return {
                        collectorUrl: b,
                        ...Object.keys(f).length > 0 ? {
                            baseContext: f
                        } : {}
                    }
                }
                i(h, "getOptionsFromMeta")
            },
            38772: (O, P, E) => {
                E.d(P, {
                    dy: () => A,
                    sY: () => g,
                    Au: () => o
                });
                var h = E(69567);
                const S = new WeakSet;

                function b(e) {
                    return S.has(e)
                }
                i(b, "isDirective");

                function f(e, n) {
                    return b(n) ? (n(e), !0) : !1
                }
                i(f, "processDirective");

                function _(e) {
                    return (...n) => {
                        const s = e(...n);
                        return S.add(s), s
                    }
                }
                i(_, "directive");
                const l = new WeakMap;
                class c {
                    constructor(n, s) {
                        this.element = n, this.type = s, this.element.addEventListener(this.type, this), l.get(this.element).set(this.type, this)
                    }
                    set(n) {
                        typeof n == "function" ? this.handleEvent = n.bind(this.element) : typeof n == "object" && typeof n.handleEvent == "function" ? this.handleEvent = n.handleEvent.bind(n) : (this.element.removeEventListener(this.type, this), l.get(this.element).delete(this.type))
                    }
                    static
                    for (n) {
                        l.has(n.element) || l.set(n.element, new Map);
                        const s = n.attributeName.slice(2),
                            t = l.get(n.element);
                        return t.has(s) ? t.get(s) : new c(n.element, s)
                    }
                }
                i(c, "EventHandler");

                function a(e, n) {
                    return e instanceof h.sV && e.attributeName.startsWith("on") ? (c.for(e).set(n), e.element.removeAttributeNS(e.attributeNamespace, e.attributeName), !0) : !1
                }
                i(a, "processEvent");

                function u(e, n) {
                    return n instanceof L && e instanceof h.GZ ? (n.renderInto(e), !0) : !1
                }
                i(u, "processSubTemplate");

                function p(e, n) {
                    return n instanceof DocumentFragment && e instanceof h.GZ ? (n.childNodes.length && e.replace(...n.childNodes), !0) : !1
                }
                i(p, "processDocumentFragment");

                function k(e) {
                    return typeof e == "object" && Symbol.iterator in e
                }
                i(k, "isIterable");

                function F(e, n) {
                    if (!k(n)) return !1;
                    if (e instanceof h.GZ) {
                        const s = [];
                        for (const t of n)
                            if (t instanceof L) {
                                const r = document.createDocumentFragment();
                                t.renderInto(r), s.push(...r.childNodes)
                            } else t instanceof DocumentFragment ? s.push(...t.childNodes) : s.push(String(t));
                        return s.length && e.replace(...s), !0
                    } else return e.value = Array.from(n).join(" "), !0
                }
                i(F, "processIterable");

                function T(e, n) {
                    f(e, n) || (0, h.W_)(e, n) || a(e, n) || u(e, n) || p(e, n) || F(e, n) || (0, h.Al)(e, n)
                }
                i(T, "processPart");
                const I = new WeakMap,
                    R = new WeakMap,
                    M = new WeakMap;
                class L {
                    constructor(n, s, t) {
                        this.strings = n, this.values = s, this.processor = t
                    }
                    get template() {
                        if (I.has(this.strings)) return I.get(this.strings); {
                            const n = document.createElement("template"),
                                s = this.strings.length - 1;
                            return n.innerHTML = this.strings.reduce((t, r, d) => t + r + (d < s ? `{{ ${d} }}` : ""), ""), I.set(this.strings, n), n
                        }
                    }
                    renderInto(n) {
                        const s = this.template;
                        if (R.get(n) !== s) {
                            R.set(n, s);
                            const t = new h.R(s, this.values, this.processor);
                            M.set(n, t), n instanceof h.GZ ? n.replace(...t.children) : n.appendChild(t);
                            return
                        }
                        M.get(n).update(this.values)
                    }
                }
                i(L, "TemplateResult");
                const y = (0, h.AQ)(T);

                function A(e, ...n) {
                    return new L(e, n, y)
                }
                i(A, "html");

                function g(e, n) {
                    e.renderInto(n)
                }
                i(g, "render");
                const w = new WeakMap,
                    v = _((...e) => n => {
                        w.has(n) || w.set(n, {
                            i: e.length
                        });
                        const s = w.get(n);
                        for (let t = 0; t < e.length; t += 1) e[t] instanceof Promise ? Promise.resolve(e[t]).then(r => {
                            t < s.i && (s.i = t, T(n, r))
                        }) : t <= s.i && (s.i = t, T(n, e[t]))
                    }),
                    o = _(e => n => {
                        if (!(n instanceof h.GZ)) return;
                        const s = document.createElement("template");
                        s.innerHTML = e;
                        const t = document.importNode(s.content, !0);
                        n.replace(...t.childNodes)
                    })
            },
            69567: (O, P, E) => {
                E.d(P, {
                    sV: () => l,
                    GZ: () => k,
                    R: () => v,
                    AQ: () => F,
                    W_: () => I,
                    Al: () => T,
                    XK: () => M
                });

                function* h(o) {
                    let e = "",
                        n = 0,
                        s = !1;
                    for (let t = 0; t < o.length; t += 1) o[t] === "{" && o[t + 1] === "{" && o[t - 1] !== "\\" && !s ? (s = !0, e && (yield {
                        type: "string",
                        start: n,
                        end: t,
                        value: e
                    }), e = "{{", n = t, t += 2) : o[t] === "}" && o[t + 1] === "}" && o[t - 1] !== "\\" && s && (s = !1, yield {
                        type: "part",
                        start: n,
                        end: t + 2,
                        value: e.slice(2).trim()
                    }, e = "", t += 2, n = t), e += o[t] || "";
                    e && (yield {
                        type: "string",
                        start: n,
                        end: o.length,
                        value: e
                    })
                }
                i(h, "parse");
                var S = function(o, e, n) {
                        if (!e.has(o)) throw new TypeError("attempted to set private field on non-instance");
                        return e.set(o, n), n
                    },
                    b = function(o, e) {
                        if (!e.has(o)) throw new TypeError("attempted to get private field on non-instance");
                        return e.get(o)
                    },
                    f, _;
                class l {
                    constructor(e, n) {
                        this.expression = n, f.set(this, void 0), _.set(this, ""), S(this, f, e), b(this, f).updateParent("")
                    }
                    get attributeName() {
                        return b(this, f).attr.name
                    }
                    get attributeNamespace() {
                        return b(this, f).attr.namespaceURI
                    }
                    get value() {
                        return b(this, _)
                    }
                    set value(e) {
                        S(this, _, e || ""), b(this, f).updateParent(e)
                    }
                    get element() {
                        return b(this, f).element
                    }
                    get booleanValue() {
                        return b(this, f).booleanValue
                    }
                    set booleanValue(e) {
                        b(this, f).booleanValue = e
                    }
                }
                i(l, "AttributeTemplatePart"), f = new WeakMap, _ = new WeakMap;
                class c {
                    constructor(e, n) {
                        this.element = e, this.attr = n, this.partList = []
                    }
                    get booleanValue() {
                        return this.element.hasAttributeNS(this.attr.namespaceURI, this.attr.name)
                    }
                    set booleanValue(e) {
                        if (this.partList.length !== 1) throw new DOMException("Operation not supported", "NotSupportedError");
                        this.partList[0].value = e ? "" : null
                    }
                    append(e) {
                        this.partList.push(e)
                    }
                    updateParent(e) {
                        if (this.partList.length === 1 && e === null) this.element.removeAttributeNS(this.attr.namespaceURI, this.attr.name);
                        else {
                            const n = this.partList.map(s => typeof s == "string" ? s : s.value).join("");
                            this.element.setAttributeNS(this.attr.namespaceURI, this.attr.name, n)
                        }
                    }
                }
                i(c, "AttributeValueSetter");
                var a = function(o, e, n) {
                        if (!e.has(o)) throw new TypeError("attempted to set private field on non-instance");
                        return e.set(o, n), n
                    },
                    u = function(o, e) {
                        if (!e.has(o)) throw new TypeError("attempted to get private field on non-instance");
                        return e.get(o)
                    },
                    p;
                class k {
                    constructor(e, n) {
                        this.expression = n, p.set(this, void 0), a(this, p, [e]), e.textContent = ""
                    }
                    get value() {
                        return u(this, p).map(e => e.textContent).join("")
                    }
                    set value(e) {
                        this.replace(e)
                    }
                    get previousSibling() {
                        return u(this, p)[0].previousSibling
                    }
                    get nextSibling() {
                        return u(this, p)[u(this, p).length - 1].nextSibling
                    }
                    replace(...e) {
                        const n = e.map(s => typeof s == "string" ? new Text(s) : s);
                        n.length || n.push(new Text("")), u(this, p)[0].before(...n);
                        for (const s of u(this, p)) s.remove();
                        a(this, p, n)
                    }
                }
                i(k, "NodeTemplatePart"), p = new WeakMap;

                function F(o) {
                    return {
                        createCallback(e, n, s) {
                            this.processCallback(e, n, s)
                        },
                        processCallback(e, n, s) {
                            var t;
                            if (!(typeof s != "object" || !s)) {
                                for (const r of n)
                                    if (r.expression in s) {
                                        const d = (t = s[r.expression]) !== null && t !== void 0 ? t : "";
                                        o(r, d)
                                    }
                            }
                        }
                    }
                }
                i(F, "createProcessor");

                function T(o, e) {
                    o.value = String(e)
                }
                i(T, "processPropertyIdentity");

                function I(o, e) {
                    return typeof e == "boolean" && o instanceof l && typeof o.element[o.attributeName] == "boolean" ? (o.booleanValue = e, !0) : !1
                }
                i(I, "processBooleanAttribute");
                const R = F(T),
                    M = F((o, e) => {
                        I(o, e) || T(o, e)
                    });
                var L = function(o, e, n) {
                        if (!e.has(o)) throw new TypeError("attempted to set private field on non-instance");
                        return e.set(o, n), n
                    },
                    y = function(o, e) {
                        if (!e.has(o)) throw new TypeError("attempted to get private field on non-instance");
                        return e.get(o)
                    },
                    A, g;

                function* w(o) {
                    const e = o.ownerDocument.createTreeWalker(o, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, null, !1);
                    let n;
                    for (; n = e.nextNode();)
                        if (n instanceof Element && n.hasAttributes())
                            for (let s = 0; s < n.attributes.length; s += 1) {
                                const t = n.attributes.item(s);
                                if (t && t.value.includes("{{")) {
                                    const r = new c(n, t);
                                    for (const d of h(t.value))
                                        if (d.type === "string") r.append(d.value);
                                        else {
                                            const m = new l(r, d.value);
                                            r.append(m), yield m
                                        }
                                }
                            } else if (n instanceof Text && n.textContent && n.textContent.includes("{{"))
                                for (const s of h(n.textContent)) {
                                    s.end < n.textContent.length && n.splitText(s.end), s.type === "part" && (yield new k(n, s.value));
                                    break
                                }
                }
                i(w, "collectParts");
                class v extends DocumentFragment {
                    constructor(e, n, s = R) {
                        var t, r;
                        super();
                        A.set(this, void 0), g.set(this, void 0), Object.getPrototypeOf(this !== v.prototype) && Object.setPrototypeOf(this, v.prototype), this.appendChild(e.content.cloneNode(!0)), L(this, g, Array.from(w(this))), L(this, A, s), (r = (t = y(this, A)).createCallback) === null || r === void 0 || r.call(t, this, y(this, g), n)
                    }
                    update(e) {
                        y(this, A).processCallback(this, y(this, g), e)
                    }
                }
                i(v, "TemplateInstance"), A = new WeakMap, g = new WeakMap
            }
        }
    ]);
})();

//# sourceMappingURL=6319-654d23c75510.js.map